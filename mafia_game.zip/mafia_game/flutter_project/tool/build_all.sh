#!/usr/bin/env bash
# ==============================================================================
# اسکریپت ساخت یکپارچه «مافیا لوکال» (Mafia Local)
# 1. کامپایل نسخه وب بازیکنان (Flutter Web)
# 2. کپی خروجی وب به پوشه assets/web/ اپلیکیشن میزبان
# 3. اجرای تست‌های واحد و تست عدم نشت اطلاعات (flutter test)
# 4. ساخت فایل نصبی اندروید میزبان (APK)
# ==============================================================================
set -euo pipefail

cd "$(dirname "$0")/.."

echo "==> [1/4] در حال کامپایل کلاینت وب بازیکنان (lib/player_web/main.dart)..."
flutter build web --target=lib/player_web/main.dart --release --base-href=/

echo "==> [2/4] کپی فایل‌های استاتیک وب به assets/web/ میزبان..."
rm -rf assets/web
mkdir -p assets/web
cp -R build/web/* assets/web/

echo "==> [3/4] اجرای flutter analyze و تست‌های واحد و یکپارچگی پروتکل..."
flutter analyze
flutter test

echo "==> [4/4] ساخت فایل APK اندروید میزبان (lib/host_app/main.dart)..."
flutter build apk --target=lib/host_app/main.dart --release

echo "=================================================================="
echo "ساخت با موفقیت انجام شد!"
echo "فایل نصبی میزبان: build/app/outputs/flutter-apk/app-release.apk"
echo "=================================================================="
