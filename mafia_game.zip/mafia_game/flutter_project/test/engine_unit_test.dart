import 'package:flutter_test/flutter_test.dart';
import 'package:mafia_local/core/engine/action_resolver.dart';
import 'package:mafia_local/core/engine/game_engine.dart';
import 'package:mafia_local/core/engine/win_checker.dart';
import 'package:mafia_local/core/roles/role_ids.dart';
import 'package:mafia_local/core/roles/role_module.dart';

void main() {
  group('تست‌های واحد موتور بازی مافیا لوکال (Engine Unit Tests)', () {
    test('توزیع نقش‌ها دقیقاً مطابق تنظیمات میزبان است', () {
      final engine = GameEngine();
      final host = engine.joinOrReconnect(name: 'میزبان', preferHost: true).session;
      for (final n in ['پ۲', 'پ۳', 'پ۴', 'پ۵', 'پ۶']) {
        engine.joinOrReconnect(name: n);
      }

      engine.configureRoles(host.playerId, {
        RoleIds.mafia: 1,
        RoleIds.doctor: 1,
        RoleIds.detective: 1,
        RoleIds.hunter: 0,
      });
      engine.startGame(host.playerId, seed: 12345);

      final counts = <String, int>{};
      for (final s in engine.sessions) {
        final r = engine.getRoleForPlayer(s.playerId)!;
        counts[r] = (counts[r] ?? 0) + 1;
      }

      expect(counts[RoleIds.mafia], 1);
      expect(counts[RoleIds.doctor], 1);
      expect(counts[RoleIds.detective], 1);
      expect(counts[RoleIds.villager], 3);
    });

    test('محافظت دکتر مانع از کشته شدن هدف شلیک مافیا می‌شود', () {
      final engine = GameEngine();
      final p1 = engine.joinOrReconnect(name: 'پ۱', preferHost: true).session;
      final p2 = engine.joinOrReconnect(name: 'پ۲').session;
      final p3 = engine.joinOrReconnect(name: 'پ۳').session;
      final p4 = engine.joinOrReconnect(name: 'پ۴').session;
      final p5 = engine.joinOrReconnect(name: 'پ۵').session;

      final baseView = engine.buildInternalView();
      final view = GameStateView(
        round: 1,
        phase: 'night',
        players: baseView.players,
        roleAssignments: {
          p1.playerId: RoleIds.mafia,
          p2.playerId: RoleIds.doctor,
          p3.playerId: RoleIds.detective,
          p4.playerId: RoleIds.villager,
          p5.playerId: RoleIds.villager,
        },
        doctorLastProtectedTarget: const {},
        hunterUsedShot: const {},
        nightActions: const {},
        rules: engine.rules,
      );

      final outcome = ActionResolver.resolveNight(view, {
        p1.playerId: NightAction(
          actorId: p1.playerId,
          roleId: RoleIds.mafia,
          targetPlayerId: p4.playerId,
        ),
        p2.playerId: NightAction(
          actorId: p2.playerId,
          roleId: RoleIds.doctor,
          targetPlayerId: p4.playerId,
        ),
      });

      expect(outcome.killedPlayerIds, isEmpty);
      expect(outcome.savedPlayerIds, contains(p4.playerId));
    });

    test('دکتر نمی‌تواند دو شب متوالی یک نفر را محافظت کند', () {
      final engine = GameEngine();
      final p1 = engine.joinOrReconnect(name: 'پ۱', preferHost: true).session;
      final p2 = engine.joinOrReconnect(name: 'پ۲').session;
      final p3 = engine.joinOrReconnect(name: 'پ۳').session;
      final p4 = engine.joinOrReconnect(name: 'پ۴').session;
      final p5 = engine.joinOrReconnect(name: 'پ۵').session;

      final baseView = engine.buildInternalView();
      final view = GameStateView(
        round: 2,
        phase: 'night',
        players: baseView.players,
        roleAssignments: {
          p1.playerId: RoleIds.mafia,
          p2.playerId: RoleIds.doctor,
          p3.playerId: RoleIds.villager,
          p4.playerId: RoleIds.villager,
          p5.playerId: RoleIds.villager,
        },
        doctorLastProtectedTarget: {p2.playerId: p3.playerId},
        hunterUsedShot: const {},
        nightActions: const {},
        rules: engine.rules,
      );

      final outcome = ActionResolver.resolveNight(view, {
        p1.playerId: NightAction(
          actorId: p1.playerId,
          roleId: RoleIds.mafia,
          targetPlayerId: p3.playerId,
        ),
        p2.playerId: NightAction(
          actorId: p2.playerId,
          roleId: RoleIds.doctor,
          targetPlayerId: p3.playerId, // تکراری و نامعتبر
        ),
      });

      expect(outcome.killedPlayerIds, contains(p3.playerId));
    });

    test('تساوی آرا در رای‌گیری روز منجر به حذف هیچ بازیکنی نمی‌شود', () {
      final engine = GameEngine();
      final host = engine.joinOrReconnect(name: 'میزبان', preferHost: true).session;
      final p2 = engine.joinOrReconnect(name: 'پ۲').session;
      final p3 = engine.joinOrReconnect(name: 'پ۳').session;
      final p4 = engine.joinOrReconnect(name: 'پ۴').session;
      final p5 = engine.joinOrReconnect(name: 'پ۵').session;
      final p6 = engine.joinOrReconnect(name: 'پ۶').session;

      engine.startGame(host.playerId, seed: 77);
      engine.hostAdvancePhase(host.playerId, force: true); // -> Night
      engine.hostAdvancePhase(host.playerId, force: true); // -> Day
      engine.hostAdvancePhase(host.playerId, force: true); // -> Vote

      engine.submitVote(host.playerId, p2.playerId);
      engine.submitVote(p4.playerId, p2.playerId);
      engine.submitVote(p2.playerId, p3.playerId);
      engine.submitVote(p5.playerId, p3.playerId);
      engine.submitVote(p3.playerId, null);
      engine.submitVote(p6.playerId, null);

      engine.hostAdvancePhase(host.playerId, force: true);

      expect(engine.lastVoteWasTie, isTrue);
      expect(engine.lastVoteEliminatedId, isNull);
      expect(engine.sessions.where((s) => s.isAlive).length, 6);
    });

    test('شرایط پیروزی شهروندان و مافیا به درستی تشخیص داده می‌شود', () {
      final engine = GameEngine();
      final p1 = engine.joinOrReconnect(name: 'پ۱', preferHost: true).session;
      final p2 = engine.joinOrReconnect(name: 'پ۲').session;
      final p3 = engine.joinOrReconnect(name: 'پ۳').session;
      final p4 = engine.joinOrReconnect(name: 'پ۴').session;
      final p5 = engine.joinOrReconnect(name: 'پ۵').session;

      p1.isAlive = false; // مافیا حذف شد
      final townWinView = GameStateView(
        round: 1,
        phase: 'day',
        players: engine.buildInternalView().players,
        roleAssignments: {
          p1.playerId: RoleIds.mafia,
          p2.playerId: RoleIds.doctor,
          p3.playerId: RoleIds.detective,
          p4.playerId: RoleIds.villager,
          p5.playerId: RoleIds.villager,
        },
        doctorLastProtectedTarget: const {},
        hunterUsedShot: const {},
        nightActions: const {},
        rules: engine.rules,
      );

      final resTown = WinChecker.check(townWinView);
      expect(resTown.isGameOver, isTrue);
      expect(resTown.winningTeam, RoleTeam.town);
    });
  });
}
