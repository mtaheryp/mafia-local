import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:mafia_local/core/engine/game_engine.dart';
import 'package:mafia_local/core/engine/game_phase.dart';
import 'package:mafia_local/core/roles/role_ids.dart';
import 'package:mafia_local/server/ws_gateway.dart';

void main() {
  test(
    'تست یکپارچگی ۶ کلاینت روی وب‌سوکت: هیچ کلاینتی هرگز نقش مخفی بازیکن دیگر را دریافت نمی‌کند (§6.2)',
    () {
      final engine = GameEngine();
      final gateway = WsGateway(engine);

      // ثبت اسکنر امنیتی روی تمام پیام‌های خروجی سرور
      gateway.addInspector((recipientPlayerId, env) {
        if (recipientPlayerId == null) return;
        if (engine.phase == GamePhase.lobby || engine.phase == GamePhase.gameOver) {
          return;
        }
        final raw = jsonEncode(env.toJson());
        expect(raw.contains('"roleAssignments"'), isFalse);

        // بررسی اینکه فهرست کامل نقش‌ها پیش از پایان بازی برای هیچ بازیکن زنده‌ای ارسال نشود
        if (env.type == 'stateSync') {
          expect(env.payload['revealedRoster'], isNull);
          final myRole = env.payload['mySecretRole'] as Map<String, dynamic>?;
          if (myRole != null) {
            expect(myRole['roleId'], equals(engine.getRoleForPlayer(recipientPlayerId)));
          }
        }
      });

      final clientIds = <String, String>{}; // connId -> playerId
      for (var i = 0; i < 6; i++) {
        final connId = 'conn_$i';
        gateway.registerConnection(connId, (rawJson) {
          final decoded = jsonDecode(rawJson) as Map<String, dynamic>;
          if (decoded['type'] == 'joined') {
            final p = decoded['payload'] as Map<String, dynamic>;
            clientIds[connId] = p['playerId'] as String;
          }
        });
        gateway.handleRawMessage(
          connId,
          jsonEncode({
            'type': 'join',
            'seq': 1,
            'payload': {'name': 'بازیکن ${i + 1}', 'preferHost': i == 0},
          }),
        );
      }

      // شروع بازی توسط میزبان
      gateway.handleRawMessage(
        'conn_0',
        jsonEncode({'type': 'startGame', 'seq': 2, 'payload': {}}),
      );
      // ورود به شب اول
      gateway.handleRawMessage(
        'conn_0',
        jsonEncode({'type': 'advancePhase', 'seq': 3, 'payload': {'force': true}}),
      );

      // پیدا کردن اتصال مافیا و حذف او در رای‌گیری روز برای اتمام کامل بازی
      final mafiaConn = clientIds.entries
          .firstWhere((e) => engine.getRoleForPlayer(e.value) == RoleIds.mafia)
          .key;
      final mafiaPlayerId = clientIds[mafiaConn]!;

      // پایان شب اول -> روز اول
      gateway.handleRawMessage(
        'conn_0',
        jsonEncode({'type': 'advancePhase', 'seq': 4, 'payload': {'force': true}}),
      );
      // شروع رای‌گیری
      gateway.handleRawMessage(
        'conn_0',
        jsonEncode({'type': 'advancePhase', 'seq': 5, 'payload': {'force': true}}),
      );

      for (final entry in clientIds.entries) {
        if (entry.value != mafiaPlayerId) {
          gateway.handleRawMessage(
            entry.key,
            jsonEncode({
              'type': 'submitVote',
              'seq': 6,
              'payload': {'targetPlayerId': mafiaPlayerId},
            }),
          );
        }
      }

      // پایان رای‌گیری -> حذف مافیا -> پیروزی شهروندان
      gateway.handleRawMessage(
        'conn_0',
        jsonEncode({'type': 'advancePhase', 'seq': 7, 'payload': {'force': true}}),
      );

      expect(engine.phase, equals(GamePhase.gameOver));
    },
  );
}
