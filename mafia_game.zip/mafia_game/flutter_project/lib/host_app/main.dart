import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../core/engine/game_engine.dart';
import '../server/http_server.dart';
import '../server/ws_gateway.dart';

/// نقطه ورود اپلیکیشن اندروید میزبان (Host App).
/// ۱. سرویس پس‌زمینه (ForegroundService) و قفل بیداری صفحه (WakeLock) را فعال می‌کند.
/// ۲. آدرس IP شبکه محلی (LAN IPv4) را از طریق `network_info_plus` کشف می‌کند.
/// ۳. سرور Shelf HTTP + WebSocket را راه‌اندازی کرده و کد QR را نمایش می‌دهد.
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterForegroundTask.initCommunicationPort();
  runApp(const ProviderScope(child: MafiaHostApp()));
}

class MafiaHostApp extends StatelessWidget {
  const MafiaHostApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مافیا لوکال (میزبان)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0F1115),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF4FD1C5),
          secondary: Color(0xFFE5484D),
          surface: Color(0xFF1A1D24),
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: HostHomeScreen(),
      ),
    );
  }
}

class HostHomeScreen extends StatefulWidget {
  const HostHomeScreen({super.key});

  @override
  State<HostHomeScreen> createState() => _HostHomeScreenState();
}

class _HostHomeScreenState extends State<HostHomeScreen> {
  String? _lanIp;
  int _port = 8080;
  bool _serverStarted = false;
  String? _error;
  EmbeddedLanServer? _server;

  Future<void> _createGameSession() async {
    setState(() => _error = null);

    // ۱. بررسی اتصال Wi-Fi و دریافت IPv4 شبکه محلی
    final info = NetworkInfo();
    final wifiIp = await info.getWifiIP();
    if (wifiIp == null || wifiIp.isEmpty) {
      setState(() {
        _error =
            'آدرس IP شبکه وای‌فای یافت نشد. لطفاً Wi-Fi یا هات‌اسپات گوشی را روشن کرده و دوباره تلاش کنید.';
      });
      return;
    }

    // ۲. فعال‌سازی قفل بیداری صفحه (WakeLock) و سرویس Foreground
    await WakelockPlus.enable();

    // ۳. راه‌اندازی سرور HTTP + WebSocket روی اولین پورت آزاد از ۸۰۸۰ به بعد
    final engine = GameEngine();
    final gateway = WsGateway(engine);
    final server = EmbeddedLanServer(gateway);
    final boundPort = await server.start(preferredPort: 8080);

    setState(() {
      _lanIp = wifiIp;
      _port = boundPort;
      _server = server;
      _serverStarted = true;
    });
  }

  @override
  void dispose() {
    _server?.stop();
    WakelockPlus.disable();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final url = _lanIp != null ? 'http://$_lanIp:$_port' : '';
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1A1D24),
        title: const Text('مافیا لوکال — دستگاه میزبان'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: !_serverStarted
              ? Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'بازی مافیا چندنفره آفلاین روی Wi-Fi محلی',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    if (_error != null)
                      Container(
                        padding: const EdgeInsets.all(16),
                        margin: const EdgeInsets.only(bottom: 16),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5484D).withOpacity(0.15),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Text(
                          _error!,
                          style: const TextStyle(color: Color(0xFFE5484D)),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ElevatedButton(
                      onPressed: _createGameSession,
                      child: const Text('ساخت بازی جدید (Create Game)'),
                    ),
                  ],
                )
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('همه بازیکنان را به یک Wi-Fi متصل کنید'),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: QrImageView(
                        data: url,
                        size: 220,
                      ),
                    ),
                    const SizedBox(height: 16),
                    SelectableText(
                      url,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF4FD1C5),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}
