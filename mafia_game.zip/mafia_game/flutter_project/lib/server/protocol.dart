/// پاکت استاندارد پروتکل وب‌سوکت بین کلاینت و سرور (§3.3).
/// `{ "type": "string", "seq": 0, "payload": { } }`
class ProtocolEnvelope {
  final String type;
  final int seq;
  final Map<String, dynamic> payload;

  const ProtocolEnvelope({
    required this.type,
    required this.seq,
    required this.payload,
  });

  factory ProtocolEnvelope.fromJson(Map<String, dynamic> json) {
    return ProtocolEnvelope(
      type: json['type'] as String? ?? 'unknown',
      seq: (json['seq'] as num?)?.toInt() ?? 0,
      payload: Map<String, dynamic>.from(json['payload'] as Map? ?? const {}),
    );
  }

  Map<String, dynamic> toJson() => {
        'type': type,
        'seq': seq,
        'payload': payload,
      };
}
