import 'dart:io';

import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:shelf_static/shelf_static.dart';
import 'package:shelf_web_socket/shelf_web_socket.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import 'ws_gateway.dart';

/// سرور محلی HTTP + WebSocket مبتنی بر Shelf که داخل اپلیکیشن اندروید میزبان اجرا می‌شود.
/// در صورت مشغول بودن پورت ۸۰۸۰، به صورت خودکار پورت‌های ۸۰۸۱، ۸۰۸۲ و ... را امتحان می‌کند (§2.2).
class EmbeddedLanServer {
  final WsGateway gateway;
  HttpServer? _server;
  int _boundPort = 8080;

  EmbeddedLanServer(this.gateway);

  int get boundPort => _boundPort;

  Future<int> start({
    String webAssetsPath = 'assets/web',
    int preferredPort = 8080,
  }) async {
    var connCounter = 0;

    final wsHandler = webSocketHandler((WebSocketChannel channel) {
      final connId = 'c_${++connCounter}';
      gateway.registerConnection(connId, (raw) => channel.sink.add(raw));
      channel.stream.listen(
        (msg) => gateway.handleRawMessage(connId, msg.toString()),
        onDone: () => gateway.handleDisconnect(connId),
        onError: (_) => gateway.handleDisconnect(connId),
      );
    });

    final staticHandler = createStaticHandler(
      webAssetsPath,
      defaultDocument: 'index.html',
    );

    final cascade = Cascade().add((Request req) {
      if (req.url.path == 'ws') {
        return wsHandler(req);
      }
      return Response.notFound('Not WS');
    }).add(staticHandler);

    for (var port = preferredPort; port < preferredPort + 20; port++) {
      try {
        _server = await shelf_io.serve(
          cascade.handler,
          InternetAddress.anyIPv4,
          port,
        );
        _boundPort = port;
        return port;
      } on SocketException {
        continue;
      }
    }
    throw StateError('هیچ پورت آزادی در بازه $preferredPort یافت نشد.');
  }

  Future<void> stop() async {
    await _server?.close(force: true);
    _server = null;
  }
}
