import '../core/engine/game_engine.dart';
import '../core/engine/game_phase.dart';
import '../core/roles/role_registry.dart';

/// سازنده نمای اختصاصی هر کلاینت (StateBroadcaster).
/// تضمین می‌کند که هر بازیکن فقط وضعیت عمومی + نقش مخفی خودش را دریافت کند (§2.3 و §3.3).
class StateBroadcaster {
  StateBroadcaster._();

  static Map<String, dynamic> buildClientState(
    GameEngine engine,
    String targetPlayerId,
  ) {
    final session = engine.getSessionByPlayerId(targetPlayerId);
    if (session == null) {
      throw ArgumentError('Session not found for $targetPlayerId');
    }

    final view = engine.buildInternalView();
    final myRoleId = engine.getRoleForPlayer(targetPlayerId);
    final myRoleMod = myRoleId != null ? RoleRegistry.tryGet(myRoleId) : null;

    final mySecretRole = (engine.phase != GamePhase.lobby && myRoleMod != null)
        ? {
            'roleId': myRoleMod.id,
            'displayName': myRoleMod.displayName,
            'shortDescription': myRoleMod.shortDescription,
            'team': myRoleMod.team.name,
            'hasNightAction': myRoleMod.hasNightAction,
          }
        : null;

    final myNightPrompt = (engine.phase == GamePhase.night &&
            session.isAlive &&
            myRoleMod != null)
        ? myRoleMod.buildNightActionSchema(view, targetPlayerId)?.toJson()
        : null;

    final canSeeFullRoster = engine.phase == GamePhase.gameOver ||
        (engine.phase != GamePhase.lobby &&
            !session.isAlive &&
            engine.rules.revealRolesToDeadSpectators);

    final revealedRoster = canSeeFullRoster
        ? engine.sessions.map((s) {
            final rId = engine.getRoleForPlayer(s.playerId) ?? 'villager';
            final mod = RoleRegistry.get(rId);
            return {
              'playerId': s.playerId,
              'name': s.name,
              'isAlive': s.isAlive,
              'roleId': rId,
              'roleDisplayName': mod.displayName,
              'team': mod.team.name,
            };
          }).toList()
        : null;

    return {
      'gameId': engine.gameId,
      'phase': engine.phase.name,
      'round': engine.round,
      'selfPlayerId': session.playerId,
      'selfSessionToken': session.sessionToken,
      'isHost': session.isHost,
      'players': view.players.map((p) => p.toJson()).toList(),
      'roleCountsConfig': engine.roleCountsConfig,
      'rules': engine.rules.toJson(),
      'mySecretRole': mySecretRole,
      'myNightPrompt': myNightPrompt,
      'myPrivateReports': engine
          .getPrivateReportsForPlayer(targetPlayerId)
          .map((r) => r.toJson())
          .toList(),
      'revealedRoster': revealedRoster,
    };
  }
}
