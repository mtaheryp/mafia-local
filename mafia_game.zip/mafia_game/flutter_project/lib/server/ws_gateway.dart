import 'dart:convert';

import '../core/engine/game_engine.dart';
import 'protocol.dart';
import 'state_broadcaster.dart';

typedef ClientSender = void Function(String rawJson);

/// درگاه وب‌سوکت سرور فلاتر که اتصال هر کلاینت را با توکن نشست مدیریت می‌کند.
class WsGateway {
  final GameEngine engine;
  int _seq = 0;
  final Map<String, String> _connToPlayerId = {};
  final Map<String, ClientSender> _connSenders = {};
  final List<void Function(String? recipientId, ProtocolEnvelope env)> _inspectors = [];

  WsGateway(this.engine);

  void addInspector(void Function(String? recipientId, ProtocolEnvelope env) fn) {
    _inspectors.add(fn);
  }

  void registerConnection(String connId, ClientSender sender) {
    _connSenders[connId] = sender;
  }

  void handleDisconnect(String connId) {
    _connSenders.remove(connId);
    _connToPlayerId.remove(connId);
    broadcastAll();
  }

  void handleRawMessage(String connId, String rawJson) {
    final decoded = jsonDecode(rawJson) as Map<String, dynamic>;
    final env = ProtocolEnvelope.fromJson(decoded);
    final payload = env.payload;

    try {
      switch (env.type) {
        case 'join':
          final res = engine.joinOrReconnect(
            name: payload['name'] as String? ?? 'بازیکن',
            sessionToken: payload['sessionToken'] as String?,
            preferHost: payload['preferHost'] as bool? ?? false,
          );
          _connToPlayerId[connId] = res.session.playerId;
          _sendToConn(connId, res.session.playerId, 'joined', {
            'playerId': res.session.playerId,
            'isHost': res.session.isHost,
            'sessionToken': res.session.sessionToken,
          });
          broadcastAll();
          break;
        case 'startGame':
          final pid = _connToPlayerId[connId]!;
          engine.startGame(pid);
          broadcastAll();
          break;
        case 'ready':
          final pid = _connToPlayerId[connId]!;
          engine.markReady(pid);
          broadcastAll();
          break;
        case 'submitNightAction':
          final pid = _connToPlayerId[connId]!;
          engine.submitNightAction(pid, payload['targetPlayerId'] as String?);
          broadcastAll();
          break;
        case 'submitVote':
          final pid = _connToPlayerId[connId]!;
          engine.submitVote(pid, payload['targetPlayerId'] as String?);
          broadcastAll();
          break;
        case 'advancePhase':
          final pid = _connToPlayerId[connId]!;
          engine.hostAdvancePhase(pid, force: payload['force'] as bool? ?? false);
          broadcastAll();
          break;
      }
    } catch (e) {
      _sendToConn(connId, _connToPlayerId[connId], 'error', {
        'message': e.toString(),
      });
    }
  }

  void broadcastAll() {
    for (final entry in _connToPlayerId.entries) {
      final connId = entry.key;
      final playerId = entry.value;
      final state = StateBroadcaster.buildClientState(engine, playerId);
      _sendToConn(connId, playerId, 'stateSync', state);
    }
  }

  void _sendToConn(
    String connId,
    String? recipientPlayerId,
    String type,
    Map<String, dynamic> payload,
  ) {
    final sender = _connSenders[connId];
    if (sender == null) return;
    _seq++;
    final env = ProtocolEnvelope(type: type, seq: _seq, payload: payload);
    for (final inspector in _inspectors) {
      inspector(recipientPlayerId, env);
    }
    sender(jsonEncode(env.toJson()));
  }
}
