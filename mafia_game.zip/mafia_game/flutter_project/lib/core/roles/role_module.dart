import '../engine/game_state.dart';
import '../rules/win_conditions.dart';

/// تیم‌های اصلی بازی مافیا.
enum RoleTeam {
  town,
  mafia,
  neutral,
}

/// گزینه قابل انتخاب در عملیات شب.
class SelectablePlayerOption {
  final String playerId;
  final String displayName;
  final bool disabled;
  final String? disabledReason;

  const SelectablePlayerOption({
    required this.playerId,
    required this.displayName,
    this.disabled = false,
    this.disabledReason,
  });

  Map<String, dynamic> toJson() => {
        'playerId': playerId,
        'displayName': displayName,
        'disabled': disabled,
        if (disabledReason != null) 'disabledReason': disabledReason,
      };
}

/// طرحواره (Schema) رابط کاربری عملیات شب که سرور برای هر نقش ارسال می‌کند.
class NightActionSchema {
  final String roleId;
  final String prompt;
  final bool allowSkip;
  final List<SelectablePlayerOption> selectablePlayers;
  final List<Map<String, String>>? teammates;
  final Map<String, String?>? teammateSelections;

  const NightActionSchema({
    required this.roleId,
    required this.prompt,
    required this.allowSkip,
    required this.selectablePlayers,
    this.teammates,
    this.teammateSelections,
  });

  Map<String, dynamic> toJson() => {
        'roleId': roleId,
        'prompt': prompt,
        'allowSkip': allowSkip,
        'selectablePlayers': selectablePlayers.map((e) => e.toJson()).toList(),
        if (teammates != null) 'teammates': teammates,
        if (teammateSelections != null) 'teammateSelections': teammateSelections,
      };
}

/// عملیات ثبت‌شده توسط بازیکن در شب.
class NightAction {
  final String actorId;
  final String roleId;
  final String? targetPlayerId;

  const NightAction({
    required this.actorId,
    required this.roleId,
    required this.targetPlayerId,
  });
}

/// نوع اثر شبانه در ترتیب قطعی (محافظت -> شلیک -> استعلام).
enum NightEffectType {
  protect,
  kill,
  investigate,
}

/// اثر تولیدشده توسط یک نقش در شب.
class NightEffect {
  final NightEffectType type;
  final String sourcePlayerId;
  final String roleId;
  final String targetPlayerId;

  const NightEffect({
    required this.type,
    required this.sourcePlayerId,
    required this.roleId,
    required this.targetPlayerId,
  });
}

/// زمینه اجرای عملیات شب.
class NightContext {
  final GameStateView view;
  final Map<String, NightAction> allSubmittedActions;

  const NightContext({
    required this.view,
    required this.allSubmittedActions,
  });
}

/// خروجی تجمیع‌شده حل عملیات شب.
class NightOutcome {
  final List<String> killedPlayerIds;
  final List<String> savedPlayerIds;
  final String? targetedByMafiaId;
  final Map<String, ({String targetId, String targetName, RoleTeam team})> investigations;
  final String? hunterKilledId;

  const NightOutcome({
    required this.killedPlayerIds,
    required this.savedPlayerIds,
    required this.targetedByMafiaId,
    required this.investigations,
    this.hunterKilledId,
  });
}

/// نتیجه محرمانه‌ای که فقط برای بازیگر مربوطه ارسال می‌شود (مانند نتیجه استعلام کارآگاه).
class RoleResultPayload {
  final String roleId;
  final String title;
  final String message;
  final String? targetPlayerId;
  final RoleTeam? discoveredAlignment;

  const RoleResultPayload({
    required this.roleId,
    required this.title,
    required this.message,
    this.targetPlayerId,
    this.discoveredAlignment,
  });

  Map<String, dynamic> toJson() => {
        'roleId': roleId,
        'title': title,
        'message': message,
        if (targetPlayerId != null) 'targetPlayerId': targetPlayerId,
        if (discoveredAlignment != null) 'discoveredAlignment': discoveredAlignment!.name,
      };
}

/// قرارداد انتزاعی و دقیق هر پلاگین نقش (§3.2).
/// برای افزودن نقش جدید کافی است یک کلاس با پیاده‌سازی این رابط بسازید
/// و آن را در `RoleRegistry` ثبت کنید.
abstract class RoleModule {
  /// شناسه یکتای نقش (مثلاً 'doctor')
  String get id;

  /// نام نمایشی فارسی (مثلاً 'دکتر')
  String get displayName;

  /// توضیح کوتاه نقش برای کارت افشای نقش
  String get shortDescription;

  /// تیم نقش (town, mafia, neutral)
  RoleTeam get team;

  /// آیا این نقش در فاز شب بیدار می‌شود؟
  bool get hasNightAction;

  /// آیا هر شب عمل می‌کند؟ (برای نقش‌های تک‌ضربتی مانند شکارچی false است)
  bool get actsEachNight;

  /// ساخت طرحواره انتخاب هدف در شب برای بازیکن زنده دارای این نقش
  NightActionSchema? buildNightActionSchema(GameStateView view, String actorId);

  /// اعتبارسنجی عملیات ارسال‌شده در شب
  bool validateAction(GameStateView view, String actorId, NightAction action);

  /// تولید اثر شبانه برای ترکیب در ActionResolver
  NightEffect? resolve(NightContext ctx, String actorId, NightAction action);

  /// ساخت پیام محرمانه نتیجه شب برای خود بازیکن (در صورت وجود)
  RoleResultPayload? resultForActor(
    GameStateView view,
    String actorId,
    NightOutcome outcome,
  );

  /// شرط پیروزی اختصاصی (برای نقش‌های مستقل؛ برای شهروند و مافیا null است)
  WinCondition? get customWinCondition => null;
}
