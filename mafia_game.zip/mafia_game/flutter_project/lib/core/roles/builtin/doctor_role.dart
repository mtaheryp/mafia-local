import '../../engine/game_state.dart';
import '../role_ids.dart';
import '../role_module.dart';

/// نقش دکتر (`doctor`).
/// تیم: شهروندان (Town). هر شب یک بازیکن را از خطر شلیک مافیا نجات می‌دهد.
/// قانون استاندارد: دکتر نمی‌تواند دو شب متوالی یک نفر را نجات دهد.
class DoctorRole extends RoleModule {
  @override
  String get id => RoleIds.doctor;

  @override
  String get displayName => 'دکتر';

  @override
  String get shortDescription =>
      'عضو گروه شهروندان است. هر شب یک نفر را از خطر شلیک مافیا نجات می‌دهد و نمی‌تواند دو شب پیاپی یک نفر را انتخاب کند.';

  @override
  RoleTeam get team => RoleTeam.town;

  @override
  bool get hasNightAction => true;

  @override
  bool get actsEachNight => true;

  @override
  NightActionSchema? buildNightActionSchema(GameStateView view, String actorId) {
    final actor = view.findPlayer(actorId);
    if (actor == null || !actor.isAlive) return null;

    final lastTarget = view.doctorLastProtectedTarget[actorId];

    final options = view.players.where((p) => p.isAlive).map((p) {
      final isRepeat =
          view.rules.doctorCannotProtectSameTargetTwiceInARow && lastTarget == p.id;
      final isSelfBlocked = !view.rules.doctorCanSelfProtect && p.id == actorId;
      return SelectablePlayerOption(
        playerId: p.id,
        displayName: p.id == actorId ? '${p.name} (خودتان)' : p.name,
        disabled: isRepeat || isSelfBlocked,
        disabledReason: isRepeat
            ? 'شب گذشته محافظت شده (ممنوعیت دو شب متوالی)'
            : isSelfBlocked
                ? 'محافظت از خود در قوانین غیرفعال است'
                : null,
      );
    }).toList();

    return NightActionSchema(
      roleId: id,
      prompt: 'یک بازیکن را برای محافظت در برابر شلیک امشب انتخاب کنید:',
      allowSkip: false,
      selectablePlayers: options,
    );
  }

  @override
  bool validateAction(GameStateView view, String actorId, NightAction action) {
    final actor = view.findPlayer(actorId);
    if (actor == null || !actor.isAlive) return false;
    if (action.targetPlayerId == null) return true;

    final target = view.findPlayer(action.targetPlayerId!);
    if (target == null || !target.isAlive) return false;
    if (!view.rules.doctorCanSelfProtect && target.id == actorId) return false;

    final lastTarget = view.doctorLastProtectedTarget[actorId];
    if (view.rules.doctorCannotProtectSameTargetTwiceInARow && lastTarget == target.id) {
      return false;
    }
    return true;
  }

  @override
  NightEffect? resolve(NightContext ctx, String actorId, NightAction action) {
    if (action.targetPlayerId == null) return null;
    return NightEffect(
      type: NightEffectType.protect,
      sourcePlayerId: actorId,
      roleId: id,
      targetPlayerId: action.targetPlayerId!,
    );
  }

  @override
  RoleResultPayload? resultForActor(
    GameStateView view,
    String actorId,
    NightOutcome outcome,
  ) =>
      null;
}
