import '../../engine/game_state.dart';
import '../role_ids.dart';
import '../role_module.dart';

/// نقش مافیا (`mafia`).
/// تیم: مافیا (Mafia). هر شب اعضای مافیا یک هدف را برای شلیک انتخاب می‌کنند.
class MafiaRole extends RoleModule {
  @override
  String get id => RoleIds.mafia;

  @override
  String get displayName => 'مافیا';

  @override
  String get shortDescription =>
      'عضو گروه مافیا است. هم‌تیمی‌های خود را می‌شناسد و هر شب با رای‌گیری درون‌گروهی یک نفر را برای شلیک انتخاب می‌کنند.';

  @override
  RoleTeam get team => RoleTeam.mafia;

  @override
  bool get hasNightAction => true;

  @override
  bool get actsEachNight => true;

  @override
  NightActionSchema? buildNightActionSchema(GameStateView view, String actorId) {
    final actor = view.findPlayer(actorId);
    if (actor == null || !actor.isAlive) return null;

    final teammates = view.players
        .where((p) => p.isAlive && view.roleAssignments[p.id] == RoleIds.mafia)
        .map((p) => {'playerId': p.id, 'displayName': p.name})
        .toList();

    final selections = <String, String?>{};
    for (final mate in teammates) {
      final pid = mate['playerId']!;
      if (view.nightActions.containsKey(pid)) {
        selections[pid] = view.nightActions[pid]?.targetPlayerId;
      }
    }

    final options = view.players.where((p) => p.isAlive).map((p) {
      final isTeammate = view.roleAssignments[p.id] == RoleIds.mafia;
      return SelectablePlayerOption(
        playerId: p.id,
        displayName: p.name,
        disabled: isTeammate,
        disabledReason: isTeammate ? 'هم‌تیمی مافیا' : null,
      );
    }).toList();

    return NightActionSchema(
      roleId: id,
      prompt: 'یک بازیکن را برای شلیک امشب مافیا انتخاب کنید (اکثریت آرا ملاک است؛ تساوی = عدم شلیک):',
      allowSkip: true,
      selectablePlayers: options,
      teammates: teammates,
      teammateSelections: selections,
    );
  }

  @override
  bool validateAction(GameStateView view, String actorId, NightAction action) {
    final actor = view.findPlayer(actorId);
    if (actor == null || !actor.isAlive) return false;
    if (action.targetPlayerId == null) return true;
    final target = view.findPlayer(action.targetPlayerId!);
    if (target == null || !target.isAlive) return false;
    if (view.roleAssignments[target.id] == RoleIds.mafia) return false;
    return true;
  }

  @override
  NightEffect? resolve(NightContext ctx, String actorId, NightAction action) {
    if (action.targetPlayerId == null) return null;
    return NightEffect(
      type: NightEffectType.kill,
      sourcePlayerId: actorId,
      roleId: id,
      targetPlayerId: action.targetPlayerId!,
    );
  }

  @override
  RoleResultPayload? resultForActor(
    GameStateView view,
    String actorId,
    NightOutcome outcome,
  ) =>
      null;
}
