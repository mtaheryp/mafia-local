import '../../engine/game_state.dart';
import '../role_ids.dart';
import '../role_module.dart';

/// نقش شهروند ساده (`villager`).
/// تیم: شهروندان (Town). بدون عملیات شبانه.
class VillagerRole extends RoleModule {
  @override
  String get id => RoleIds.villager;

  @override
  String get displayName => 'شهروند ساده';

  @override
  String get shortDescription =>
      'عضو گروه شهروندان است. در طول شب عملیاتی ندارد و در روز با استدلال و رای‌گیری به شناسایی مافیا کمک می‌کند.';

  @override
  RoleTeam get team => RoleTeam.town;

  @override
  bool get hasNightAction => false;

  @override
  bool get actsEachNight => false;

  @override
  NightActionSchema? buildNightActionSchema(GameStateView view, String actorId) => null;

  @override
  bool validateAction(GameStateView view, String actorId, NightAction action) => false;

  @override
  NightEffect? resolve(NightContext ctx, String actorId, NightAction action) => null;

  @override
  RoleResultPayload? resultForActor(
    GameStateView view,
    String actorId,
    NightOutcome outcome,
  ) =>
      null;
}
