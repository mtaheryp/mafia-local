import '../../engine/game_state.dart';
import '../role_ids.dart';
import '../role_module.dart';

/// نقش تک‌تیرانداز / شکارچی (`hunter`) — پلاگین پنجم (به صورت پیش‌فرض ۰ در چیدمان).
/// نمونه عملی توسعه بدون تغییر در موتور یا رابط کاربری (§3.5 و §10).
class HunterRole extends RoleModule {
  @override
  String get id => RoleIds.hunter;

  @override
  String get displayName => 'تک‌تیرانداز (شکارچی)';

  @override
  String get shortDescription =>
      'عضو گروه شهروندان با ۱ تیر در کل بازی. در یکی از شب‌ها می‌تواند به مظنون خود شلیک کند.';

  @override
  RoleTeam get team => RoleTeam.town;

  @override
  bool get hasNightAction => true;

  @override
  bool get actsEachNight => false;

  @override
  NightActionSchema? buildNightActionSchema(GameStateView view, String actorId) {
    final actor = view.findPlayer(actorId);
    if (actor == null || !actor.isAlive) return null;
    if (view.hunterUsedShot[actorId] == true) return null;

    final options = view.players.where((p) => p.isAlive).map((p) {
      final isSelf = p.id == actorId;
      return SelectablePlayerOption(
        playerId: p.id,
        displayName: p.name,
        disabled: isSelf,
        disabledReason: isSelf ? 'نمی‌توانید به خودتان شلیک کنید' : null,
      );
    }).toList();

    return NightActionSchema(
      roleId: id,
      prompt: 'شما ۱ تیر در کل بازی دارید. می‌توانید امشب شلیک کنید یا تیر خود را نگه دارید:',
      allowSkip: true,
      selectablePlayers: options,
    );
  }

  @override
  bool validateAction(GameStateView view, String actorId, NightAction action) {
    final actor = view.findPlayer(actorId);
    if (actor == null || !actor.isAlive) return false;
    if (view.hunterUsedShot[actorId] == true) return false;
    if (action.targetPlayerId == null) return true;
    if (action.targetPlayerId == actorId) return false;
    final target = view.findPlayer(action.targetPlayerId!);
    return target != null && target.isAlive;
  }

  @override
  NightEffect? resolve(NightContext ctx, String actorId, NightAction action) {
    if (action.targetPlayerId == null) return null;
    return NightEffect(
      type: NightEffectType.kill,
      sourcePlayerId: actorId,
      roleId: id,
      targetPlayerId: action.targetPlayerId!,
    );
  }

  @override
  RoleResultPayload? resultForActor(
    GameStateView view,
    String actorId,
    NightOutcome outcome,
  ) {
    if (outcome.hunterKilledId == null) return null;
    return RoleResultPayload(
      roleId: id,
      title: 'شلیک تک‌تیرانداز انجام شد',
      message: 'تیر شما شلیک شد. نتیجه در گزارش صبحگاهی شهر اعلام می‌شود.',
      targetPlayerId: outcome.hunterKilledId,
    );
  }
}
