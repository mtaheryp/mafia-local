import '../../engine/game_state.dart';
import '../role_ids.dart';
import '../role_module.dart';

/// نقش کارآگاه (`detective`).
/// تیم: شهروندان (Town). هر شب قطب یک بازیکن (شهروند یا مافیا) را بدون افشای نقش دقیق دریافت می‌کند.
class DetectiveRole extends RoleModule {
  @override
  String get id => RoleIds.detective;

  @override
  String get displayName => 'کارآگاه';

  @override
  String get shortDescription =>
      'عضو گروه شهروندان است. هر شب استعلام یک بازیکن را می‌گیرد و قطب او (شهروند یا مافیا) را به صورت محرمانه دریافت می‌کند.';

  @override
  RoleTeam get team => RoleTeam.town;

  @override
  bool get hasNightAction => true;

  @override
  bool get actsEachNight => true;

  @override
  NightActionSchema? buildNightActionSchema(GameStateView view, String actorId) {
    final actor = view.findPlayer(actorId);
    if (actor == null || !actor.isAlive) return null;

    final options = view.players.where((p) => p.isAlive).map((p) {
      final isSelf = p.id == actorId;
      return SelectablePlayerOption(
        playerId: p.id,
        displayName: p.name,
        disabled: isSelf,
        disabledReason: isSelf ? 'نمی‌توانید از خودتان استعلام بگیرید' : null,
      );
    }).toList();

    return NightActionSchema(
      roleId: id,
      prompt: 'یک بازیکن را برای استعلام قطب (شهروند / مافیا) انتخاب کنید:',
      allowSkip: false,
      selectablePlayers: options,
    );
  }

  @override
  bool validateAction(GameStateView view, String actorId, NightAction action) {
    final actor = view.findPlayer(actorId);
    if (actor == null || !actor.isAlive) return false;
    if (action.targetPlayerId == null) return true;
    if (action.targetPlayerId == actorId) return false;
    final target = view.findPlayer(action.targetPlayerId!);
    return target != null && target.isAlive;
  }

  @override
  NightEffect? resolve(NightContext ctx, String actorId, NightAction action) {
    if (action.targetPlayerId == null) return null;
    return NightEffect(
      type: NightEffectType.investigate,
      sourcePlayerId: actorId,
      roleId: id,
      targetPlayerId: action.targetPlayerId!,
    );
  }

  @override
  RoleResultPayload? resultForActor(
    GameStateView view,
    String actorId,
    NightOutcome outcome,
  ) {
    final inv = outcome.investigations[actorId];
    if (inv == null) return null;
    final isMafia = inv.team == RoleTeam.mafia;
    return RoleResultPayload(
      roleId: id,
      title: 'نتیجه استعلام کارآگاه (${inv.targetName})',
      message: isMafia
          ? 'استعلام «${inv.targetName}» مثبت است: او عضو گروه مافیا است!'
          : 'استعلام «${inv.targetName}» منفی است: او در گروه شهروندان قرار دارد.',
      targetPlayerId: inv.targetId,
      discoveredAlignment: inv.team,
    );
  }
}
