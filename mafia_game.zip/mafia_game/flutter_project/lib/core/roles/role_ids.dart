/// شناسه‌های ثابت نقش‌های بازی مافیا لوکال.
class RoleIds {
  RoleIds._();

  static const String villager = 'villager';
  static const String mafia = 'mafia';
  static const String doctor = 'doctor';
  static const String detective = 'detective';
  static const String hunter = 'hunter';
}
