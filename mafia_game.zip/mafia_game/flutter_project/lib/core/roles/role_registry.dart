import 'builtin/detective_role.dart';
import 'builtin/doctor_role.dart';
import 'builtin/hunter_role.dart';
import 'builtin/mafia_role.dart';
import 'builtin/villager_role.dart';
import 'role_ids.dart';
import 'role_module.dart';

/// رجیستری مرکزی نقش‌ها.
/// افزودن یک نقش جدید فقط به ۱ خط `RoleRegistry.register(...)` در این فایل نیاز دارد.
class RoleRegistry {
  RoleRegistry._();

  static final Map<String, RoleModule> _modules = {
    RoleIds.mafia: MafiaRole(),
    RoleIds.doctor: DoctorRole(),
    RoleIds.detective: DetectiveRole(),
    RoleIds.hunter: HunterRole(),
    RoleIds.villager: VillagerRole(),
  };

  /// ثبت یک پلاگین نقش جدید
  static void register(RoleModule module) {
    _modules[module.id] = module;
  }

  /// دریافت ماژول نقش با شناسه
  static RoleModule get(String id) {
    final module = _modules[id];
    if (module == null) {
      throw ArgumentError('RoleModule not found for id: $id');
    }
    return module;
  }

  static RoleModule? tryGet(String id) => _modules[id];

  static List<RoleModule> getAll() => _modules.values.toList(growable: false);

  static List<RoleModule> getConfigurableNonVillagerRoles() =>
      _modules.values.where((r) => r.id != RoleIds.villager).toList(growable: false);
}
