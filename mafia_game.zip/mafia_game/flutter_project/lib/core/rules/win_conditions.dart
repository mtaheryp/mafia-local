import '../engine/game_state.dart';
import '../roles/role_module.dart';
import '../roles/role_registry.dart';

/// نتیجه بررسی شرط پیروزی.
class WinConditionResult {
  final bool isGameOver;
  final RoleTeam? winningTeam;
  final String reason;

  const WinConditionResult({
    required this.isGameOver,
    this.winningTeam,
    this.reason = '',
  });
}

/// رابط شرط پیروزی قابل اتصال (Pluggable WinCondition).
abstract class WinCondition {
  String get id;
  int get priority;
  WinConditionResult? evaluate(GameStateView view);
}

/// شرط پیروزی شهروندان: حذف تمام اعضای مافیا.
class TownWinCondition implements WinCondition {
  @override
  String get id => 'town_eliminates_all_mafia';

  @override
  int get priority => 10;

  @override
  WinConditionResult? evaluate(GameStateView view) {
    final alive = view.players.where((p) => p.isAlive).toList();
    if (alive.isEmpty) {
      return const WinConditionResult(
        isGameOver: true,
        winningTeam: RoleTeam.town,
        reason: 'تمام بازیکنان خارج شدند.',
      );
    }

    var aliveMafia = 0;
    for (final p in alive) {
      final roleId = view.roleAssignments[p.id];
      if (roleId != null && RoleRegistry.tryGet(roleId)?.team == RoleTeam.mafia) {
        aliveMafia++;
      }
    }

    if (aliveMafia == 0) {
      return const WinConditionResult(
        isGameOver: true,
        winningTeam: RoleTeam.town,
        reason: 'تمام اعضای مافیا از شهر خارج شدند. شهروندان پیروز شدند!',
      );
    }
    return null;
  }
}

/// شرط پیروزی مافیا: تعداد مافیای زنده مساوی یا بیشتر از شهروندان زنده.
class MafiaWinCondition implements WinCondition {
  @override
  String get id => 'mafia_parity_or_majority';

  @override
  int get priority => 20;

  @override
  WinConditionResult? evaluate(GameStateView view) {
    final alive = view.players.where((p) => p.isAlive).toList();
    if (alive.isEmpty) return null;

    var aliveMafia = 0;
    var aliveNonMafia = 0;
    for (final p in alive) {
      final roleId = view.roleAssignments[p.id];
      if (roleId != null && RoleRegistry.tryGet(roleId)?.team == RoleTeam.mafia) {
        aliveMafia++;
      } else {
        aliveNonMafia++;
      }
    }

    if (aliveMafia > 0 && aliveMafia >= aliveNonMafia) {
      return WinConditionResult(
        isGameOver: true,
        winningTeam: RoleTeam.mafia,
        reason:
            'تعداد مافیای زنده ($aliveMafia) با شهروندان زنده ($aliveNonMafia) برابر یا بیشتر شد.',
      );
    }
    return null;
  }
}
