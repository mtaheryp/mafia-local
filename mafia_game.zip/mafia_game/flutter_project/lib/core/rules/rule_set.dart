/// قوانین قابل تنظیم بازی مافیا لوکال (§3.4).
class RuleSet {
  final bool revealRoleOnDeath;
  final bool doctorCanSelfProtect;
  final bool doctorCannotProtectSameTargetTwiceInARow;
  final bool revealRolesToDeadSpectators;
  final bool enableLobbyChat;
  final bool enableDayChat;
  final int discussionTimerSeconds;
  final String mafiaTieRule; // 'no_kill' | 'last_selection'
  final int minPlayersToStart;

  const RuleSet({
    this.revealRoleOnDeath = true,
    this.doctorCanSelfProtect = true,
    this.doctorCannotProtectSameTargetTwiceInARow = true,
    this.revealRolesToDeadSpectators = false,
    this.enableLobbyChat = true,
    this.enableDayChat = false,
    this.discussionTimerSeconds = 120,
    this.mafiaTieRule = 'no_kill',
    this.minPlayersToStart = 5,
  });

  Map<String, dynamic> toJson() => {
        'revealRoleOnDeath': revealRoleOnDeath,
        'doctorCanSelfProtect': doctorCanSelfProtect,
        'doctorCannotProtectSameTargetTwiceInARow':
            doctorCannotProtectSameTargetTwiceInARow,
        'revealRolesToDeadSpectators': revealRolesToDeadSpectators,
        'enableLobbyChat': enableLobbyChat,
        'enableDayChat': enableDayChat,
        'discussionTimerSeconds': discussionTimerSeconds,
        'mafiaTieRule': mafiaTieRule,
        'minPlayersToStart': minPlayersToStart,
      };
}
