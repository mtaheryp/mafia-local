import 'dart:math';

import '../roles/role_ids.dart';
import '../roles/role_module.dart';
import '../roles/role_registry.dart';
import '../rules/rule_set.dart';
import '../session/session.dart';
import 'action_resolver.dart';
import 'game_phase.dart';
import 'game_state.dart';
import 'win_checker.dart';

/// موتور اصلی بازی مافیا لوکال (Pure Dart — بدون هیچ وابستگی به Flutter یا Shelf).
class GameEngine {
  final String gameId;
  GamePhase _phase = GamePhase.lobby;
  int _round = 0;
  int _seed = 0;
  RuleSet _rules = const RuleSet();
  final Map<String, PlayerSession> _sessions = {};
  final Map<String, String> _tokenToPlayerId = {};
  Map<String, int> _roleCountsConfig = {
    RoleIds.mafia: 1,
    RoleIds.doctor: 1,
    RoleIds.detective: 1,
    RoleIds.hunter: 0,
    RoleIds.villager: 3,
  };
  final Map<String, String> _roleAssignments = {};
  final Map<String, String?> _doctorLastProtectedTarget = {};
  final Map<String, bool> _hunterUsedShot = {};
  final Map<String, NightAction> _nightActions = {};
  final Map<String, List<RoleResultPayload>> _privateReports = {};
  final Map<String, String?> _votes = {};
  List<String> _lastKilledNames = [];
  String? _lastVoteEliminatedId;
  bool _lastVoteWasTie = false;
  RoleTeam? _winningTeam;
  String _winReason = '';

  GameEngine({this.gameId = 'mafia-lan'});

  GamePhase get phase => _phase;
  int get round => _round;
  int get seed => _seed;
  RuleSet get rules => _rules;
  Map<String, int> get roleCountsConfig => Map.unmodifiable(_roleCountsConfig);
  List<PlayerSession> get sessions => _sessions.values.toList(growable: false);
  List<String> get lastKilledNames => List.unmodifiable(_lastKilledNames);
  String? get lastVoteEliminatedId => _lastVoteEliminatedId;
  bool get lastVoteWasTie => _lastVoteWasTie;
  RoleTeam? get winningTeam => _winningTeam;
  String get winReason => _winReason;

  PlayerSession? getSessionByPlayerId(String id) => _sessions[id];
  PlayerSession? getSessionByToken(String token) {
    final pid = _tokenToPlayerId[token];
    return pid != null ? _sessions[pid] : null;
  }

  String? getRoleForPlayer(String playerId) => _roleAssignments[playerId];
  List<RoleResultPayload> getPrivateReportsForPlayer(String playerId) =>
      List.unmodifiable(_privateReports[playerId] ?? const []);

  /// ورود بازیکن جدید یا اتصال مجدد با توکن نشست قبلی.
  /// نام‌های تکراری به صورت خودکار با #2، #3 متمایز می‌شوند (§5).
  ({PlayerSession session, bool reconnected}) joinOrReconnect({
    required String name,
    String? sessionToken,
    bool preferHost = false,
  }) {
    if (sessionToken != null && _tokenToPlayerId.containsKey(sessionToken)) {
      final pid = _tokenToPlayerId[sessionToken]!;
      final existing = _sessions[pid]!;
      existing.isConnected = true;
      return (session: existing, reconnected: true);
    }

    if (_phase != GamePhase.lobby) {
      throw StateError('بازی در جریان است؛ ورود بازیکن جدید ممکن نیست.');
    }

    final baseName = name.trim().isEmpty ? 'بازیکن' : name.trim();
    final usedNames = _sessions.values.map((s) => s.name).toSet();
    var finalName = baseName;
    var suffix = 2;
    while (usedNames.contains(finalName)) {
      finalName = '$baseName #$suffix';
      suffix++;
    }

    final hasHost = _sessions.values.any((s) => s.isHost);
    final isHost = !hasHost && (preferHost || _sessions.isEmpty);
    final now = DateTime.now().microsecondsSinceEpoch;
    final playerId = 'p_${_sessions.length + 1}_$now';
    final token = 'tok_${_sessions.length + 1}_$now';

    final session = PlayerSession(
      playerId: playerId,
      sessionToken: token,
      name: finalName,
      isHost: isHost,
      joinedAt: now,
    );
    _sessions[playerId] = session;
    _tokenToPlayerId[token] = playerId;
    return (session: session, reconnected: false);
  }

  /// پیکربندی تعداد نقش‌ها توسط میزبان.
  void configureRoles(String hostPlayerId, Map<String, int> counts, {RuleSet? rules}) {
    _assertHost(hostPlayerId);
    if (rules != null) _rules = rules;
    final next = <String, int>{};
    var sumOthers = 0;
    for (final role in RoleRegistry.getConfigurableNonVillagerRoles()) {
      final c = max(0, counts[role.id] ?? 0);
      next[role.id] = c;
      sumOthers += c;
    }
    next[RoleIds.villager] = max(0, _sessions.length - sumOthers);
    _roleCountsConfig = next;
  }

  /// شروع بازی و توزیع تصادفی یکنواخت نقش‌ها با Seed مشخص.
  void startGame(String hostPlayerId, {int? seed}) {
    _assertHost(hostPlayerId);
    if (_sessions.length < _rules.minPlayersToStart) {
      throw StateError('حداقل ${_rules.minPlayersToStart} بازیکن نیاز است.');
    }

    final pool = <String>[];
    for (final role in RoleRegistry.getConfigurableNonVillagerRoles()) {
      final count = _roleCountsConfig[role.id] ?? 0;
      for (var i = 0; i < count; i++) {
        pool.add(role.id);
      }
    }
    while (pool.length < _sessions.length) {
      pool.add(RoleIds.villager);
    }

    _seed = seed ?? Random().nextInt(0x7fffffff);
    pool.shuffle(Random(_seed));

    _roleAssignments.clear();
    _doctorLastProtectedTarget.clear();
    _hunterUsedShot.clear();
    _nightActions.clear();
    _privateReports.clear();
    _votes.clear();
    _round = 1;

    final list = sessions;
    for (var i = 0; i < list.length; i++) {
      final s = list[i];
      s.isAlive = true;
      s.isReady = false;
      _roleAssignments[s.playerId] = pool[i];
      _privateReports[s.playerId] = [];
    }

    _phase = GamePhase.roleReveal;
  }

  void markReady(String playerId) {
    _sessions[playerId]?.isReady = true;
  }

  void submitNightAction(String actorId, String? targetPlayerId) {
    if (_phase != GamePhase.night) throw StateError('فاز فعلی شب نیست.');
    final roleId = _roleAssignments[actorId];
    if (roleId == null) throw StateError('نقش یافت نشد.');
    final module = RoleRegistry.get(roleId);
    final view = buildInternalView();
    final action = NightAction(
      actorId: actorId,
      roleId: roleId,
      targetPlayerId: targetPlayerId,
    );
    if (!module.validateAction(view, actorId, action)) {
      throw ArgumentError('عملیات شب نامعتبر است.');
    }
    _nightActions[actorId] = action;
  }

  void submitVote(String voterId, String? targetPlayerId) {
    if (_phase != GamePhase.vote) throw StateError('فاز فعلی رای‌گیری نیست.');
    final voter = _sessions[voterId];
    if (voter == null || !voter.isAlive) throw StateError('رای‌دهنده زنده نیست.');
    _votes[voterId] = targetPlayerId;
  }

  void hostAdvancePhase(String hostPlayerId, {bool force = false}) {
    _assertHost(hostPlayerId);
    switch (_phase) {
      case GamePhase.roleReveal:
        _phase = GamePhase.night;
        _nightActions.clear();
        break;
      case GamePhase.night:
        _resolveNight();
        break;
      case GamePhase.day:
        _phase = GamePhase.vote;
        _votes.clear();
        break;
      case GamePhase.vote:
        _resolveVote();
        break;
      case GamePhase.lobby:
      case GamePhase.gameOver:
        break;
    }
  }

  void _resolveNight() {
    final view = buildInternalView();
    final outcome = ActionResolver.resolveNight(view, _nightActions);

    for (final entry in _nightActions.entries) {
      if (entry.value.roleId == RoleIds.doctor) {
        _doctorLastProtectedTarget[entry.key] = entry.value.targetPlayerId;
      }
      if (entry.value.roleId == RoleIds.hunter && entry.value.targetPlayerId != null) {
        _hunterUsedShot[entry.key] = true;
      }
    }

    for (final s in sessions) {
      if (!s.isAlive) continue;
      final rId = _roleAssignments[s.playerId]!;
      final report = RoleRegistry.get(rId).resultForActor(view, s.playerId, outcome);
      if (report != null) {
        _privateReports[s.playerId]!.add(report);
      }
    }

    _lastKilledNames = [];
    for (final victimId in outcome.killedPlayerIds) {
      final victim = _sessions[victimId];
      if (victim != null && victim.isAlive) {
        victim.isAlive = false;
        _lastKilledNames.add(victim.name);
      }
    }

    final win = WinChecker.check(buildInternalView());
    if (win.isGameOver) {
      _phase = GamePhase.gameOver;
      _winningTeam = win.winningTeam;
      _winReason = win.reason;
    } else {
      _phase = GamePhase.day;
    }
  }

  void _resolveVote() {
    final tally = <String, int>{};
    for (final s in sessions.where((p) => p.isAlive)) {
      if (!_votes.containsKey(s.playerId)) continue;
      final key = _votes[s.playerId] ?? 'SKIP';
      tally[key] = (tally[key] ?? 0) + 1;
    }

    var maxVotes = 0;
    var topKeys = <String>[];
    tally.forEach((k, v) {
      if (v > maxVotes) {
        maxVotes = v;
        topKeys = [k];
      } else if (v == maxVotes) {
        topKeys.add(k);
      }
    });

    if (topKeys.length == 1 && topKeys.first != 'SKIP' && maxVotes > 0) {
      _lastVoteEliminatedId = topKeys.first;
      _lastVoteWasTie = false;
      _sessions[_lastVoteEliminatedId]?.isAlive = false;
    } else {
      _lastVoteEliminatedId = null;
      _lastVoteWasTie = true;
    }

    final win = WinChecker.check(buildInternalView());
    if (win.isGameOver) {
      _phase = GamePhase.gameOver;
      _winningTeam = win.winningTeam;
      _winReason = win.reason;
    } else {
      _round++;
      _phase = GamePhase.night;
      _nightActions.clear();
    }
  }

  GameStateView buildInternalView() {
    final publicPlayers = sessions.map((s) {
      final rId = _roleAssignments[s.playerId];
      final mod = rId != null ? RoleRegistry.tryGet(rId) : null;
      final reveal = _phase == GamePhase.gameOver || (!s.isAlive && _rules.revealRoleOnDeath);
      return PublicPlayerView(
        id: s.playerId,
        name: s.name,
        isAlive: s.isAlive,
        isConnected: s.isConnected,
        isHost: s.isHost,
        isReady: s.isReady,
        revealedRoleId: reveal ? rId : null,
        revealedRoleName: reveal ? mod?.displayName : null,
        revealedTeam: reveal ? mod?.team : null,
      );
    }).toList();

    return GameStateView(
      round: _round,
      phase: _phase.name,
      players: publicPlayers,
      roleAssignments: Map.unmodifiable(_roleAssignments),
      doctorLastProtectedTarget: Map.unmodifiable(_doctorLastProtectedTarget),
      hunterUsedShot: Map.unmodifiable(_hunterUsedShot),
      nightActions: Map.unmodifiable(_nightActions),
      rules: _rules,
    );
  }

  void _assertHost(String playerId) {
    final s = _sessions[playerId];
    if (s == null || !s.isHost) {
      throw StateError('فقط میزبان مجاز به انجام این عملیات است.');
    }
  }
}
