import '../roles/role_registry.dart';
import '../rules/win_conditions.dart';
import 'game_state.dart';

/// بررسی‌کننده شرایط پیروزی بر اساس اولویت.
class WinChecker {
  WinChecker._();

  static WinConditionResult check(GameStateView view) {
    final conditions = <WinCondition>[
      TownWinCondition(),
      MafiaWinCondition(),
      for (final r in RoleRegistry.getAll())
        if (r.customWinCondition != null) r.customWinCondition!,
    ]..sort((a, b) => a.priority.compareTo(b.priority));

    for (final c in conditions) {
      final res = c.evaluate(view);
      if (res != null && res.isGameOver) {
        return res;
      }
    }
    return const WinConditionResult(isGameOver: false);
  }
}
