import '../roles/role_module.dart';
import '../rules/rule_set.dart';

/// نمای عمومی یک بازیکن که برای تمام کلاینت‌ها قابل مشاهده است.
class PublicPlayerView {
  final String id;
  final String name;
  final bool isAlive;
  final bool isConnected;
  final bool isHost;
  final bool isReady;
  final String? revealedRoleId;
  final String? revealedRoleName;
  final RoleTeam? revealedTeam;

  const PublicPlayerView({
    required this.id,
    required this.name,
    required this.isAlive,
    required this.isConnected,
    required this.isHost,
    required this.isReady,
    this.revealedRoleId,
    this.revealedRoleName,
    this.revealedTeam,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'isAlive': isAlive,
        'isConnected': isConnected,
        'isHost': isHost,
        'isReady': isReady,
        if (revealedRoleId != null) 'revealedRoleId': revealedRoleId,
        if (revealedRoleName != null) 'revealedRoleName': revealedRoleName,
        if (revealedTeam != null) 'revealedTeam': revealedTeam!.name,
      };
}

/// نمای داخلی وضعیت بازی برای استفاده در ماژول‌های نقش و ActionResolver.
/// هشدار امنیتی: این کلاس حاوی `roleAssignments` است و هرگز نباید مستقیماً به کلاینت ارسال شود!
class GameStateView {
  final int round;
  final String phase;
  final List<PublicPlayerView> players;
  final Map<String, String> roleAssignments;
  final Map<String, String?> doctorLastProtectedTarget;
  final Map<String, bool> hunterUsedShot;
  final Map<String, NightAction> nightActions;
  final RuleSet rules;

  const GameStateView({
    required this.round,
    required this.phase,
    required this.players,
    required this.roleAssignments,
    required this.doctorLastProtectedTarget,
    required this.hunterUsedShot,
    required this.nightActions,
    required this.rules,
  });

  PublicPlayerView? findPlayer(String id) {
    for (final p in players) {
      if (p.id == id) return p;
    }
    return null;
  }
}
