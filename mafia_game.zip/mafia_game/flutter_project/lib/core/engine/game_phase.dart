/// فازهای ترتیبی بازی مافیا لوکال.
enum GamePhase {
  lobby,
  roleReveal,
  night,
  day,
  vote,
  gameOver,
}
