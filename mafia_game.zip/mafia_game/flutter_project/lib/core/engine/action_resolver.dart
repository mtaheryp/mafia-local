import '../roles/role_ids.dart';
import '../roles/role_module.dart';
import '../roles/role_registry.dart';
import 'game_state.dart';

/// حل‌کننده قطعی عملیات شب به ترتیب:
/// 1. محافظت (Protect)
/// 2. شلیک / قتل (Kill)
/// 3. استعلام (Investigate)
class ActionResolver {
  ActionResolver._();

  static NightOutcome resolveNight(
    GameStateView view,
    Map<String, NightAction> submittedActions,
  ) {
    final ctx = NightContext(view: view, allSubmittedActions: submittedActions);
    final rawEffects = <NightEffect>[];

    for (final entry in submittedActions.entries) {
      final actorId = entry.key;
      final action = entry.value;
      final player = view.findPlayer(actorId);
      if (player == null || !player.isAlive) continue;

      final roleId = view.roleAssignments[actorId];
      if (roleId == null) continue;
      final module = RoleRegistry.tryGet(roleId);
      if (module == null || !module.hasNightAction) continue;
      if (!module.validateAction(view, actorId, action)) continue;

      final eff = module.resolve(ctx, actorId, action);
      if (eff != null) {
        rawEffects.add(eff);
      }
    }

    // ۱. جمع‌آوری اهداف محافظت‌شده توسط دکتر
    final protectedIds = rawEffects
        .where((e) => e.type == NightEffectType.protect)
        .map((e) => e.targetPlayerId)
        .toSet();

    // ۲. شمارش آرای شلیک مافیا (تساوی = عدم شلیک طبق قانون پیش‌فرض)
    final mafiaKills = rawEffects
        .where((e) => e.type == NightEffectType.kill && e.roleId == RoleIds.mafia)
        .toList();

    String? targetedByMafiaId;
    if (mafiaKills.isNotEmpty) {
      final tally = <String, int>{};
      String? lastTarget;
      for (final eff in mafiaKills) {
        tally[eff.targetPlayerId] = (tally[eff.targetPlayerId] ?? 0) + 1;
        lastTarget = eff.targetPlayerId;
      }

      var maxVotes = 0;
      var topCandidates = <String>[];
      tally.forEach((candidateId, count) {
        if (count > maxVotes) {
          maxVotes = count;
          topCandidates = [candidateId];
        } else if (count == maxVotes) {
          topCandidates.add(candidateId);
        }
      });

      if (topCandidates.length == 1) {
        targetedByMafiaId = topCandidates.first;
      } else if (topCandidates.length > 1 && view.rules.mafiaTieRule == 'last_selection') {
        targetedByMafiaId = lastTarget;
      }
    }

    final killedSet = <String>{};
    final savedSet = <String>{};

    if (targetedByMafiaId != null) {
      if (protectedIds.contains(targetedByMafiaId)) {
        savedSet.add(targetedByMafiaId);
      } else {
        killedSet.add(targetedByMafiaId);
      }
    }

    // شلیک سایر نقش‌های شبانه (مانند تک‌تیرانداز / شکارچی)
    String? hunterKilledId;
    for (final eff in rawEffects.where(
      (e) => e.type == NightEffectType.kill && e.roleId != RoleIds.mafia,
    )) {
      hunterKilledId = eff.targetPlayerId;
      if (protectedIds.contains(eff.targetPlayerId)) {
        savedSet.add(eff.targetPlayerId);
      } else {
        killedSet.add(eff.targetPlayerId);
      }
    }

    // ۳. پردازش استعلام‌های کارآگاه
    final investigations =
        <String, ({String targetId, String targetName, RoleTeam team})>{};
    for (final eff in rawEffects.where((e) => e.type == NightEffectType.investigate)) {
      final targetPlayer = view.findPlayer(eff.targetPlayerId);
      final targetRoleId = view.roleAssignments[eff.targetPlayerId];
      final targetRole = targetRoleId != null ? RoleRegistry.tryGet(targetRoleId) : null;
      if (targetPlayer != null && targetRole != null) {
        investigations[eff.sourcePlayerId] = (
          targetId: targetPlayer.id,
          targetName: targetPlayer.name,
          team: targetRole.team,
        );
      }
    }

    return NightOutcome(
      killedPlayerIds: killedSet.toList(),
      savedPlayerIds: savedSet.toList(),
      targetedByMafiaId: targetedByMafiaId,
      investigations: investigations,
      hunterKilledId: hunterKilledId,
    );
  }
}
