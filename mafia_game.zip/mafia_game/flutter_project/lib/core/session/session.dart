/// نشست بازیکن که با توکن یکتا برای اتصال مجدد (Reconnect) نگهداری می‌شود.
class PlayerSession {
  final String playerId;
  final String sessionToken;
  final String name;
  final bool isHost;
  bool isConnected;
  bool isAlive;
  bool isReady;
  final int joinedAt;

  PlayerSession({
    required this.playerId,
    required this.sessionToken,
    required this.name,
    required this.isHost,
    this.isConnected = true,
    this.isAlive = true,
    this.isReady = false,
    required this.joinedAt,
  });
}
