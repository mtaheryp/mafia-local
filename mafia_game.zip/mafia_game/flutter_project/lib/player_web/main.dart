import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

/// نقطه ورود کلاینت وب بازیکنان (Player Web App).
/// این برنامه با `flutter build web` کامپایل شده و داخل `assets/web/` میزبان قرار می‌گیرد.
void main() {
  runApp(const ProviderScope(child: MafiaPlayerWebApp()));
}

class MafiaPlayerWebApp extends StatelessWidget {
  const MafiaPlayerWebApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مافیا لوکال — بازیکن',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0F1115),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF4FD1C5),
          secondary: Color(0xFFE5484D),
          surface: Color(0xFF1A1D24),
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: PlayerJoinAndGameScreen(),
      ),
    );
  }
}

class PlayerJoinAndGameScreen extends StatefulWidget {
  const PlayerJoinAndGameScreen({super.key});

  @override
  State<PlayerJoinAndGameScreen> createState() => _PlayerJoinAndGameScreenState();
}

class _PlayerJoinAndGameScreenState extends State<PlayerJoinAndGameScreen> {
  final TextEditingController _nameCtrl = TextEditingController();
  WebSocketChannel? _channel;
  Map<String, dynamic>? _state;

  void _connectAndJoin() {
    final host = Uri.base.host.isEmpty ? 'localhost' : Uri.base.host;
    final port = Uri.base.hasPort ? Uri.base.port : 8080;
    final wsUrl = Uri.parse('ws://$host:$port/ws');
    _channel = WebSocketChannel.connect(wsUrl);
    _channel!.stream.listen((raw) {
      final env = jsonDecode(raw.toString()) as Map<String, dynamic>;
      if (env['type'] == 'stateSync') {
        setState(() {
          _state = Map<String, dynamic>.from(env['payload'] as Map);
        });
      }
    });
    _channel!.sink.add(jsonEncode({
      'type': 'join',
      'seq': 1,
      'payload': {'name': _nameCtrl.text.trim()},
    }));
  }

  @override
  Widget build(BuildContext context) {
    if (_state == null) {
      return Scaffold(
        body: Center(
          child: SizedBox(
            width: 360,
            child: Card(
              color: const Color(0xFF1A1D24),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'ورود به بازی مافیا لوکال',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _nameCtrl,
                      decoration: const InputDecoration(
                        labelText: 'نام شما',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _connectAndJoin,
                        child: const Text('ورود به لابی'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('مافیا لوکال — فاز: ${_state!['phase']}'),
      ),
      body: Center(
        child: Text('متصل شد! شناسه شما: ${_state!['selfPlayerId']}'),
      ),
    );
  }
}
