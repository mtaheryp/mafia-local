import express from 'express';
import http from 'http';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { WebSocketServer, WebSocket } from 'ws';
import { GameEngine } from './src/core/engine/game_engine';
import { runAllEngineAndPrivacyTests } from './src/core/tests/engine_and_privacy_suite';
import { WsConnectionAdapter, WsGateway } from './src/server/ws_gateway';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Discovers the primary LAN IPv4 address of the host machine.
 */
function discoverLanIp(): { lanIp: string | null; allInterfaces: { name: string; address: string }[] } {
  const nets = os.networkInterfaces();
  const list: { name: string; address: string }[] = [];

  for (const [name, interfaces] of Object.entries(nets)) {
    if (!interfaces) continue;
    for (const net of interfaces) {
      if (net.family === 'IPv4' && !net.internal) {
        list.push({ name, address: net.address });
      }
    }
  }

  // Prefer 192.168.x.x or 10.x.x.x or 172.x.x.x
  const preferred =
    list.find((i) => i.address.startsWith('192.168.')) ??
    list.find((i) => i.address.startsWith('10.')) ??
    list[0];

  return {
    lanIp: preferred ? preferred.address : '192.168.1.100',
    allInterfaces: list,
  };
}

async function startServer() {
  const app = express();
  app.use(express.json());

  const server = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  let gateway = new WsGateway(new GameEngine('mafia-local-room'));
  let simulatedWifiOff = false;
  let activePort = 8080; // Displayed LAN port (with fallback simulation support)

  // Periodically broadcast timer ticks during Day phase when timer is active
  setInterval(() => {
    const rem = gateway.engine.getDiscussionTimerRemainingSec();
    if (rem !== null) {
      gateway.broadcastAllClients();
    }
  }, 1000);

  // API: Network & Host Server Info
  app.get('/api/network-info', (req, res) => {
    const { lanIp, allInterfaces } = discoverLanIp();
    const appUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
    res.json({
      wifiConnected: !simulatedWifiOff && Boolean(lanIp),
      lanIp: simulatedWifiOff ? null : lanIp,
      lanPort: activePort,
      lanUrl: simulatedWifiOff ? null : `http://${lanIp}:${activePort}`,
      liveJoinUrl: appUrl,
      allInterfaces,
      foregroundServiceRunning: true,
      wakeLockAcquired: true,
      playerCount: gateway.engine.sessions.length,
      phase: gateway.engine.phase,
    });
  });

  // API: Toggle Wi-Fi Off / Port Fallback simulation (to verify §5 error handling)
  app.post('/api/simulate-network', (req, res) => {
    const { wifiOff, portFallback } = req.body ?? {};
    if (typeof wifiOff === 'boolean') {
      simulatedWifiOff = wifiOff;
    }
    if (typeof portFallback === 'boolean') {
      activePort = portFallback ? 8081 : 8080;
    }
    const { lanIp } = discoverLanIp();
    res.json({
      wifiConnected: !simulatedWifiOff && Boolean(lanIp),
      lanIp: simulatedWifiOff ? null : lanIp,
      lanPort: activePort,
      lanUrl: simulatedWifiOff ? null : `http://${lanIp}:${activePort}`,
    });
  });

  // API: Reset / Create Fresh Game Session
  app.post('/api/create-room', (_req, res) => {
    gateway = new WsGateway(new GameEngine(`mafia-${Date.now().toString(36)}`));
    res.json({ ok: true, gameId: gateway.engine.gameId });
  });

  // API: Run Automated Unit & 6-Client WebSocket Privacy Leak Tests
  app.get('/api/run-tests', (_req, res) => {
    const results = runAllEngineAndPrivacyTests();
    res.json({
      allPassed: results.every((r) => r.passed),
      totalTests: results.length,
      passedCount: results.filter((r) => r.passed).length,
      results,
    });
  });

  // WebSocket Upgrade on /ws
  server.on('upgrade', (request, socket, head) => {
    const pathname = new URL(request.url || '/', `http://${request.headers.host}`).pathname;
    if (pathname === '/ws') {
      wss.handleUpgrade(request, socket, head, (ws: WebSocket) => {
        wss.emit('connection', ws, request);
      });
    }
  });

  let connSeq = 0;
  wss.on('connection', (ws: WebSocket) => {
    connSeq += 1;
    const adapter: WsConnectionAdapter = {
      id: `ws_${connSeq}_${Date.now()}`,
      send: (jsonText: string) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(jsonText);
        }
      },
    };

    ws.on('message', (data) => {
      gateway.handleRawMessage(adapter, data.toString());
    });

    ws.on('close', () => {
      gateway.handleDisconnect(adapter);
    });

    ws.on('error', () => {
      gateway.handleDisconnect(adapter);
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = 3000;
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Mafia Local LAN & Web Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
