import { useEffect, useRef, useState, useCallback } from 'react';
import { ClientPersonalizedState } from '../core/engine/game_state';
import { RuleSet } from '../core/rules/rule_set';
import { WsMessageEnvelope } from '../server/protocol';

export interface DeviceSlot {
  slotId: string;
  label: string;
  sessionToken?: string;
  playerName?: string;
  isHostSlot?: boolean;
}

const STORAGE_SLOTS_KEY = 'mafia_local_device_slots_v1';

/**
 * Manages one or more real WebSocket client connections to the server.
 * Each slot represents an independent physical device / browser tab with its own `sessionToken`.
 * This allows both:
 * 1. Real multi-phone play over Wi-Fi / QR scan (each phone uses its default slot 0).
 * 2. Multi-device simulation on a single screen (switching between Host phone and Player 2..N phones).
 */
export function useMafiaMultiClient() {
  const [slots, setSlots] = useState<DeviceSlot[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_SLOTS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore storage errors
    }
    return [{ slotId: 'device_host', label: 'دستگاه فعلی', isHostSlot: true }];
  });

  const [activeSlotId, setActiveSlotId] = useState<string>(() => slots[0]?.slotId ?? 'device_host');
  const [statesBySlot, setStatesBySlot] = useState<Record<string, ClientPersonalizedState>>({});
  const [connectedBySlot, setConnectedBySlot] = useState<Record<string, boolean>>({});
  const [errorBySlot, setErrorBySlot] = useState<Record<string, string | null>>({});

  const socketsRef = useRef<Record<string, WebSocket>>({});
  const seqRef = useRef<number>(1);
  const slotsRef = useRef<DeviceSlot[]>(slots);
  slotsRef.current = slots;

  // Persist slots to localStorage for automatic reconnect on browser refresh
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_SLOTS_KEY, JSON.stringify(slots));
    } catch {
      // ignore
    }
  }, [slots]);

  const sendEnvelope = useCallback(
    (slotId: string, type: string, payload: Record<string, unknown>) => {
      const ws = socketsRef.current[slotId];
      if (!ws || ws.readyState !== WebSocket.OPEN) {
        setErrorBySlot((prev) => ({
          ...prev,
          [slotId]: 'اتصال وب‌سوکت برقرار نیست. در حال تلاش مجدد...',
        }));
        return;
      }
      seqRef.current += 1;
      const env: WsMessageEnvelope = {
        type,
        seq: seqRef.current,
        payload,
      };
      ws.send(JSON.stringify(env));
    },
    []
  );

  const ensureSlotSocket = useCallback(
    (slot: DeviceSlot, autoJoinName?: string, preferHost?: boolean) => {
      const existing = socketsRef.current[slot.slotId];
      if (
        existing &&
        (existing.readyState === WebSocket.OPEN || existing.readyState === WebSocket.CONNECTING)
      ) {
        if (existing.readyState === WebSocket.OPEN && autoJoinName) {
          sendEnvelope(slot.slotId, 'join', {
            name: autoJoinName,
            sessionToken: slot.sessionToken,
            preferHost: Boolean(preferHost),
          });
        }
        return;
      }

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      const ws = new WebSocket(wsUrl);
      socketsRef.current[slot.slotId] = ws;

      ws.onopen = () => {
        setConnectedBySlot((prev) => ({ ...prev, [slot.slotId]: true }));
        setErrorBySlot((prev) => ({ ...prev, [slot.slotId]: null }));

        // If slot already has a sessionToken or autoJoinName, automatically join/reconnect
        const latestSlot =
          slotsRef.current.find((s) => s.slotId === slot.slotId) ?? slot;
        const nameToJoin = autoJoinName ?? latestSlot.playerName;
        if (nameToJoin || latestSlot.sessionToken) {
          seqRef.current += 1;
          ws.send(
            JSON.stringify({
              type: 'join',
              seq: seqRef.current,
              payload: {
                name: nameToJoin ?? 'بازیکن',
                sessionToken: latestSlot.sessionToken,
                preferHost: preferHost ?? latestSlot.isHostSlot ?? false,
              },
            })
          );
        }
      };

      ws.onmessage = (ev) => {
        try {
          const env = JSON.parse(String(ev.data)) as WsMessageEnvelope;
          if (env.type === 'joined') {
            const p = env.payload as {
              playerId: string;
              name: string;
              isHost: boolean;
              sessionToken: string;
              warning?: string;
            };
            setSlots((prev) =>
              prev.map((s) =>
                s.slotId === slot.slotId
                  ? {
                      ...s,
                      sessionToken: p.sessionToken,
                      playerName: p.name,
                      label: p.isHost ? `${p.name} (میزبان)` : p.name,
                      isHostSlot: p.isHost,
                    }
                  : s
              )
            );
            if (p.warning) {
              setErrorBySlot((prev) => ({ ...prev, [slot.slotId]: p.warning ?? null }));
            }
          } else if (env.type === 'stateSync') {
            const sync = env.payload as unknown as ClientPersonalizedState;
            setStatesBySlot((prev) => ({ ...prev, [slot.slotId]: sync }));
          } else if (env.type === 'error') {
            const err = env.payload as { message?: string };
            setErrorBySlot((prev) => ({
              ...prev,
              [slot.slotId]: err.message ?? 'خطایی رخ داد',
            }));
          }
        } catch {
          // ignore malformed frame
        }
      };

      ws.onclose = () => {
        setConnectedBySlot((prev) => ({ ...prev, [slot.slotId]: false }));
      };
    },
    [sendEnvelope]
  );

  // Connect all existing slots on mount
  useEffect(() => {
    slots.forEach((slot) => {
      ensureSlotSocket(slot);
    });
  }, [slots, ensureSlotSocket]);

  const joinSlot = useCallback(
    (slotId: string, name: string, preferHost = false) => {
      const targetSlot = slotsRef.current.find((s) => s.slotId === slotId);
      if (!targetSlot) return;
      setSlots((prev) =>
        prev.map((s) => (s.slotId === slotId ? { ...s, playerName: name } : s))
      );
      ensureSlotSocket(targetSlot, name, preferHost);
    },
    [ensureSlotSocket]
  );

  /**
   * Spawns simulated real WebSocket player devices so a single user can test a full 6-player game
   * without needing 6 physical phones in hand.
   */
  const spawnTestPlayersUpToSix = useCallback(() => {
    const sampleNames = ['سهراب', 'نازنین', 'کیوان', 'پریسا', 'بهرام', 'مهسا', 'آرش'];
    const currentSlots = slotsRef.current;

    // Ensure host slot is joined first if not yet joined
    const hostSlot = currentSlots[0];
    if (hostSlot && !statesBySlot[hostSlot.slotId]) {
      joinSlot(hostSlot.slotId, 'امیر (میزبان)', true);
    }

    const needed = Math.max(0, 6 - currentSlots.length);
    const newSlots: DeviceSlot[] = [];
    for (let i = 0; i < needed; i++) {
      const idx = currentSlots.length + i;
      const name = sampleNames[idx - 1] ?? `بازیکن ${idx}`;
      newSlots.push({
        slotId: `sim_device_${Date.now()}_${i}`,
        label: name,
        playerName: name,
        isHostSlot: false,
      });
    }

    if (newSlots.length > 0) {
      const combined = [...currentSlots, ...newSlots];
      setSlots(combined);
      newSlots.forEach((ns) => {
        setTimeout(() => {
          ensureSlotSocket(ns, ns.playerName, false);
        }, 60);
      });
    }
  }, [ensureSlotSocket, joinSlot, statesBySlot]);

  const addSingleSimulatedDevice = useCallback(
    (customName?: string) => {
      const idx = slotsRef.current.length + 1;
      const defaultNames = ['امیر', 'سارا', 'سهراب', 'نازنین', 'کیوان', 'پریسا', 'بهرام', 'مهسا'];
      const name = customName || defaultNames[(idx - 1) % defaultNames.length];
      const newSlot: DeviceSlot = {
        slotId: `sim_device_${Date.now()}_${idx}`,
        label: name,
        playerName: name,
        isHostSlot: false,
      };
      setSlots((prev) => [...prev, newSlot]);
      setActiveSlotId(newSlot.slotId);
      setTimeout(() => {
        ensureSlotSocket(newSlot, name, false);
      }, 40);
    },
    [ensureSlotSocket]
  );

  const resetAllLocalSessions = useCallback(async () => {
    // Close existing sockets
    Object.values(socketsRef.current).forEach((ws) => {
      try {
        ws.close();
      } catch {
        // ignore
      }
    });
    socketsRef.current = {};
    localStorage.removeItem(STORAGE_SLOTS_KEY);

    await fetch('/api/create-room', { method: 'POST' });

    const initialSlot: DeviceSlot = {
      slotId: `device_host_${Date.now()}`,
      label: 'دستگاه میزبان',
      isHostSlot: true,
    };
    setStatesBySlot({});
    setConnectedBySlot({});
    setErrorBySlot({});
    setSlots([initialSlot]);
    setActiveSlotId(initialSlot.slotId);
  }, []);

  const activeState = statesBySlot[activeSlotId] ?? null;
  const activeConnected = connectedBySlot[activeSlotId] ?? false;
  const activeError = errorBySlot[activeSlotId] ?? null;

  const clearActiveError = useCallback(() => {
    setErrorBySlot((prev) => ({ ...prev, [activeSlotId]: null }));
  }, [activeSlotId]);

  // Actions for the currently active device slot
  const actions = {
    join: (name: string, preferHost = false) => joinSlot(activeSlotId, name, preferHost),
    markReady: () => {
      if (!activeState) return;
      sendEnvelope(activeSlotId, 'ready', { sessionToken: activeState.selfSessionToken });
    },
    configureRoles: (roleCounts?: Record<string, number>, rules?: Partial<RuleSet>) => {
      if (!activeState) return;
      sendEnvelope(activeSlotId, 'configureRoles', {
        sessionToken: activeState.selfSessionToken,
        roleCounts,
        rules,
      });
    },
    startGame: () => {
      if (!activeState) return;
      sendEnvelope(activeSlotId, 'startGame', { sessionToken: activeState.selfSessionToken });
    },
    submitNightAction: (targetPlayerId: string | null) => {
      if (!activeState) return;
      sendEnvelope(activeSlotId, 'submitNightAction', {
        sessionToken: activeState.selfSessionToken,
        targetPlayerId,
      });
    },
    submitVote: (targetPlayerId: string | null) => {
      if (!activeState) return;
      sendEnvelope(activeSlotId, 'submitVote', {
        sessionToken: activeState.selfSessionToken,
        targetPlayerId,
      });
    },
    advancePhase: (force = false) => {
      if (!activeState) return;
      sendEnvelope(activeSlotId, 'advancePhase', {
        sessionToken: activeState.selfSessionToken,
        force,
      });
    },
    restartTimer: (durationSec?: number) => {
      if (!activeState) return;
      sendEnvelope(activeSlotId, 'restartTimer', {
        sessionToken: activeState.selfSessionToken,
        durationSec,
      });
    },
    resetToLobby: () => {
      if (!activeState) return;
      sendEnvelope(activeSlotId, 'resetToLobby', {
        sessionToken: activeState.selfSessionToken,
      });
    },
    sendChat: (text: string) => {
      if (!activeState) return;
      sendEnvelope(activeSlotId, 'chat', {
        sessionToken: activeState.selfSessionToken,
        text,
      });
    },
    /** Helper for testing: marks all simulated connected players Ready in RoleReveal */
    markAllSimulatedPlayersReady: () => {
      for (const [slotId, st] of Object.entries(statesBySlot)) {
        sendEnvelope(slotId, 'ready', { sessionToken: st.selfSessionToken });
      }
    },
  };

  return {
    slots,
    activeSlotId,
    setActiveSlotId,
    statesBySlot,
    activeState,
    activeConnected,
    activeError,
    clearActiveError,
    actions,
    spawnTestPlayersUpToSix,
    addSingleSimulatedDevice,
    resetAllLocalSessions,
  };
}
