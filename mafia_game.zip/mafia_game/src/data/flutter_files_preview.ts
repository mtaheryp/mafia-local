export interface FlutterSourceFileItem {
  path: string;
  layer: string;
  description: string;
  code: string;
}

export const FLUTTER_PROJECT_TREE = `flutter_project/
├── pubspec.yaml
├── android/app/src/main/AndroidManifest.xml
├── tool/build_all.sh
├── lib/
│   ├── core/
│   │   ├── engine/
│   │   │   ├── game_engine.dart
│   │   │   ├── game_state.dart
│   │   │   ├── game_phase.dart
│   │   │   ├── action_resolver.dart
│   │   │   └── win_checker.dart
│   │   ├── roles/
│   │   │   ├── role_module.dart
│   │   │   ├── role_registry.dart
│   │   │   ├── role_ids.dart
│   │   │   └── builtin/
│   │   │       ├── villager_role.dart
│   │   │       ├── mafia_role.dart
│   │   │       ├── doctor_role.dart
│   │   │       ├── detective_role.dart
│   │   │       └── hunter_role.dart
│   │   ├── rules/
│   │   │   ├── rule_set.dart
│   │   │   └── win_conditions.dart
│   │   └── session/
│   │       └── session.dart
│   ├── server/
│   │   ├── http_server.dart
│   │   ├── ws_gateway.dart
│   │   ├── protocol.dart
│   │   └── state_broadcaster.dart
│   ├── host_app/
│   │   └── main.dart
│   └── player_web/
│       └── main.dart
└── test/
    ├── engine_unit_test.dart
    └── ws_privacy_integration_test.dart`;

export const FLUTTER_SOURCE_HIGHLIGHTS: FlutterSourceFileItem[] = [
  {
    path: 'lib/core/roles/role_module.dart',
    layer: 'Core / Roles Contract',
    description: 'قرارداد انتزاعی RoleModule برای تمام نقش‌ها بدون وابستگی به UI یا سرور',
    code: `abstract class RoleModule {
  String get id;                      // stable string, e.g. 'doctor'
  String get displayName;             // نام فارسی نقش
  String get shortDescription;
  RoleTeam get team;                  // enum: town, mafia, neutral
  bool get hasNightAction;
  bool get actsEachNight;             // false for one-shot roles (Hunter)

  NightActionSchema? buildNightActionSchema(GameStateView view, String actorId);
  bool validateAction(GameStateView view, String actorId, NightAction action);
  NightEffect? resolve(NightContext ctx, String actorId, NightAction action);
  RoleResultPayload? resultForActor(GameStateView view, String actorId, NightOutcome outcome);
  WinCondition? get customWinCondition => null;
}`,
  },
  {
    path: 'lib/core/roles/builtin/hunter_role.dart',
    layer: 'Core / Extensibility Example',
    description: 'نقش پنجم (تک‌تیرانداز / شکارچی) که فقط با ۱ فایل + ۱ خط ثبت در RoleRegistry به کل بازی اضافه شده است',
    code: `class HunterRole extends RoleModule {
  @override
  String get id => RoleIds.hunter;

  @override
  String get displayName => 'تک‌تیرانداز (شکارچی)';

  @override
  RoleTeam get team => RoleTeam.town;

  @override
  bool get hasNightAction => true;

  @override
  bool get actsEachNight => false; // قابلیت تک‌ضربتی در کل بازی
  // ...
}`,
  },
  {
    path: 'lib/server/state_broadcaster.dart',
    layer: 'Server / Privacy Filter',
    description: 'تضمین عدم نشت نقش‌ها: هر کلاینت فقط اطلاعات عمومی + اطلاعات محرمانه خودش را دریافت می‌کند',
    code: `class StateBroadcaster {
  static Map<String, dynamic> buildClientState(GameEngine engine, String targetPlayerId) {
    final view = engine.buildInternalView();
    final myRoleId = engine.getRoleForPlayer(targetPlayerId);
    final myRoleMod = myRoleId != null ? RoleRegistry.tryGet(myRoleId) : null;
    // هرگز فیلد roleAssignments سایر بازیکنان را ارسال نمی‌کند
    return {
      'phase': engine.phase.name,
      'players': view.players.map((p) => p.toJson()).toList(),
      'mySecretRole': myRoleMod != null ? { 'roleId': myRoleMod.id, ... } : null,
      'myNightPrompt': myRoleMod?.buildNightActionSchema(view, targetPlayerId)?.toJson(),
      'myPrivateReports': engine.getPrivateReportsForPlayer(targetPlayerId),
    };
  }
}`,
  },
  {
    path: 'android/app/src/main/AndroidManifest.xml',
    layer: 'Android / Permissions & Service',
    description: 'حداقل مجوزهای شبکه محلی (بدون دوربین روی میزبان) + سرویس Foreground و WakeLock',
    code: `<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.WAKE_LOCK" />`,
  },
  {
    path: 'tool/build_all.sh',
    layer: 'Build & Packaging',
    description: 'اسکریپت ساخت خودکار وب، کپی به assets/web میزبان، اجرای تست‌ها و ساخت APK',
    code: `#!/usr/bin/env bash
set -euo pipefail
flutter build web --target=lib/player_web/main.dart --release --base-href=/
rm -rf assets/web && mkdir -p assets/web
cp -R build/web/* assets/web/
flutter analyze && flutter test
flutter build apk --target=lib/host_app/main.dart --release`,
  },
];
