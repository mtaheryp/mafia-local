import { ClientPersonalizedState, DayAnnouncement } from '../core/engine/game_state';
import { GamePhase } from '../core/engine/game_phase';
import {
  NightActionSchema,
  PublicPlayerView,
  RoleResultPayload,
  RoleTeam,
} from '../core/roles/role_module';
import { RuleSet } from '../core/rules/rule_set';

/**
 * WebSocket Message Envelope (§3.3)
 * Every message over the wire strictly conforms to `{ "type": string, "seq": number, "payload": object }`
 */
export interface WsMessageEnvelope<TType extends string = string, TPayload = Record<string, unknown>> {
  type: TType;
  seq: number;
  payload: TPayload;
}

// ============================================================================
// Client -> Server Message Types
// ============================================================================
export type ClientMessageType =
  | 'join'
  | 'ready'
  | 'configureRoles'
  | 'startGame'
  | 'advancePhase'
  | 'submitNightAction'
  | 'submitVote'
  | 'restartTimer'
  | 'resetToLobby'
  | 'chat'
  | 'ping';

export interface JoinPayload {
  name: string;
  sessionToken?: string;
  preferHost?: boolean;
}

export interface ReadyPayload {
  sessionToken: string;
}

export interface ConfigureRolesPayload {
  sessionToken: string;
  roleCounts?: Record<string, number>;
  rules?: Partial<RuleSet>;
}

export interface StartGamePayload {
  sessionToken: string;
}

export interface AdvancePhasePayload {
  sessionToken: string;
  force?: boolean;
}

export interface SubmitNightActionPayload {
  sessionToken: string;
  targetPlayerId: string | null;
}

export interface SubmitVotePayload {
  sessionToken: string;
  targetPlayerId: string | null;
}

export interface RestartTimerPayload {
  sessionToken: string;
  durationSec?: number;
}

export interface ResetToLobbyPayload {
  sessionToken: string;
}

export interface ChatPayload {
  sessionToken: string;
  text: string;
}

export interface PingPayload {
  timestamp: number;
}

// ============================================================================
// Server -> Client Message Types
// ============================================================================
export type ServerMessageType =
  | 'joined'
  | 'lobbyUpdate'
  | 'roleAssigned'
  | 'phaseChanged'
  | 'nightPrompt'
  | 'nightResultPrivate'
  | 'dayResult'
  | 'voteUpdate'
  | 'gameOver'
  | 'stateSync'
  | 'error'
  | 'pong';

export interface JoinedServerPayload {
  playerId: string;
  name: string;
  isHost: boolean;
  sessionToken: string;
  reconnected: boolean;
  warning?: string;
}

export interface LobbyUpdateServerPayload {
  players: PublicPlayerView[];
  roleCountsConfig: Record<string, number>;
  rules: RuleSet;
}

export interface RoleAssignedServerPayload {
  roleId: string;
  displayName: string;
  shortDescription: string;
  team: RoleTeam;
  hasNightAction: boolean;
}

export interface PhaseChangedServerPayload {
  phase: GamePhase;
  round: number;
  players: PublicPlayerView[];
}

export interface NightPromptServerPayload {
  schema: NightActionSchema | null;
  submittedTargetId: string | null | undefined;
}

export interface NightResultPrivateServerPayload {
  reports: RoleResultPayload[];
}

export interface DayResultServerPayload {
  announcement: DayAnnouncement | null;
}

export interface VoteUpdateServerPayload {
  tallies: Record<string, number>;
  totalVotesCast: number;
  totalEligibleVoters: number;
  myCurrentVoteTargetId: string | null | undefined;
}

export interface GameOverServerPayload {
  winningTeam: RoleTeam;
  reason: string;
  revealedRoster: {
    playerId: string;
    name: string;
    isAlive: boolean;
    roleId: string;
    roleDisplayName: string;
    team: RoleTeam;
  }[];
}

export interface ErrorServerPayload {
  message: string;
}

export interface PongServerPayload {
  timestamp: number;
  serverTime: number;
}

export type ServerStateSyncPayload = ClientPersonalizedState;
