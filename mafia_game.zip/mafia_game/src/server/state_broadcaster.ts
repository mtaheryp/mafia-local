import { GameEngine } from '../core/engine/game_engine';
import { GamePhase } from '../core/engine/game_phase';
import { ClientPersonalizedState } from '../core/engine/game_state';
import { RoleRegistry } from '../core/roles/role_registry';

/**
 * StateBroadcaster constructs strictly isolated per-client views (`ClientPersonalizedState`).
 *
 * CRITICAL SECURITY INVARIANT:
 * `buildClientState(engine, targetPlayerId)` composes ONLY:
 *   (a) Public game state
 *   (b) `targetPlayerId`'s own secret role, own night prompt, and own private reports.
 * It NEVER leaks another player's unrevealed role.
 */
export class StateBroadcaster {
  static buildClientState(engine: GameEngine, targetPlayerId: string): ClientPersonalizedState {
    const session = engine.getSessionByPlayerId(targetPlayerId);
    if (!session) {
      throw new Error(`Session not found for playerId: ${targetPlayerId}`);
    }

    const internalView = engine.buildInternalGameStateView();
    const myRoleId = engine.getRoleAssignmentForPlayer(targetPlayerId);
    const myRoleModule = myRoleId ? RoleRegistry.tryGet(myRoleId) : undefined;

    const mySecretRole =
      engine.phase !== GamePhase.lobby && myRoleId && myRoleModule
        ? {
            roleId: myRoleModule.id,
            displayName: myRoleModule.displayName,
            shortDescription: myRoleModule.shortDescription,
            team: myRoleModule.team,
            hasNightAction: myRoleModule.hasNightAction,
          }
        : null;

    const myNightPrompt =
      engine.phase === GamePhase.night && myRoleModule && session.isAlive
        ? myRoleModule.buildNightActionSchema(internalView, targetPlayerId)
        : null;

    const mySubmittedAction = engine.getNightActionForPlayer(targetPlayerId);
    const mySubmittedNightTargetId =
      mySubmittedAction !== undefined ? mySubmittedAction.targetPlayerId : undefined;

    const votesSnapshot = engine.getVotesSnapshot();
    const myCurrentVoteTargetId = votesSnapshot.rawVotes[targetPlayerId];

    // Reveal full roster ONLY when Game Over OR if viewer is dead and `revealRolesToDeadSpectators` is ON
    const canSeeFullRoster =
      engine.phase === GamePhase.gameOver ||
      (engine.phase !== GamePhase.lobby &&
        !session.isAlive &&
        engine.rules.revealRolesToDeadSpectators);

    const revealedRoster = canSeeFullRoster
      ? engine.sessions.map((s) => {
          const rId = engine.getRoleAssignmentForPlayer(s.playerId) ?? 'villager';
          const rMod = RoleRegistry.get(rId);
          return {
            playerId: s.playerId,
            name: s.name,
            isAlive: s.isAlive,
            roleId: rId,
            roleDisplayName: rMod.displayName,
            team: rMod.team,
          };
        })
      : null;

    const availableRolesMeta = RoleRegistry.getAll().map((r) => ({
      id: r.id,
      displayName: r.displayName,
      shortDescription: r.shortDescription,
      team: r.team,
      minCount: r.minCountInConfig,
    }));

    const timerRemaining = engine.getDiscussionTimerRemainingSec();

    return {
      gameId: engine.gameId,
      phase: engine.phase,
      round: engine.round,
      selfPlayerId: session.playerId,
      selfSessionToken: session.sessionToken,
      isHost: session.isHost,
      players: internalView.players,
      roleCountsConfig: engine.roleCountsConfig,
      rules: { ...engine.rules },
      availableRolesMeta,
      mySecretRole,
      myNightPrompt,
      mySubmittedNightTargetId,
      myPrivateReports: engine.getPrivateReportsForPlayer(targetPlayerId),
      hostNightStatus:
        session.isHost && engine.phase === GamePhase.night
          ? engine.getNightSubmissionStatus()
          : null,
      lastDayAnnouncement: engine.getLastDayAnnouncement(),
      discussionTimerRemainingSec: timerRemaining,
      discussionTimerRunning: timerRemaining !== null && timerRemaining > 0,
      voteTallies: votesSnapshot.tallies,
      totalVotesCast: votesSnapshot.totalVotesCast,
      totalEligibleVoters: votesSnapshot.totalEligibleVoters,
      myCurrentVoteTargetId,
      lastVoteSummary: engine.getLastVoteSummary(),
      revealedRoster,
      gameOverInfo: engine.getGameOverInfo(),
      chatMessages: engine.getChatMessages(),
    };
  }
}
