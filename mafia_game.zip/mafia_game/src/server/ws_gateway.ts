import { GameEngine } from '../core/engine/game_engine';
import { GamePhase } from '../core/engine/game_phase';
import {
  AdvancePhasePayload,
  ChatPayload,
  ConfigureRolesPayload,
  DayResultServerPayload,
  ErrorServerPayload,
  GameOverServerPayload,
  JoinedServerPayload,
  JoinPayload,
  LobbyUpdateServerPayload,
  NightPromptServerPayload,
  NightResultPrivateServerPayload,
  PhaseChangedServerPayload,
  PingPayload,
  PongServerPayload,
  ReadyPayload,
  ResetToLobbyPayload,
  RestartTimerPayload,
  RoleAssignedServerPayload,
  ServerMessageType,
  StartGamePayload,
  SubmitNightActionPayload,
  SubmitVotePayload,
  VoteUpdateServerPayload,
  WsMessageEnvelope,
} from './protocol';
import { StateBroadcaster } from './state_broadcaster';

export interface WsConnectionAdapter {
  id: string;
  send(jsonText: string): void;
}

/**
 * Transport-agnostic WebSocket Gateway.
 * Works identically with real WebSockets (`ws` on Node / `shelf_web_socket` on Dart)
 * and in-memory test sockets for programmatic 6-client integration & privacy leak testing.
 */
export class WsGateway {
  readonly engine: GameEngine;
  private _seq = 0;
  private _connToPlayerId: Map<string, string> = new Map();
  private _playerIdToConns: Map<string, Set<WsConnectionAdapter>> = new Map();
  /** Optional hook for automated tests to inspect every outgoing frame per recipient */
  private _outgoingInspectors: ((recipientPlayerId: string | null, envelope: WsMessageEnvelope) => void)[] = [];

  constructor(engine = new GameEngine()) {
    this.engine = engine;
  }

  onOutgoingMessage(
    inspector: (recipientPlayerId: string | null, envelope: WsMessageEnvelope) => void
  ): void {
    this._outgoingInspectors.push(inspector);
  }

  handleDisconnect(conn: WsConnectionAdapter): void {
    const playerId = this._connToPlayerId.get(conn.id);
    this._connToPlayerId.delete(conn.id);

    if (playerId) {
      const set = this._playerIdToConns.get(playerId);
      if (set) {
        set.delete(conn);
        if (set.size === 0) {
          this._playerIdToConns.delete(playerId);
          this.engine.markDisconnected(playerId);
          this.broadcastAllClients();
        }
      }
    }
  }

  handleRawMessage(conn: WsConnectionAdapter, rawText: string): void {
    let parsed: WsMessageEnvelope<string, Record<string, unknown>>;
    try {
      parsed = JSON.parse(rawText) as WsMessageEnvelope<string, Record<string, unknown>>;
    } catch {
      this._sendToConn(conn, null, 'error', { message: 'قالب پیام JSON نامعتبر است.' });
      return;
    }

    if (!parsed || typeof parsed.type !== 'string') {
      this._sendToConn(conn, null, 'error', { message: 'نوع پیام مشخص نشده است.' });
      return;
    }

    const type = parsed.type;
    const payload = (parsed.payload ?? {}) as Record<string, unknown>;

    try {
      switch (type) {
        case 'ping': {
          const p = payload as unknown as PingPayload;
          const pong: PongServerPayload = {
            timestamp: p.timestamp ?? Date.now(),
            serverTime: Date.now(),
          };
          const pid = this._connToPlayerId.get(conn.id) ?? null;
          this._sendToConn(conn, pid, 'pong', pong);
          break;
        }

        case 'join': {
          const p = payload as unknown as JoinPayload;
          const { session, reconnected, warning } = this.engine.joinOrReconnect({
            name: String(p.name ?? 'بازیکن'),
            sessionToken: typeof p.sessionToken === 'string' ? p.sessionToken : undefined,
            preferHost: Boolean(p.preferHost),
          });

          this._connToPlayerId.set(conn.id, session.playerId);
          let set = this._playerIdToConns.get(session.playerId);
          if (!set) {
            set = new Set();
            this._playerIdToConns.set(session.playerId, set);
          }
          set.add(conn);

          const joinedPayload: JoinedServerPayload = {
            playerId: session.playerId,
            name: session.name,
            isHost: session.isHost,
            sessionToken: session.sessionToken,
            reconnected,
            warning,
          };
          this._sendToConn(conn, session.playerId, 'joined', joinedPayload);
          this.broadcastAllClients();
          break;
        }

        case 'configureRoles': {
          const p = payload as unknown as ConfigureRolesPayload;
          const session = this._requireSession(conn, p.sessionToken);
          this.engine.configureRolesAndRules(session.playerId, p.roleCounts, p.rules);
          this.broadcastAllClients();
          break;
        }

        case 'startGame': {
          const p = payload as unknown as StartGamePayload;
          const session = this._requireSession(conn, p.sessionToken);
          this.engine.startGame(session.playerId);
          this._emitSpecificRoleAssignedEvents();
          this._emitPhaseChangedEvents();
          this.broadcastAllClients();
          break;
        }

        case 'ready': {
          const p = payload as unknown as ReadyPayload;
          const session = this._requireSession(conn, p.sessionToken);
          this.engine.markPlayerReady(session.playerId);
          this.broadcastAllClients();
          break;
        }

        case 'submitNightAction': {
          const p = payload as unknown as SubmitNightActionPayload;
          const session = this._requireSession(conn, p.sessionToken);
          this.engine.submitNightAction(
            session.playerId,
            p.targetPlayerId === undefined ? null : p.targetPlayerId
          );
          this.broadcastAllClients();
          break;
        }

        case 'submitVote': {
          const p = payload as unknown as SubmitVotePayload;
          const session = this._requireSession(conn, p.sessionToken);
          this.engine.submitVote(
            session.playerId,
            p.targetPlayerId === undefined ? null : p.targetPlayerId
          );
          this._emitVoteUpdateEvents();
          this.broadcastAllClients();
          break;
        }

        case 'advancePhase': {
          const p = payload as unknown as AdvancePhasePayload;
          const session = this._requireSession(conn, p.sessionToken);
          const prevPhase = this.engine.phase;
          this.engine.hostAdvancePhase(session.playerId, Boolean(p.force));
          const nextPhase = this.engine.phase;

          if (prevPhase !== nextPhase) {
            this._emitPhaseChangedEvents();
            if (nextPhase === GamePhase.night) {
              this._emitNightPromptEvents();
            } else if (nextPhase === GamePhase.day) {
              this._emitNightResultPrivateEvents();
              this._emitDayResultEvents();
            } else if (nextPhase === GamePhase.gameOver) {
              this._emitGameOverEvents();
            }
          }
          this.broadcastAllClients();
          break;
        }

        case 'restartTimer': {
          const p = payload as unknown as RestartTimerPayload;
          const session = this._requireSession(conn, p.sessionToken);
          this.engine.restartDiscussionTimer(session.playerId, p.durationSec);
          this.broadcastAllClients();
          break;
        }

        case 'resetToLobby': {
          const p = payload as unknown as ResetToLobbyPayload;
          const session = this._requireSession(conn, p.sessionToken);
          this.engine.resetToLobby(session.playerId);
          this._emitPhaseChangedEvents();
          this.broadcastAllClients();
          break;
        }

        case 'chat': {
          const p = payload as unknown as ChatPayload;
          const session = this._requireSession(conn, p.sessionToken);
          this.engine.addChatMessage(session.playerId, String(p.text ?? ''));
          this.broadcastAllClients();
          break;
        }

        default:
          this._sendToConn(conn, null, 'error', { message: `نوع پیام ناشناخته: ${type}` });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'خطای نامشخص در سرور بازی';
      const pid = this._connToPlayerId.get(conn.id) ?? null;
      const errPayload: ErrorServerPayload = { message: msg };
      this._sendToConn(conn, pid, 'error', errPayload);
    }
  }

  private _requireSession(conn: WsConnectionAdapter, sessionToken?: string) {
    if (sessionToken) {
      const byToken = this.engine.getSessionByToken(sessionToken);
      if (byToken) return byToken;
    }
    const pid = this._connToPlayerId.get(conn.id);
    if (pid) {
      const byId = this.engine.getSessionByPlayerId(pid);
      if (byId) return byId;
    }
    throw new Error('نشست کاربری شما معتبر نیست؛ لطفاً صفحه را رفرش کنید.');
  }

  /**
   * Emits personalized `roleAssigned` message ONLY to each individual player.
   */
  private _emitSpecificRoleAssignedEvents(): void {
    for (const [playerId, conns] of this._playerIdToConns.entries()) {
      const state = StateBroadcaster.buildClientState(this.engine, playerId);
      if (state.mySecretRole) {
        const payload: RoleAssignedServerPayload = {
          roleId: state.mySecretRole.roleId,
          displayName: state.mySecretRole.displayName,
          shortDescription: state.mySecretRole.shortDescription,
          team: state.mySecretRole.team,
          hasNightAction: state.mySecretRole.hasNightAction,
        };
        for (const conn of conns) {
          this._sendToConn(conn, playerId, 'roleAssigned', payload);
        }
      }
    }
  }

  private _emitPhaseChangedEvents(): void {
    for (const [playerId, conns] of this._playerIdToConns.entries()) {
      const state = StateBroadcaster.buildClientState(this.engine, playerId);
      const payload: PhaseChangedServerPayload = {
        phase: state.phase,
        round: state.round,
        players: state.players,
      };
      for (const conn of conns) {
        this._sendToConn(conn, playerId, 'phaseChanged', payload);
      }
    }
  }

  private _emitNightPromptEvents(): void {
    for (const [playerId, conns] of this._playerIdToConns.entries()) {
      const state = StateBroadcaster.buildClientState(this.engine, playerId);
      if (state.myNightPrompt) {
        const payload: NightPromptServerPayload = {
          schema: state.myNightPrompt,
          submittedTargetId: state.mySubmittedNightTargetId,
        };
        for (const conn of conns) {
          this._sendToConn(conn, playerId, 'nightPrompt', payload);
        }
      }
    }
  }

  private _emitNightResultPrivateEvents(): void {
    for (const [playerId, conns] of this._playerIdToConns.entries()) {
      const state = StateBroadcaster.buildClientState(this.engine, playerId);
      if (state.myPrivateReports.length > 0) {
        const payload: NightResultPrivateServerPayload = {
          reports: state.myPrivateReports,
        };
        for (const conn of conns) {
          this._sendToConn(conn, playerId, 'nightResultPrivate', payload);
        }
      }
    }
  }

  private _emitDayResultEvents(): void {
    for (const [playerId, conns] of this._playerIdToConns.entries()) {
      const state = StateBroadcaster.buildClientState(this.engine, playerId);
      const payload: DayResultServerPayload = {
        announcement: state.lastDayAnnouncement,
      };
      for (const conn of conns) {
        this._sendToConn(conn, playerId, 'dayResult', payload);
      }
    }
  }

  private _emitVoteUpdateEvents(): void {
    for (const [playerId, conns] of this._playerIdToConns.entries()) {
      const state = StateBroadcaster.buildClientState(this.engine, playerId);
      const payload: VoteUpdateServerPayload = {
        tallies: state.voteTallies,
        totalVotesCast: state.totalVotesCast,
        totalEligibleVoters: state.totalEligibleVoters,
        myCurrentVoteTargetId: state.myCurrentVoteTargetId,
      };
      for (const conn of conns) {
        this._sendToConn(conn, playerId, 'voteUpdate', payload);
      }
    }
  }

  private _emitGameOverEvents(): void {
    for (const [playerId, conns] of this._playerIdToConns.entries()) {
      const state = StateBroadcaster.buildClientState(this.engine, playerId);
      if (state.gameOverInfo && state.revealedRoster) {
        const payload: GameOverServerPayload = {
          winningTeam: state.gameOverInfo.winningTeam,
          reason: state.gameOverInfo.reason,
          revealedRoster: state.revealedRoster,
        };
        for (const conn of conns) {
          this._sendToConn(conn, playerId, 'gameOver', payload);
        }
      }
    }
  }

  /**
   * Broadcasts `lobbyUpdate` (when in lobby) and `stateSync` (personalized state)
   * to every connected client using `StateBroadcaster`.
   */
  broadcastAllClients(): void {
    for (const [playerId, conns] of this._playerIdToConns.entries()) {
      const personalizedState = StateBroadcaster.buildClientState(this.engine, playerId);

      if (personalizedState.phase === GamePhase.lobby) {
        const lobbyPayload: LobbyUpdateServerPayload = {
          players: personalizedState.players,
          roleCountsConfig: personalizedState.roleCountsConfig,
          rules: personalizedState.rules,
        };
        for (const conn of conns) {
          this._sendToConn(conn, playerId, 'lobbyUpdate', lobbyPayload);
        }
      }

      for (const conn of conns) {
        this._sendToConn(conn, playerId, 'stateSync', personalizedState);
      }
    }
  }

  private _sendToConn<TPayload>(
    conn: WsConnectionAdapter,
    recipientPlayerId: string | null,
    type: ServerMessageType,
    payload: TPayload
  ): void {
    this._seq += 1;
    const envelope: WsMessageEnvelope<ServerMessageType, TPayload> = {
      type,
      seq: this._seq,
      payload,
    };

    for (const inspector of this._outgoingInspectors) {
      inspector(recipientPlayerId, envelope as unknown as WsMessageEnvelope);
    }

    conn.send(JSON.stringify(envelope));
  }
}
