import React, { useState, useEffect } from 'react';
import {
  Check,
  Eye,
  Moon,
  Sun,
  Vote,
  Trophy,
  Send,
  Settings,
  Play,
  FastForward,
  Timer,
  AlertTriangle,
  Shield,
  Skull,
  Search,
  Users,
  RotateCcw,
} from 'lucide-react';
import { GamePhase, PHASE_LABELS_FA } from '../core/engine/game_phase';
import { ClientPersonalizedState } from '../core/engine/game_state';
import { RoleTeam } from '../core/roles/role_module';
import { validateRoleConfiguration } from '../core/rules/rule_set';
import { Strings } from '../core/strings';

interface SharedPlayerScreensProps {
  state: ClientPersonalizedState;
  onMarkReady: () => void;
  onOpenConfigureRoles: () => void;
  onStartGame: () => void;
  onSubmitNightAction: (targetPlayerId: string | null) => void;
  onSubmitVote: (targetPlayerId: string | null) => void;
  onAdvancePhase: (force?: boolean) => void;
  onRestartTimer: (durationSec?: number) => void;
  onResetToLobby: () => void;
  onSendChat: (text: string) => void;
  onMarkAllSimulatedReady?: () => void;
  hasMultipleSimulatedSlots?: boolean;
}

export const SharedPlayerScreens: React.FC<SharedPlayerScreensProps> = ({
  state,
  onMarkReady,
  onOpenConfigureRoles,
  onStartGame,
  onSubmitNightAction,
  onSubmitVote,
  onAdvancePhase,
  onRestartTimer,
  onResetToLobby,
  onSendChat,
  onMarkAllSimulatedReady,
  hasMultipleSimulatedSlots,
}) => {
  const [isCardFlipped, setIsCardFlipped] = useState(false);
  const [selectedNightTarget, setSelectedNightTarget] = useState<string | null>(null);
  const [chatInput, setChatInput] = useState('');
  const [confirmForceEndNight, setConfirmForceEndNight] = useState(false);

  // Reset card flip state when entering roleReveal or changing active player
  useEffect(() => {
    setIsCardFlipped(false);
    setConfirmForceEndNight(false);
  }, [state.selfPlayerId, state.phase, state.round]);

  useEffect(() => {
    if (state.mySubmittedNightTargetId !== undefined) {
      setSelectedNightTarget(state.mySubmittedNightTargetId);
    } else {
      setSelectedNightTarget(null);
    }
  }, [state.mySubmittedNightTargetId, state.selfPlayerId, state.round]);

  const selfPlayer = state.players.find((p) => p.id === state.selfPlayerId);
  const isSelfAlive = selfPlayer?.isAlive ?? true;

  const getInitials = (name: string) => {
    const clean = name.replace(/#\d+$/, '').trim();
    const parts = clean.split(/\s+/);
    if (parts.length >= 2) {
      return `${parts[0][0] ?? ''}\u200C${parts[1][0] ?? ''}`;
    }
    return clean.slice(0, 2);
  };

  const getTeamAccentClasses = (team?: RoleTeam) => {
    if (team === RoleTeam.mafia) {
      return {
        border: 'border-[#E5484D]/50',
        bg: 'bg-[#E5484D]/15',
        text: 'text-[#E5484D]',
        solidBg: 'bg-[#E5484D]',
        label: Strings.teamMafia,
      };
    }
    if (team === RoleTeam.neutral) {
      return {
        border: 'border-[#F5A524]/50',
        bg: 'bg-[#F5A524]/15',
        text: 'text-[#F5A524]',
        solidBg: 'bg-[#F5A524]',
        label: Strings.teamNeutral,
      };
    }
    return {
      border: 'border-[#4FD1C5]/50',
      bg: 'bg-[#4FD1C5]/15',
      text: 'text-[#4FD1C5]',
      solidBg: 'bg-[#4FD1C5]',
      label: Strings.teamTown,
    };
  };

  const formatTimer = (sec: number | null) => {
    if (sec === null) return '00:00';
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    onSendChat(chatInput.trim());
    setChatInput('');
  };

  const roleValidation = validateRoleConfiguration(
    state.roleCountsConfig,
    state.players.length,
    state.rules.minPlayersToStart
  );

  const readyPlayersCount = state.players.filter((p) => p.isReady).length;

  return (
    <div className="space-y-6 pb-28">
      {/* Spectator Banner if Dead during active game */}
      {state.phase !== GamePhase.lobby &&
        state.phase !== GamePhase.gameOver &&
        !isSelfAlive && (
          <div className="p-4 rounded-2xl bg-[#E5484D]/15 border border-[#E5484D]/40 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Skull className="w-5 h-5 text-[#E5484D] shrink-0" />
              <div>
                <h3 className="text-sm font-bold text-white">
                  شما از بازی خارج شده‌اید (حالت تماشاگر)
                </h3>
                <p className="text-xs text-zinc-300 mt-0.5">
                  شما می‌توانید روند بازی را دنبال کنید اما امکان رای دادن یا انجام عملیات شب را ندارید.
                </p>
              </div>
            </div>
          </div>
        )}

      {/* Phase Status Header Card */}
      <div className="p-5 rounded-2xl bg-[#1A1D24] border border-white/10 flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs text-zinc-400">
            <span>{PHASE_LABELS_FA[state.phase]}</span>
            {state.round > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">دور {state.round}</span>
              </>
            )}
            <span aria-hidden="true">·</span>
            <span>
              بازیکن فعلی:{' '}
              <strong className="text-white">{selfPlayer?.name ?? 'بازیکن'}</strong>
            </span>
            {state.isHost && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-[#4FD1C5] font-semibold">{Strings.hostBadge}</span>
              </>
            )}
          </div>
          <h1 className="text-xl font-bold text-white">
            {state.phase === GamePhase.lobby && Strings.lobbyTitle}
            {state.phase === GamePhase.roleReveal && Strings.roleRevealTitle}
            {state.phase === GamePhase.night && Strings.nightPhaseTitle(state.round)}
            {state.phase === GamePhase.day && Strings.dayPhaseTitle(state.round)}
            {state.phase === GamePhase.vote && Strings.votePhaseTitle(state.round)}
            {state.phase === GamePhase.gameOver && Strings.gameOverTitle}
          </h1>
        </div>

        {/* My Secret Role Quick Peek Pill (Only visible to self after game starts) */}
        {state.mySecretRole && state.phase !== GamePhase.roleReveal && (
          <div className="px-3.5 py-2 rounded-xl bg-[#0F1115] border border-white/10 text-xs flex items-center gap-2">
            <span className="text-zinc-400">نقش مخفی شما:</span>
            <span
              className={`font-bold ${
                state.mySecretRole.team === RoleTeam.mafia
                  ? 'text-[#E5484D]'
                  : 'text-[#4FD1C5]'
              }`}
            >
              {state.mySecretRole.displayName}
            </span>
          </div>
        )}
      </div>

      {/* =====================================================================
          1. LOBBY SCREEN
         ===================================================================== */}
      {state.phase === GamePhase.lobby && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Players Grid */}
          <div className="lg:col-span-8 p-6 rounded-2xl bg-[#1A1D24] border border-white/10 space-y-5">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h2 className="text-base font-bold text-white">
                  {Strings.playersJoinedCount(state.players.length)}
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  {Strings.minPlayersNotice(state.rules.minPlayersToStart)}
                </p>
              </div>
              {!state.isHost && (
                <span className="text-xs text-[#4FD1C5] font-medium">
                  {Strings.waitingForHostToStart}
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {state.players.map((p) => {
                const isMe = p.id === state.selfPlayerId;
                return (
                  <div
                    key={p.id}
                    className={`p-3.5 rounded-xl border transition-colors flex items-center gap-3 ${
                      isMe
                        ? 'bg-[#4FD1C5]/10 border-[#4FD1C5]/40'
                        : 'bg-[#0F1115] border-white/5'
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 ${
                        isMe
                          ? 'bg-[#4FD1C5] text-[#0F1115]'
                          : 'bg-[#232730] text-zinc-200'
                      }`}
                    >
                      {getInitials(p.name)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-bold text-white truncate">{p.name}</div>
                      <div className="flex items-center gap-1.5 text-[11px] text-zinc-400 mt-0.5">
                        {isMe && <span className="text-[#4FD1C5]">{Strings.youBadge}</span>}
                        {isMe && p.isHost && <span aria-hidden="true">·</span>}
                        {p.isHost && <span className="text-amber-400">{Strings.hostBadge}</span>}
                        {!p.isConnected && (
                          <span className="text-[#E5484D]">{Strings.disconnectedBadge}</span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Role Summary Bar in Lobby */}
            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs text-zinc-300">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-zinc-400">چیدمان فعلی نقش‌ها:</span>
                {state.availableRolesMeta.map((r) => {
                  const count = state.roleCountsConfig[r.id] ?? 0;
                  if (count <= 0) return null;
                  return (
                    <span key={r.id} className="text-white font-medium">
                      {r.displayName}: <strong className="font-mono">{count}</strong>
                      <span className="mx-1.5 text-zinc-600">·</span>
                    </span>
                  );
                })}
              </div>
              {!roleValidation.isValid && (
                <span className="text-[#F5A524]">{roleValidation.errorMessage}</span>
              )}
            </div>
          </div>

          {/* Public Lobby Chat (Optional, Default ON in Lobby) */}
          <div className="lg:col-span-4 p-5 rounded-2xl bg-[#1A1D24] border border-white/10 flex flex-col h-[380px]">
            <h3 className="text-sm font-bold text-white pb-3 border-b border-white/10">
              {Strings.publicChatTitle}
            </h3>
            <div className="flex-1 overflow-y-auto py-3 space-y-2.5">
              {state.chatMessages.length === 0 ? (
                <p className="text-xs text-zinc-500 text-center py-12">
                  هنوز پیامی در لابی ارسال نشده است.
                </p>
              ) : (
                state.chatMessages.map((msg) => {
                  const isMine = msg.senderId === state.selfPlayerId;
                  return (
                    <div
                      key={msg.id}
                      className={`p-2.5 rounded-xl text-xs ${
                        isMine ? 'bg-[#4FD1C5]/15 text-white' : 'bg-[#0F1115] text-zinc-200'
                      }`}
                    >
                      <div className="font-bold text-[#4FD1C5] mb-0.5">{msg.senderName}</div>
                      <p className="leading-relaxed break-words">{msg.text}</p>
                    </div>
                  );
                })
              )}
            </div>
            {state.rules.enableLobbyChat && (
              <form onSubmit={handleChatSubmit} className="pt-2 border-t border-white/10 flex gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder={Strings.chatPlaceholder}
                  className="flex-1 px-3 py-2 rounded-xl bg-[#0F1115] border border-white/10 text-xs text-white focus:outline-none focus:border-[#4FD1C5]"
                />
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl bg-[#4FD1C5] text-[#0F1115] text-xs font-bold hover:bg-[#38B2AC] transition-colors cursor-pointer shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* =====================================================================
          2. ROLE REVEAL SCREEN (3D Card Flip Animation)
         ===================================================================== */}
      {state.phase === GamePhase.roleReveal && state.mySecretRole && (
        <div className="max-w-lg mx-auto space-y-6">
          <div className="text-center space-y-1">
            <p className="text-xs text-[#F5A524] font-medium">{Strings.keepSecretWarning}</p>
            <p className="text-sm text-zinc-300">{Strings.tapToFlipPrompt}</p>
          </div>

          {/* 3D Flip Card Container */}
          <div
            onClick={() => setIsCardFlipped((prev) => !prev)}
            className="perspective-1000 w-full h-80 cursor-pointer select-none"
          >
            <div
              className={`relative w-full h-full transition-transform duration-500 transform-style-3d ${
                isCardFlipped ? 'rotate-y-180' : ''
              }`}
            >
              {/* Front of Card (Face Down Mystery) */}
              <div className="absolute inset-0 backface-hidden rounded-2xl bg-[#1A1D24] border-2 border-white/15 p-8 flex flex-col items-center justify-center text-center shadow-2xl">
                <div className="w-16 h-16 rounded-2xl bg-[#232730] flex items-center justify-center mb-4">
                  <Eye className="w-8 h-8 text-[#4FD1C5]" />
                </div>
                <h2 className="text-xl font-bold text-white mb-2">کارت نقش مخفی</h2>
                <p className="text-xs text-zinc-400 max-w-xs leading-relaxed">
                  برای چرخاندن کارت و مشاهده نقش اختصاصی خود ({selfPlayer?.name}) روی کارت ضربه بزنید.
                </p>
              </div>

              {/* Back of Card (Secret Role Revealed) */}
              <div
                className={`absolute inset-0 backface-hidden rotate-y-180 rounded-2xl bg-[#1A1D24] border-2 p-8 flex flex-col items-center justify-center text-center shadow-2xl ${
                  getTeamAccentClasses(state.mySecretRole.team).border
                }`}
              >
                <span
                  className={`text-xs font-bold mb-2 ${
                    getTeamAccentClasses(state.mySecretRole.team).text
                  }`}
                >
                  {getTeamAccentClasses(state.mySecretRole.team).label}
                </span>
                <h2 className="text-3xl font-extrabold text-white mb-4">
                  {state.mySecretRole.displayName}
                </h2>
                <p className="text-sm text-zinc-200 leading-relaxed max-w-sm">
                  {state.mySecretRole.shortDescription}
                </p>
                <span className="mt-6 text-[11px] text-zinc-400">
                  برای پنهان کردن مجدد کارت دوباره ضربه بزنید
                </span>
              </div>
            </div>
          </div>

          {/* Ready Action Button */}
          <div className="p-5 rounded-2xl bg-[#1A1D24] border border-white/10 space-y-4">
            <div className="flex items-center justify-between text-xs text-zinc-300">
              <span>وضعیت آمادگی بازیکنان:</span>
              <span className="font-mono font-bold text-[#4FD1C5] tabular-nums">
                {readyPlayersCount} از {state.players.length} بازیکن آماده
              </span>
            </div>

            {!selfPlayer?.isReady ? (
              <button
                type="button"
                onClick={onMarkReady}
                className="w-full h-12 rounded-xl bg-[#4FD1C5] hover:bg-[#38B2AC] text-[#0F1115] font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{Strings.iSawMyRoleReadyBtn}</span>
              </button>
            ) : (
              <div className="p-3 rounded-xl bg-[#4FD1C5]/10 border border-[#4FD1C5]/30 text-center text-xs text-[#4FD1C5] font-medium">
                {Strings.waitingForOthersReady}
              </div>
            )}

            {hasMultipleSimulatedSlots &&
              readyPlayersCount < state.players.length &&
              onMarkAllSimulatedReady && (
                <button
                  type="button"
                  onClick={onMarkAllSimulatedReady}
                  className="w-full py-2.5 rounded-xl bg-[#232730] hover:bg-zinc-700 text-xs text-zinc-200 font-medium transition-colors cursor-pointer"
                >
                  تایید آمادگی تمام بازیکنان آزمایشی (سریع)
                </button>
              )}
          </div>
        </div>
      )}

      {/* =====================================================================
          3. NIGHT SCREEN
         ===================================================================== */}
      {state.phase === GamePhase.night && (
        <div className="max-w-2xl mx-auto space-y-6">
          {isSelfAlive && state.myNightPrompt ? (
            <div className="p-6 rounded-2xl bg-[#1A1D24] border border-white/10 space-y-5">
              <div className="flex items-center justify-between gap-4 pb-4 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#232730] flex items-center justify-center">
                    {state.myNightPrompt.roleId === 'mafia' ? (
                      <Skull className="w-5 h-5 text-[#E5484D]" />
                    ) : state.myNightPrompt.roleId === 'doctor' ? (
                      <Shield className="w-5 h-5 text-[#4FD1C5]" />
                    ) : (
                      <Search className="w-5 h-5 text-[#4FD1C5]" />
                    )}
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-white">
                      عملیات شبانه ({state.mySecretRole?.displayName})
                    </h2>
                    <p className="text-xs text-zinc-300 mt-0.5">{state.myNightPrompt.prompt}</p>
                  </div>
                </div>
              </div>

              {/* Mafia Coordination Panel (If Mafia has teammates) */}
              {state.myNightPrompt.teammates && state.myNightPrompt.teammates.length > 0 && (
                <div className="p-4 rounded-xl bg-[#0F1115] border border-[#E5484D]/30 space-y-2">
                  <div className="text-xs font-bold text-[#E5484D]">
                    {Strings.mafiaTeammatesLabel}
                  </div>
                  <div className="flex flex-wrap gap-3 text-xs">
                    {state.myNightPrompt.teammates.map((mate) => {
                      const targetId = state.myNightPrompt?.teammateSelections?.[mate.playerId];
                      const targetPlayer = state.players.find((p) => p.id === targetId);
                      return (
                        <div
                          key={mate.playerId}
                          className="px-3 py-1.5 rounded-lg bg-[#1A1D24] border border-white/5 text-zinc-200"
                        >
                          <span className="font-bold text-white">{mate.displayName}</span>
                          <span className="mx-1.5 text-zinc-500">←</span>
                          <span className="text-zinc-300">
                            {targetId === undefined
                              ? 'هنوز رای نداده'
                              : targetPlayer
                              ? `هدف: ${targetPlayer.name}`
                              : 'بدون شلیک'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Selectable Target Players Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {state.myNightPrompt.selectablePlayers.map((opt) => {
                  const isSelected = selectedNightTarget === opt.playerId;
                  return (
                    <button
                      key={opt.playerId}
                      type="button"
                      disabled={opt.disabled}
                      onClick={() => setSelectedNightTarget(opt.playerId)}
                      className={`p-4 rounded-xl border text-right transition-colors flex items-center justify-between gap-3 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                        isSelected
                          ? 'bg-[#4FD1C5]/15 border-[#4FD1C5] text-white'
                          : 'bg-[#0F1115] border-white/5 text-zinc-200 hover:border-white/20'
                      }`}
                    >
                      <div>
                        <div className="text-sm font-bold">{opt.displayName}</div>
                        {opt.disabledReason && (
                          <div className="text-[11px] text-amber-400 mt-0.5">
                            {opt.disabledReason}
                          </div>
                        )}
                      </div>
                      <div
                        className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                          isSelected ? 'border-[#4FD1C5] bg-[#4FD1C5] text-[#0F1115]' : 'border-zinc-600'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5" />}
                      </div>
                    </button>
                  );
                })}

                {state.myNightPrompt.allowSkip && (
                  <button
                    type="button"
                    onClick={() => setSelectedNightTarget(null)}
                    className={`p-4 rounded-xl border text-right transition-colors flex items-center justify-between gap-3 cursor-pointer ${
                      selectedNightTarget === null
                        ? 'bg-[#F5A524]/15 border-[#F5A524] text-white'
                        : 'bg-[#0F1115] border-white/5 text-zinc-300 hover:border-white/20'
                    }`}
                  >
                    <span className="text-sm font-bold">انصراف از عملیات در این شب</span>
                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                        selectedNightTarget === null
                          ? 'border-[#F5A524] bg-[#F5A524] text-[#0F1115]'
                          : 'border-zinc-600'
                      }`}
                    >
                      {selectedNightTarget === null && <Check className="w-3.5 h-3.5" />}
                    </div>
                  </button>
                )}
              </div>

              <button
                type="button"
                disabled={
                  !state.myNightPrompt.allowSkip && selectedNightTarget === null
                }
                onClick={() => onSubmitNightAction(selectedNightTarget)}
                className="w-full h-12 rounded-xl bg-[#4FD1C5] hover:bg-[#38B2AC] disabled:opacity-40 text-[#0F1115] font-bold text-sm transition-colors cursor-pointer"
              >
                {Strings.submitNightActionBtn}
              </button>

              {state.mySubmittedNightTargetId !== undefined && (
                <div className="p-3 rounded-xl bg-[#4FD1C5]/10 border border-[#4FD1C5]/30 text-xs text-[#4FD1C5] text-center font-medium">
                  {Strings.actionSubmittedNotice}
                </div>
              )}
            </div>
          ) : (
            /* Atmospheric "The Town Sleeps..." Screen for Villagers or Dead Spectators */
            <div className="p-10 rounded-2xl bg-[#1A1D24] border border-white/10 text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-[#0F1115] border border-white/10 flex items-center justify-center mx-auto">
                <Moon className="w-8 h-8 text-[#4FD1C5]" />
              </div>
              <h2 className="text-xl font-bold text-white">{Strings.townSleepsTitle}</h2>
              <p className="text-sm text-zinc-400 max-w-md mx-auto leading-relaxed">
                {Strings.townSleepsSubtitle}
              </p>
            </div>
          )}
        </div>
      )}

      {/* =====================================================================
          4. DAY SCREEN
         ===================================================================== */}
      {state.phase === GamePhase.day && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-8 space-y-6">
            {/* Public Morning Announcement */}
            {state.lastDayAnnouncement && (
              <div
                className={`p-6 rounded-2xl border ${
                  state.lastDayAnnouncement.killedPlayers.length > 0
                    ? 'bg-[#E5484D]/10 border-[#E5484D]/30'
                    : 'bg-[#4FD1C5]/10 border-[#4FD1C5]/30'
                }`}
              >
                <div className="flex items-center gap-3 mb-2">
                  <Sun
                    className={`w-6 h-6 ${
                      state.lastDayAnnouncement.killedPlayers.length > 0
                        ? 'text-[#E5484D]'
                        : 'text-[#4FD1C5]'
                    }`}
                  />
                  <h2 className="text-lg font-bold text-white">گزارش عمومی صبحگاهی شهر</h2>
                </div>
                <p className="text-sm text-zinc-100 leading-relaxed font-medium">
                  {state.lastDayAnnouncement.message}
                </p>
                {state.lastDayAnnouncement.killedPlayers.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2 text-xs text-zinc-300">
                    {state.lastDayAnnouncement.killedPlayers.map((k) => (
                      <span key={k.id} className="px-3 py-1 rounded-lg bg-[#0F1115]">
                        {k.name}
                        {k.revealedRoleName ? ` (نقش: ${k.revealedRoleName})` : ''}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Private Night Result Report (Strictly visible ONLY to Detective or Victim) */}
            {state.myPrivateReports.length > 0 && (
              <div className="p-5 rounded-2xl bg-[#1A1D24] border border-[#4FD1C5]/40 space-y-3">
                <h3 className="text-xs font-bold text-[#4FD1C5]">
                  {Strings.privateNightResultHeader}
                </h3>
                <div className="space-y-2">
                  {state.myPrivateReports.map((rep, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-xl bg-[#0F1115] border border-white/5 space-y-1"
                    >
                      <div className="text-sm font-bold text-white">{rep.title}</div>
                      <p className="text-xs text-zinc-300 leading-relaxed">{rep.message}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Alive & Fallen Players List */}
            <div className="p-6 rounded-2xl bg-[#1A1D24] border border-white/10 space-y-4">
              <h3 className="text-sm font-bold text-white">{Strings.alivePlayersHeader}</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {state.players
                  .filter((p) => p.isAlive)
                  .map((p) => (
                    <div
                      key={p.id}
                      className="p-3 rounded-xl bg-[#0F1115] border border-white/5 flex items-center gap-3"
                    >
                      <div className="w-9 h-9 rounded-lg bg-[#232730] flex items-center justify-center text-xs font-bold text-white shrink-0">
                        {getInitials(p.name)}
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-bold text-white truncate">{p.name}</div>
                        <div className="text-[11px] text-[#4FD1C5]">در قید حیات</div>
                      </div>
                    </div>
                  ))}
              </div>

              {state.players.some((p) => !p.isAlive) && (
                <div className="pt-4 border-t border-white/10 space-y-3">
                  <h4 className="text-xs font-bold text-zinc-400">
                    {Strings.fallenPlayersHeader}
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {state.players
                      .filter((p) => !p.isAlive)
                      .map((p) => (
                        <div
                          key={p.id}
                          className="p-3 rounded-xl bg-[#0F1115]/50 border border-white/5 opacity-60 flex items-center gap-3"
                        >
                          <div className="w-9 h-9 rounded-lg bg-zinc-800 flex items-center justify-center text-xs font-bold text-zinc-400 shrink-0">
                            {getInitials(p.name)}
                          </div>
                          <div className="min-w-0">
                            <div className="text-sm font-bold text-zinc-300 line-through truncate">
                              {p.name}
                            </div>
                            {p.revealedRoleName && (
                              <div className="text-[11px] text-zinc-400">
                                نقش: {p.revealedRoleName}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Discussion Timer & Optional Day Chat */}
          <div className="lg:col-span-4 space-y-6">
            <div className="p-5 rounded-2xl bg-[#1A1D24] border border-white/10 text-center space-y-3">
              <div className="flex items-center justify-center gap-2 text-xs text-zinc-400">
                <Timer className="w-4 h-4 text-[#4FD1C5]" />
                <span>{Strings.discussionTimerLabel}</span>
              </div>
              <div className="text-4xl font-mono font-extrabold text-white tabular-nums">
                {formatTimer(state.discussionTimerRemainingSec)}
              </div>
              {state.isHost && (
                <div className="flex items-center justify-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => onRestartTimer(60)}
                    className="px-3 py-1.5 rounded-lg bg-[#0F1115] hover:bg-white/10 text-xs text-zinc-200 cursor-pointer"
                  >
                    شروع ۶۰ ثانیه
                  </button>
                  <button
                    type="button"
                    onClick={() => onRestartTimer(120)}
                    className="px-3 py-1.5 rounded-lg bg-[#0F1115] hover:bg-white/10 text-xs text-zinc-200 cursor-pointer"
                  >
                    شروع ۱۲۰ ثانیه
                  </button>
                </div>
              )}
            </div>

            {state.rules.enableDayChat && (
              <div className="p-5 rounded-2xl bg-[#1A1D24] border border-white/10 flex flex-col h-[300px]">
                <h3 className="text-sm font-bold text-white pb-3 border-b border-white/10">
                  گفتگوی روز
                </h3>
                <div className="flex-1 overflow-y-auto py-3 space-y-2">
                  {state.chatMessages.map((msg) => (
                    <div key={msg.id} className="p-2.5 rounded-xl bg-[#0F1115] text-xs">
                      <span className="font-bold text-[#4FD1C5]">{msg.senderName}: </span>
                      <span className="text-zinc-200">{msg.text}</span>
                    </div>
                  ))}
                </div>
                {isSelfAlive && (
                  <form onSubmit={handleChatSubmit} className="pt-2 flex gap-2">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder={Strings.chatPlaceholder}
                      className="flex-1 px-3 py-2 rounded-xl bg-[#0F1115] border border-white/10 text-xs text-white"
                    />
                    <button
                      type="submit"
                      className="px-3 py-2 rounded-xl bg-[#4FD1C5] text-[#0F1115] text-xs font-bold cursor-pointer"
                    >
                      ارسال
                    </button>
                  </form>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* =====================================================================
          5. VOTE SCREEN
         ===================================================================== */}
      {state.phase === GamePhase.vote && (
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="p-6 rounded-2xl bg-[#1A1D24] border border-white/10 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white">{Strings.voteInstruction}</h2>
                <p className="text-xs text-zinc-400 mt-0.5">{Strings.changeVoteHint}</p>
              </div>
              <div className="text-xs font-mono font-bold text-[#4FD1C5] tabular-nums">
                آرای ثبت‌شده: {state.totalVotesCast} از {state.totalEligibleVoters}
              </div>
            </div>

            <div className="space-y-3">
              {state.players
                .filter((p) => p.isAlive)
                .map((candidate) => {
                  const voteCount = state.voteTallies[candidate.id] ?? 0;
                  const pct =
                    state.totalEligibleVoters > 0
                      ? Math.round((voteCount / state.totalEligibleVoters) * 100)
                      : 0;
                  const isMyChoice = state.myCurrentVoteTargetId === candidate.id;

                  return (
                    <button
                      key={candidate.id}
                      type="button"
                      disabled={!isSelfAlive}
                      onClick={() => onSubmitVote(candidate.id)}
                      className={`w-full p-4 rounded-xl border text-right transition-all relative overflow-hidden cursor-pointer disabled:cursor-not-allowed ${
                        isMyChoice
                          ? 'bg-[#E5484D]/15 border-[#E5484D]'
                          : 'bg-[#0F1115] border-white/5 hover:border-white/20'
                      }`}
                    >
                      {/* Animated Progress Bar Fill */}
                      <div
                        className="absolute inset-y-0 right-0 bg-white/5 transition-transform duration-200 origin-right pointer-events-none"
                        style={{
                          width: '100%',
                          transform: `scaleX(${pct / 100})`,
                        }}
                      />

                      <div className="relative flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg bg-[#232730] flex items-center justify-center text-xs font-bold text-white">
                            {getInitials(candidate.name)}
                          </div>
                          <div>
                            <div className="text-sm font-bold text-white">{candidate.name}</div>
                            {isMyChoice && (
                              <div className="text-[11px] text-[#E5484D] font-medium">
                                رای فعلی شما
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="font-mono text-sm font-bold text-white tabular-nums">
                            {voteCount} رای
                          </span>
                        </div>
                      </div>
                    </button>
                  );
                })}

              {/* Skip Vote Option */}
              <button
                type="button"
                disabled={!isSelfAlive}
                onClick={() => onSubmitVote(null)}
                className={`w-full p-4 rounded-xl border text-right transition-colors flex items-center justify-between gap-4 cursor-pointer disabled:cursor-not-allowed ${
                  state.myCurrentVoteTargetId === null
                    ? 'bg-[#F5A524]/15 border-[#F5A524]'
                    : 'bg-[#0F1115] border-white/5 hover:border-white/20'
                }`}
              >
                <div>
                  <div className="text-sm font-bold text-white">{Strings.skipVoteOption}</div>
                  {state.myCurrentVoteTargetId === null && (
                    <div className="text-[11px] text-[#F5A524] font-medium">رای فعلی شما</div>
                  )}
                </div>
                <span className="font-mono text-sm font-bold text-white tabular-nums">
                  {state.voteTallies['SKIP'] ?? 0} رای
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          6. GAME OVER SCREEN
         ===================================================================== */}
      {state.phase === GamePhase.gameOver && state.gameOverInfo && (
        <div className="max-w-3xl mx-auto space-y-6">
          <div
            className={`p-8 rounded-2xl border text-center space-y-3 ${
              state.gameOverInfo.winningTeam === RoleTeam.mafia
                ? 'bg-[#E5484D]/15 border-[#E5484D]/50'
                : 'bg-[#4FD1C5]/15 border-[#4FD1C5]/50'
            }`}
          >
            <div className="w-16 h-16 rounded-2xl bg-[#0F1115] flex items-center justify-center mx-auto">
              <Trophy
                className={`w-8 h-8 ${
                  state.gameOverInfo.winningTeam === RoleTeam.mafia
                    ? 'text-[#E5484D]'
                    : 'text-[#4FD1C5]'
                }`}
              />
            </div>
            <h2 className="text-2xl font-extrabold text-white">
              {state.gameOverInfo.winningTeam === RoleTeam.mafia
                ? Strings.mafiaWinsBanner
                : Strings.townWinsBanner}
            </h2>
            <p className="text-sm text-zinc-200 max-w-xl mx-auto leading-relaxed">
              {state.gameOverInfo.reason}
            </p>
          </div>

          {state.lastVoteSummary && (
            <div className="p-4 rounded-xl bg-[#1A1D24] border border-white/10 text-xs text-zinc-300 text-center">
              نتیجه آخرین رای‌گیری: {state.lastVoteSummary.message}
            </div>
          )}

          {/* Full Roster with All Secret Roles Revealed */}
          {state.revealedRoster && (
            <div className="p-6 rounded-2xl bg-[#1A1D24] border border-white/10 space-y-4">
              <h3 className="text-base font-bold text-white">{Strings.fullRoleRosterTitle}</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {state.revealedRoster.map((item) => {
                  const accent = getTeamAccentClasses(item.team);
                  return (
                    <div
                      key={item.playerId}
                      className={`p-4 rounded-xl bg-[#0F1115] border ${accent.border} flex items-center justify-between gap-3`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-[#232730] flex items-center justify-center font-bold text-sm text-white">
                          {getInitials(item.name)}
                        </div>
                        <div>
                          <div className="text-sm font-bold text-white">{item.name}</div>
                          <div className="text-xs text-zinc-400 mt-0.5">
                            {item.isAlive ? 'زنده در پایان بازی' : 'حذف‌شده در طول بازی'}
                          </div>
                        </div>
                      </div>
                      <div className="text-left">
                        <div className={`text-sm font-bold ${accent.text}`}>
                          {item.roleDisplayName}
                        </div>
                        <div className="text-[11px] text-zinc-400">{accent.label}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Spectator Full Role List (ONLY if player is dead AND host enabled revealRolesToDeadSpectators) */}
      {state.phase !== GamePhase.gameOver &&
        !isSelfAlive &&
        state.revealedRoster && (
          <div className="p-5 rounded-2xl bg-[#1A1D24] border border-white/10 space-y-3">
            <h3 className="text-xs font-bold text-amber-400">
              فهرست نقش‌ها (ویژه تماشاگران — فعال‌شده توسط میزبان)
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              {state.revealedRoster.map((r) => (
                <div key={r.playerId} className="p-2.5 rounded-lg bg-[#0F1115] text-zinc-200">
                  <span className="font-bold text-white">{r.name}: </span>
                  <span>{r.roleDisplayName}</span>
                </div>
              ))}
            </div>
          </div>
        )}

      {/* =====================================================================
          HOST-ONLY CONTROL BAR OVERLAY (Visually distinct, unobtrusive bottom bar)
          CRITICAL: Rendered ONLY if `state.isHost === true`. Never exposes roles.
         ===================================================================== */}
      {state.isHost && (
        <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#1A1D24]/95 backdrop-blur-md border-t border-[#4FD1C5]/30 px-4 py-3 shadow-2xl">
          <div className="max-w-5xl mx-auto flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-1 rounded-md bg-[#4FD1C5]/15 text-[#4FD1C5] text-xs font-bold">
                پنل کنترل میزبان
              </span>

              {state.phase === GamePhase.lobby && (
                <span className="text-xs text-zinc-300">
                  {state.players.length} بازیکن متصل ·{' '}
                  {roleValidation.isValid ? 'آماده شروع' : roleValidation.errorMessage}
                </span>
              )}

              {state.phase === GamePhase.roleReveal && (
                <span className="text-xs text-zinc-300">
                  آمادگی بازیکنان: {readyPlayersCount} از {state.players.length}
                </span>
              )}

              {state.phase === GamePhase.night && state.hostNightStatus && (
                <div className="text-xs text-zinc-300 flex flex-wrap items-center gap-2">
                  <span>
                    عملیات شب ثبت‌شده:{' '}
                    <strong className="font-mono text-white tabular-nums">
                      {state.hostNightStatus.submittedCount} /{' '}
                      {state.hostNightStatus.totalExpectedActions}
                    </strong>
                  </span>
                  {state.hostNightStatus.submittedPlayerNames.length > 0 && (
                    <span className="text-zinc-400">
                      (اقدام‌کنندگان: {state.hostNightStatus.submittedPlayerNames.join('، ')})
                    </span>
                  )}
                </div>
              )}

              {state.phase === GamePhase.vote && (
                <span className="text-xs text-zinc-300">
                  آرای ثبت‌شده: {state.totalVotesCast} از {state.totalEligibleVoters}
                </span>
              )}
            </div>

            {/* Host Action Buttons per Phase */}
            <div className="flex items-center gap-2.5">
              {state.phase === GamePhase.lobby && (
                <>
                  <button
                    type="button"
                    onClick={onOpenConfigureRoles}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#232730] hover:bg-zinc-700 text-xs font-bold text-white transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Settings className="w-4 h-4 text-[#4FD1C5]" />
                    <span>{Strings.configureRolesBtn}</span>
                  </button>
                  <button
                    type="button"
                    disabled={!roleValidation.isValid}
                    onClick={onStartGame}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#4FD1C5] hover:bg-[#38B2AC] disabled:opacity-40 disabled:pointer-events-none text-xs font-bold text-[#0F1115] transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Play className="w-4 h-4" />
                    <span>{Strings.startGameBtn}</span>
                  </button>
                </>
              )}

              {state.phase === GamePhase.roleReveal && (
                <button
                  type="button"
                  onClick={() => onAdvancePhase(true)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#4FD1C5] hover:bg-[#38B2AC] text-xs font-bold text-[#0F1115] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <FastForward className="w-4 h-4" />
                  <span>{Strings.hostContinueToNightBtn}</span>
                </button>
              )}

              {state.phase === GamePhase.night && state.hostNightStatus && (
                <>
                  {state.hostNightStatus.allSubmitted ? (
                    <button
                      type="button"
                      onClick={() => onAdvancePhase(false)}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#4FD1C5] hover:bg-[#38B2AC] text-xs font-bold text-[#0F1115] transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <Sun className="w-4 h-4" />
                      <span>{Strings.hostEndNightBtn}</span>
                    </button>
                  ) : !confirmForceEndNight ? (
                    <button
                      type="button"
                      onClick={() => setConfirmForceEndNight(true)}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#232730] hover:bg-zinc-700 text-xs font-bold text-amber-400 transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <AlertTriangle className="w-4 h-4" />
                      <span>پایان شب (اجباری)</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-amber-400">همه اقدام نکرده‌اند؛ مطمئنید؟</span>
                      <button
                        type="button"
                        onClick={() => {
                          setConfirmForceEndNight(false);
                          onAdvancePhase(true);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-[#E5484D] text-white text-xs font-bold cursor-pointer"
                      >
                        بله، پایان شب
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmForceEndNight(false)}
                        className="px-2.5 py-1.5 rounded-lg bg-[#232730] text-zinc-300 text-xs cursor-pointer"
                      >
                        لغو
                      </button>
                    </div>
                  )}
                </>
              )}

              {state.phase === GamePhase.day && (
                <button
                  type="button"
                  onClick={() => onAdvancePhase(true)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#4FD1C5] hover:bg-[#38B2AC] text-xs font-bold text-[#0F1115] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Vote className="w-4 h-4" />
                  <span>{Strings.hostStartVotingBtn}</span>
                </button>
              )}

              {state.phase === GamePhase.vote && (
                <button
                  type="button"
                  onClick={() => onAdvancePhase(true)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#E5484D] hover:bg-red-600 text-xs font-bold text-white transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Check className="w-4 h-4" />
                  <span>{Strings.hostEndVotingBtn}</span>
                </button>
              )}

              {state.phase === GamePhase.gameOver && (
                <button
                  type="button"
                  onClick={onResetToLobby}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#4FD1C5] hover:bg-[#38B2AC] text-xs font-bold text-[#0F1115] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>{Strings.backToLobbyHostBtn}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
