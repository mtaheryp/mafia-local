import React, { useState, useEffect } from 'react';
import { CheckCircle2, Play, FileCode, Terminal, X, Copy, Check } from 'lucide-react';
import {
   runAllEngineAndPrivacyTests,
  TestCaseResult,
} from '../core/tests/engine_and_privacy_suite';
import {
  FLUTTER_PROJECT_TREE,
  FLUTTER_SOURCE_HIGHLIGHTS,
} from '../data/flutter_files_preview';

interface FlutterArchitectureModalProps {
  isOpen: boolean;
  initialTab?: 'tests' | 'flutter_code';
  onClose: () => void;
}

export const FlutterArchitectureModal: React.FC<FlutterArchitectureModalProps> = ({
  isOpen,
  initialTab = 'tests',
  onClose,
}) => {
  const [tab, setTab] = useState<'tests' | 'flutter_code'>(initialTab);
  const [testResults, setTestResults] = useState<TestCaseResult[]>([]);
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (isOpen && tab === 'tests') {
      setTestResults(runAllEngineAndPrivacyTests());
    }
  }, [isOpen, tab]);

  if (!isOpen) return null;

  const handleRunTestsAgain = () => {
    setTestResults(runAllEngineAndPrivacyTests());
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const passedCount = testResults.filter((t) => t.passed).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-4xl rounded-2xl bg-[#1A1D24] border border-white/10 shadow-2xl overflow-hidden my-6">
        {/* Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setTab('tests')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                tab === 'tests'
                  ? 'bg-[#4FD1C5] text-[#0F1115]'
                  : 'bg-[#0F1115] text-zinc-300 hover:text-white'
              }`}
            >
              <Terminal className="w-4 h-4" />
              <span>تست‌های واحد و تست عدم نشت اطلاعات (§6)</span>
            </button>
            <button
              type="button"
              onClick={() => setTab('flutter_code')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                tab === 'flutter_code'
                  ? 'bg-[#4FD1C5] text-[#0F1115]'
                  : 'bg-[#0F1115] text-zinc-300 hover:text-white'
              }`}
            >
              <FileCode className="w-4 h-4" />
              <span>ساختار پروژه Flutter و کدهای Dart (§3 & §7)</span>
            </button>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-white/5 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {tab === 'tests' ? (
          <div className="p-6 space-y-5 max-h-[78vh] overflow-y-auto">
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-[#0F1115] border border-[#4FD1C5]/30">
              <div>
                <h3 className="text-sm font-bold text-white">
                  نتیجه اجرای زنده تست‌های موتور و پروتکل وب‌سوکت
                </h3>
                <p className="text-xs text-zinc-400 mt-1">
                  شامل تست شبیه‌سازی کامل ۶ کلاینت روی وب‌سوکت و اسکن تمام بسته‌های خروجی برای تضمین عدم افشای نقش سایر بازیکنان
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono font-bold text-[#4FD1C5] tabular-nums">
                  {passedCount} / {testResults.length} PASSED
                </span>
                <button
                  type="button"
                  onClick={handleRunTestsAgain}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#4FD1C5] text-[#0F1115] text-xs font-bold hover:bg-[#38B2AC] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>اجرای مجدد تست‌ها</span>
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {testResults.map((res) => (
                <div
                  key={res.id}
                  className="p-4 rounded-xl bg-[#0F1115] border border-white/5 space-y-1.5"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#4FD1C5] shrink-0" />
                      <span className="text-sm font-bold text-white">{res.title}</span>
                    </div>
                    <span className="text-xs font-mono text-zinc-400 tabular-nums shrink-0">
                      {res.durationMs} ms · {res.category === 'integration_privacy' ? 'یکپارچگی وب‌سوکت' : 'تست واحد'}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-300 pr-6 leading-relaxed">{res.details}</p>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 max-h-[78vh] overflow-y-auto">
            {/* Left column: Tree & File selector */}
            <div className="lg:col-span-5 space-y-4">
              <div className="p-4 rounded-xl bg-[#0F1115] border border-white/5">
                <h4 className="text-xs font-bold text-[#4FD1C5] mb-2">
                  درخت کامل فایل‌های پروژه فلاتر (/flutter_project)
                </h4>
                <pre
                  dir="ltr"
                  className="text-[11px] font-mono text-zinc-300 overflow-x-auto leading-relaxed"
                >
                  {FLUTTER_PROJECT_TREE}
                </pre>
              </div>

              <div className="space-y-1.5">
                {FLUTTER_SOURCE_HIGHLIGHTS.map((item, idx) => (
                  <button
                    key={item.path}
                    type="button"
                    onClick={() => setSelectedFileIndex(idx)}
                    className={`w-full text-right p-3 rounded-xl border transition-colors cursor-pointer ${
                      selectedFileIndex === idx
                        ? 'bg-[#232730] border-[#4FD1C5]/40 text-white'
                        : 'bg-[#0F1115] border-white/5 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <div className="font-mono text-xs font-bold text-[#4FD1C5]" dir="ltr">
                      {item.path}
                    </div>
                    <div className="text-xs text-zinc-300 mt-1">{item.description}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Right column: Code viewer */}
            <div className="lg:col-span-7 flex flex-col rounded-xl bg-[#0F1115] border border-white/5 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 bg-[#232730] border-b border-white/5">
                <span className="font-mono text-xs text-white" dir="ltr">
                  {FLUTTER_SOURCE_HIGHLIGHTS[selectedFileIndex].path}
                </span>
                <button
                  type="button"
                  onClick={() =>
                    handleCopyCode(FLUTTER_SOURCE_HIGHLIGHTS[selectedFileIndex].code)
                  }
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#1A1D24] text-xs text-zinc-200 hover:text-white cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#4FD1C5]" />
                      <span>کپی شد</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>کپی کد</span>
                    </>
                  )}
                </button>
              </div>
              <pre
                dir="ltr"
                className="p-4 text-xs font-mono text-zinc-200 overflow-x-auto leading-relaxed flex-1"
              >
                {FLUTTER_SOURCE_HIGHLIGHTS[selectedFileIndex].code}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
