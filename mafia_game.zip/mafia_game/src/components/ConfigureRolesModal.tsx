import React, { useState, useEffect } from 'react';
import { Minus, Plus, RotateCcw, ShieldAlert, CheckCircle2, X } from 'lucide-react';
import { ClientPersonalizedState } from '../core/engine/game_state';
import { RoleIds } from '../core/roles/role_ids';
import { RoleTeam } from '../core/roles/role_module';
import {
  buildSuggestedRoleCounts,
  RuleSet,
  validateRoleConfiguration,
} from '../core/rules/rule_set';
import { Strings } from '../core/strings';

interface ConfigureRolesModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: ClientPersonalizedState;
  onSaveConfig: (roleCounts: Record<string, number>, rules: Partial<RuleSet>) => void;
  onStartGame: () => void;
}

export const ConfigureRolesModal: React.FC<ConfigureRolesModalProps> = ({
  isOpen,
  onClose,
  state,
  onSaveConfig,
  onStartGame,
}) => {
  const totalPlayers = state.players.length;
  const [counts, setCounts] = useState<Record<string, number>>(state.roleCountsConfig);
  const [rules, setRules] = useState<RuleSet>(state.rules);

  useEffect(() => {
    setCounts(state.roleCountsConfig);
    setRules(state.rules);
  }, [state.roleCountsConfig, state.rules, isOpen]);

  if (!isOpen) return null;

  const configurableRoles = state.availableRolesMeta.filter(
    (r) => r.id !== RoleIds.villager
  );
  const validation = validateRoleConfiguration(
    counts,
    totalPlayers,
    rules.minPlayersToStart
  );

  const handleAdjustRole = (roleId: string, delta: number, minCount: number) => {
    const current = counts[roleId] ?? 0;
    const nextVal = Math.max(minCount, current + delta);
    const nextCounts = { ...counts, [roleId]: nextVal };
    setCounts(nextCounts);
    onSaveConfig(nextCounts, rules);
  };

  const handleApplySuggested = () => {
    const suggested = buildSuggestedRoleCounts(Math.max(totalPlayers, 6));
    setCounts(suggested);
    onSaveConfig(suggested, rules);
  };

  const handleToggleRule = <K extends keyof RuleSet>(key: K, value: RuleSet[K]) => {
    const nextRules = { ...rules, [key]: value };
    setRules(nextRules);
    onSaveConfig(counts, nextRules);
  };

  const getTeamColorText = (team: RoleTeam) => {
    if (team === RoleTeam.mafia) return 'text-[#E5484D]';
    if (team === RoleTeam.town) return 'text-[#4FD1C5]';
    return 'text-[#F5A524]';
  };

  const getTeamLabel = (team: RoleTeam) => {
    if (team === RoleTeam.mafia) return Strings.teamMafia;
    if (team === RoleTeam.town) return Strings.teamTown;
    return Strings.teamNeutral;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-2xl rounded-2xl bg-[#1A1D24] border border-white/10 shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <div>
            <h2 className="text-lg font-bold text-white">{Strings.roleConfigTitle}</h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              {Strings.totalPlayersLabel}{' '}
              <span className="font-mono font-semibold text-white tabular-nums">
                {totalPlayers}
              </span>{' '}
              نفر
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleApplySuggested}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#232730] hover:bg-zinc-700 text-xs font-medium text-zinc-200 transition-colors cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{Strings.applyPresetBtn}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
              aria-label="بستن"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Role Steppers */}
          <div className="space-y-3">
            {configurableRoles.map((role) => {
              const val = counts[role.id] ?? 0;
              return (
                <div
                  key={role.id}
                  className="flex items-center justify-between gap-4 p-4 rounded-xl bg-[#0F1115] border border-white/5"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-sm">
                      <span className="font-bold text-white">{role.displayName}</span>
                      <span aria-hidden="true" className="text-zinc-600">
                        ·
                      </span>
                      <span className={`text-xs font-medium ${getTeamColorText(role.team)}`}>
                        {getTeamLabel(role.team)}
                      </span>
                    </div>
                    <p className="text-xs text-zinc-400 leading-relaxed">
                      {role.shortDescription}
                    </p>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleAdjustRole(role.id, -1, role.minCount)}
                      disabled={val <= role.minCount}
                      className="w-10 h-10 rounded-xl bg-[#1A1D24] border border-white/10 flex items-center justify-center text-white disabled:opacity-30 hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-8 text-center font-mono text-lg font-bold text-white tabular-nums">
                      {val}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleAdjustRole(role.id, 1, role.minCount)}
                      className="w-10 h-10 rounded-xl bg-[#1A1D24] border border-white/10 flex items-center justify-center text-white hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}

            {/* Auto-computed Villager Row (Read-Only) */}
            <div className="flex items-center justify-between gap-4 p-4 rounded-xl bg-[#0F1115]/60 border border-[#4FD1C5]/20">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-sm">
                  <span className="font-bold text-[#4FD1C5]">شهروند ساده (محاسبه خودکار)</span>
                  <span aria-hidden="true" className="text-zinc-600">
                    ·
                  </span>
                  <span className="text-xs text-zinc-400">باقی‌مانده بازیکنان</span>
                </div>
                <p className="text-xs text-zinc-400">{Strings.villagerAutoComputedNote}</p>
              </div>
              <div className="px-4 py-2 rounded-xl bg-[#1A1D24] border border-white/5 font-mono text-lg font-bold text-[#4FD1C5] tabular-nums">
                {validation.villagerCount}
              </div>
            </div>
          </div>

          {/* Validation Status Banner */}
          <div
            className={`p-4 rounded-xl border flex items-center gap-3 text-xs leading-relaxed ${
              validation.isValid
                ? 'bg-[#4FD1C5]/10 border-[#4FD1C5]/30 text-[#4FD1C5]'
                : 'bg-[#E5484D]/10 border-[#E5484D]/30 text-[#E5484D]'
            }`}
          >
            {validation.isValid ? (
              <>
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>
                  ترکیب نقش‌ها معتبر است ({totalPlayers} بازیکن: {counts[RoleIds.mafia] ?? 1} مافیا و{' '}
                  {totalPlayers - (counts[RoleIds.mafia] ?? 1)} شهروند). آماده شروع بازی!
                </span>
              </>
            ) : (
              <>
                <ShieldAlert className="w-5 h-5 shrink-0" />
                <span>{validation.errorMessage}</span>
              </>
            )}
          </div>

          {/* Configurable Rules Section */}
          <div className="pt-4 border-t border-white/10 space-y-3">
            <h3 className="text-sm font-bold text-white">{Strings.rulesSectionTitle}</h3>

            <label className="flex items-center justify-between gap-4 p-3 rounded-xl bg-[#0F1115] cursor-pointer">
              <span className="text-xs text-zinc-200">{Strings.ruleRevealRoleOnDeath}</span>
              <input
                type="checkbox"
                checked={rules.revealRoleOnDeath}
                onChange={(e) => handleToggleRule('revealRoleOnDeath', e.target.checked)}
                className="w-4 h-4 accent-[#4FD1C5]"
              />
            </label>

            <label className="flex items-center justify-between gap-4 p-3 rounded-xl bg-[#0F1115] cursor-pointer">
              <span className="text-xs text-zinc-200">{Strings.ruleDoctorSelfProtect}</span>
              <input
                type="checkbox"
                checked={rules.doctorCanSelfProtect}
                onChange={(e) => handleToggleRule('doctorCanSelfProtect', e.target.checked)}
                className="w-4 h-4 accent-[#4FD1C5]"
              />
            </label>

            <label className="flex items-center justify-between gap-4 p-3 rounded-xl bg-[#0F1115] cursor-pointer">
              <span className="text-xs text-zinc-200">{Strings.ruleDeadSpectatorSeeRoles}</span>
              <input
                type="checkbox"
                checked={rules.revealRolesToDeadSpectators}
                onChange={(e) =>
                  handleToggleRule('revealRolesToDeadSpectators', e.target.checked)
                }
                className="w-4 h-4 accent-[#4FD1C5]"
              />
            </label>

            <label className="flex items-center justify-between gap-4 p-3 rounded-xl bg-[#0F1115] cursor-pointer">
              <span className="text-xs text-zinc-200">{Strings.ruleEnableDayChat}</span>
              <input
                type="checkbox"
                checked={rules.enableDayChat}
                onChange={(e) => handleToggleRule('enableDayChat', e.target.checked)}
                className="w-4 h-4 accent-[#4FD1C5]"
              />
            </label>

            <div className="flex items-center justify-between gap-4 p-3 rounded-xl bg-[#0F1115]">
              <span className="text-xs text-zinc-200">{Strings.ruleDiscussionTimerSeconds}</span>
              <div className="flex items-center gap-2">
                {[60, 120, 180].map((sec) => (
                  <button
                    key={sec}
                    type="button"
                    onClick={() => handleToggleRule('discussionTimerSeconds', sec)}
                    className={`px-3 py-1 rounded-lg text-xs font-mono tabular-nums cursor-pointer transition-colors ${
                      rules.discussionTimerSeconds === sec
                        ? 'bg-[#4FD1C5] text-[#0F1115] font-bold'
                        : 'bg-[#1A1D24] text-zinc-300 hover:bg-white/10'
                    }`}
                  >
                    {sec}s
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 bg-[#0F1115] border-t border-white/10">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-[#232730] hover:bg-zinc-700 text-xs font-medium text-zinc-200 transition-colors cursor-pointer"
          >
            ذخیره و بازگشت به لابی
          </button>
          <button
            type="button"
            disabled={!validation.isValid}
            onClick={() => {
              onClose();
              onStartGame();
            }}
            className="px-5 py-2.5 rounded-xl bg-[#4FD1C5] hover:bg-[#38B2AC] disabled:opacity-40 disabled:pointer-events-none text-xs font-bold text-[#0F1115] transition-colors cursor-pointer"
          >
            {Strings.startGameBtn}
          </button>
        </div>
      </div>
    </div>
  );
};
