/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  Wifi,
  WifiOff,
  QrCode,
  Users,
  Smartphone,
  Plus,
  Play,
  ShieldCheck,
  AlertCircle,
  RefreshCw,
  Copy,
  Check,
  RotateCcw,
} from 'lucide-react';
import { ConfigureRolesModal } from './components/ConfigureRolesModal';
import { FlutterArchitectureModal } from './components/FlutterArchitectureModal';
import { SharedPlayerScreens } from './components/SharedPlayerScreens';
import { RoleTeam } from './core/roles/role_module';
import { Strings } from './core/strings';
import { useMafiaMultiClient } from './state/game_client';

interface NetworkInfoResponse {
  wifiConnected: boolean;
  lanIp: string | null;
  lanPort: number;
  lanUrl: string | null;
  liveJoinUrl: string;
  foregroundServiceRunning: boolean;
  wakeLockAcquired: boolean;
  playerCount: number;
  phase: string;
}

export default function App() {
  const {
    slots,
    activeSlotId,
    setActiveSlotId,
    statesBySlot,
    activeState,
    activeConnected,
    activeError,
    clearActiveError,
    actions,
    spawnTestPlayersUpToSix,
    addSingleSimulatedDevice,
    resetAllLocalSessions,
  } = useMafiaMultiClient();

  // Host onboarding state (§2.2 exact steps)
  const [hostStep, setHostStep] = useState<'splash' | 'qr_created' | 'joined_game'>(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('join') === '1') return 'joined_game';
    return 'splash';
  });

  const [networkInfo, setNetworkInfo] = useState<NetworkInfoResponse | null>(null);
  const [loadingNet, setLoadingNet] = useState(false);
  const [joinNameInput, setJoinNameInput] = useState('امیر');
  const [showQrModal, setShowQrModal] = useState(false);
  const [showConfigRolesModal, setShowConfigRolesModal] = useState(false);
  const [archModalState, setArchModalState] = useState<{
    open: boolean;
    tab: 'tests' | 'flutter_code';
  }>({ open: false, tab: 'tests' });
  const [copiedUrl, setCopiedUrl] = useState(false);

  const fetchNetworkInfo = useCallback(async () => {
    setLoadingNet(true);
    try {
      const res = await fetch('/api/network-info');
      const data = (await res.json()) as NetworkInfoResponse;
      setNetworkInfo(data);
    } catch {
      // ignore
    } finally {
      setLoadingNet(false);
    }
  }, []);

  useEffect(() => {
    fetchNetworkInfo();
  }, [fetchNetworkInfo]);

  // Automatically transition to joined_game if activeSlot already has state from server
  useEffect(() => {
    if (activeState && hostStep === 'splash') {
      setHostStep('joined_game');
    }
  }, [activeState, hostStep]);

  const handleHostCreateGame = async () => {
    await fetchNetworkInfo();
    setHostStep('qr_created');
  };

  const handleToggleWifiSimulation = async (wifiOff: boolean) => {
    const res = await fetch('/api/simulate-network', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ wifiOff }),
    });
    const updated = await res.json();
    setNetworkInfo((prev) => (prev ? { ...prev, ...updated } : prev));
  };

  const handleTogglePortFallbackSimulation = async (portFallback: boolean) => {
    const res = await fetch('/api/simulate-network', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ portFallback }),
    });
    const updated = await res.json();
    setNetworkInfo((prev) => (prev ? { ...prev, ...updated } : prev));
  };

  const handleJoinSubmit = (e: React.FormEvent, preferHost: boolean) => {
    e.preventDefault();
    const trimmed = joinNameInput.trim() || 'بازیکن';
    actions.join(trimmed, preferHost);
    setHostStep('joined_game');
  };

  const qrTargetUrl =
    networkInfo?.liveJoinUrl
      ? `${networkInfo.liveJoinUrl}?join=1`
      : `${window.location.origin}?join=1`;

  const displayLanUrl = networkInfo?.lanUrl ?? 'http://192.168.1.100:8080';

  const handleCopyUrl = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 1800);
  };

  return (
    <div className="min-h-screen bg-[#0F1115] text-[#F3F4F6] flex flex-col">
      {/* =====================================================================
          TOP BAR CONTRACT (3 Zones separated by gap-8)
         ===================================================================== */}
      <header className="flex items-center justify-between gap-8 px-6 py-4 bg-[#1A1D24] border-b border-white/10">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            if (activeState) setHostStep('joined_game');
          }}
          className="text-lg font-extrabold tracking-tight text-white whitespace-nowrap shrink-0"
        >
          {Strings.appName}
        </a>

        {/* Zone 2: 4 clean single-line navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-zinc-300">
          <button
            type="button"
            onClick={() => {
              if (activeState) setHostStep('joined_game');
              else setHostStep('splash');
            }}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            میز بازی
          </button>
          <button
            type="button"
            onClick={() => setShowQrModal(true)}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            کد QR و شبکه محلی
          </button>
          <button
            type="button"
            onClick={() => setArchModalState({ open: true, tab: 'tests' })}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            تست‌های عدم نشت اطلاعات
          </button>
          <button
            type="button"
            onClick={() => setArchModalState({ open: true, tab: 'flutter_code' })}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            کدهای کامل Flutter
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => setShowQrModal(true)}
            className="px-4 py-2 text-xs font-bold text-[#0F1115] bg-[#4FD1C5] rounded-xl hover:bg-[#38B2AC] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            اسکن QR و اتصال بازیکنان
          </button>
        </div>
      </header>

      {/* =====================================================================
          MULTI-DEVICE SIMULATOR & WORKSPACE TOOLBAR (Below Header)
          Allows switching between Host Phone and Player 2..N Mobile Browsers
         ===================================================================== */}
      <div className="bg-[#1A1D24]/60 border-b border-white/5 px-6 py-2.5">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 overflow-x-auto py-1">
            <span className="text-xs text-zinc-400 flex items-center gap-1.5 shrink-0 ml-2">
              <Smartphone className="w-3.5 h-3.5 text-[#4FD1C5]" />
              <span>دستگاه فعال (شبیه‌ساز چند گوشی):</span>
            </span>

            {slots.map((slot, idx) => {
              const st = statesBySlot[slot.slotId];
              const isSelected = slot.slotId === activeSlotId;
              const roleBadge =
                st?.mySecretRole && isSelected ? ` · ${st.mySecretRole.displayName}` : '';

              return (
                <button
                  key={slot.slotId}
                  type="button"
                  onClick={() => {
                    setActiveSlotId(slot.slotId);
                    if (statesBySlot[slot.slotId]) {
                      setHostStep('joined_game');
                    }
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isSelected
                      ? 'bg-[#4FD1C5] text-[#0F1115] font-bold shadow-sm'
                      : 'bg-[#0F1115] text-zinc-300 hover:text-white border border-white/5'
                  }`}
                >
                  {idx + 1}. {st?.players.find((p) => p.id === st.selfPlayerId)?.name ?? slot.label}
                  {st?.isHost ? ' (میزبان)' : ''}
                  {roleBadge}
                </button>
              );
            })}

            <button
              type="button"
              onClick={() => addSingleSimulatedDevice()}
              className="px-2.5 py-1.5 rounded-lg bg-[#232730] hover:bg-zinc-700 text-xs text-zinc-200 flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
              title="افزودن یک مرورگر بازیکن جدید"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>افزودن بازیکن</span>
            </button>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {slots.length < 6 && (
              <button
                type="button"
                onClick={() => {
                  spawnTestPlayersUpToSix();
                  setHostStep('joined_game');
                }}
                className="px-3 py-1.5 rounded-lg bg-[#4FD1C5]/15 hover:bg-[#4FD1C5]/25 border border-[#4FD1C5]/30 text-xs font-bold text-[#4FD1C5] transition-colors whitespace-nowrap cursor-pointer"
              >
                ورود خودکار ۶ بازیکن برای تست سریع
              </button>
            )}
            <button
              type="button"
              onClick={async () => {
                await resetAllLocalSessions();
                setHostStep('splash');
              }}
              className="px-2.5 py-1.5 rounded-lg bg-[#0F1115] hover:bg-white/5 border border-white/10 text-xs text-zinc-400 hover:text-white flex items-center gap-1 whitespace-nowrap cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>شروع نشست کاملاً جدید</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-8">
        {/* Error Alert Banner */}
        {activeError && (
          <div className="mb-6 p-4 rounded-xl bg-[#E5484D]/15 border border-[#E5484D]/40 flex items-center justify-between gap-4 text-xs text-[#E5484D]">
            <div className="flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{activeError}</span>
            </div>
            <button
              type="button"
              onClick={clearActiveError}
              className="px-2.5 py-1 rounded-lg bg-[#E5484D]/20 hover:bg-[#E5484D]/30 text-white cursor-pointer"
            >
              بستن
            </button>
          </div>
        )}

        {/* ===================================================================
            STEP 1: HOST HOME / SPLASH SCREEN (§2.2.1 & §2.2.2)
           =================================================================== */}
        {hostStep === 'splash' && !activeState && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            {/* Right Hero Column: Host Create Game */}
            <div className="lg:col-span-7 p-8 rounded-2xl bg-[#1A1D24] border border-white/10 flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <div className="text-xs text-[#4FD1C5] font-semibold">
                  معماری آفلاین شبکه محلی (Flutter Host APK + Embedded Web Server)
                </div>
                <h1 className="text-3xl sm:text-4xl font-extrabold text-white leading-tight">
                  {Strings.appName} — اجرای بازی مافیا روی Wi-Fi بدون نیاز به اینترنت
                </h1>
                <p className="text-sm text-zinc-300 leading-relaxed">
                  یک نفر برنامه میزبان را باز کرده و بازی را می‌سازد. سایر بازیکنان (۶ تا ۱۵ نفر) فقط با دوربین گوشی کد QR را اسکن می‌کنند و بدون نصب هیچ برنامه‌ای در مرورگر موبایل خود وارد بازی می‌شوند.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                  <div className="p-3.5 rounded-xl bg-[#0F1115] border border-white/5">
                    <div className="text-xs font-bold text-[#4FD1C5]">۱۰۰٪ محرمانه</div>
                    <p className="text-[11px] text-zinc-400 mt-1">
                      هر بازیکن و حتی میزبان فقط نقش مخفی خودش را می‌بیند.
                    </p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-[#0F1115] border border-white/5">
                    <div className="text-xs font-bold text-[#4FD1C5]">بدون نصب برای بازیکنان</div>
                    <p className="text-[11px] text-zinc-400 mt-1">
                      سرور داخلی HTTP/WebSocket کلاینت وب را روی LAN سرو می‌کند.
                    </p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-[#0F1115] border border-white/5">
                    <div className="text-xs font-bold text-[#4FD1C5]">پلاگین‌پذیر (RoleModule)</div>
                    <p className="text-[11px] text-zinc-400 mt-1">
                      افزودن نقش جدید فقط با ساخت یک فایل مستقل بدون تغییر در موتور.
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-4 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={handleHostCreateGame}
                  className="px-6 py-3.5 rounded-xl bg-[#4FD1C5] hover:bg-[#38B2AC] text-[#0F1115] font-bold text-sm flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <Play className="w-4 h-4" />
                  <span>{Strings.createGame}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    spawnTestPlayersUpToSix();
                    setHostStep('joined_game');
                  }}
                  className="px-5 py-3.5 rounded-xl bg-[#232730] hover:bg-zinc-700 text-white font-bold text-sm flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <Users className="w-4 h-4 text-[#4FD1C5]" />
                  <span>شروع سریع با ۶ بازیکن آزمایشی</span>
                </button>
              </div>
            </div>

            {/* Left Column: Direct Player Join Card (For players who scanned QR) */}
            <div className="lg:col-span-5 p-8 rounded-2xl bg-[#1A1D24] border border-white/10 flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <h2 className="text-xl font-bold text-white">ورود مستقیم به لابی بازیکنان</h2>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  اگر کد QR میزبان را اسکن کرده‌اید، نام خود را وارد کنید تا وارد لابی شوید:
                </p>

                <form
                  onSubmit={(e) => handleJoinSubmit(e, slots.length === 1)}
                  className="space-y-4 pt-2"
                >
                  <div>
                    <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                      {Strings.enterYourName}
                    </label>
                    <input
                      type="text"
                      required
                      value={joinNameInput}
                      onChange={(e) => setJoinNameInput(e.target.value)}
                      placeholder={Strings.namePlaceholder}
                      className="w-full px-4 py-3 rounded-xl bg-[#0F1115] border border-white/10 text-sm text-white focus:outline-none focus:border-[#4FD1C5]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full h-12 rounded-xl bg-[#232730] hover:bg-zinc-700 text-white font-bold text-sm transition-colors cursor-pointer"
                  >
                    {Strings.joinLobbyButton}
                  </button>
                </form>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-zinc-400">
                <span>وضعیت وب‌سوکت سرور:</span>
                <span className="text-[#4FD1C5] font-medium">
                  {activeConnected ? 'متصل و آماده' : 'در حال اتصال...'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            STEP 2: HOST QR & LAN SERVER SCREEN (§2.2.3 & §2.2.4 & §5 Wi-Fi Error)
           =================================================================== */}
        {hostStep === 'qr_created' && (
          <div className="max-w-3xl mx-auto space-y-6">
            {/* Blocking Error Screen if Wi-Fi is Off / No LAN IP (§2.1 & §5) */}
            {networkInfo && !networkInfo.wifiConnected ? (
              <div className="p-8 rounded-2xl bg-[#1A1D24] border-2 border-[#E5484D]/50 text-center space-y-5">
                <div className="w-16 h-16 rounded-2xl bg-[#E5484D]/15 flex items-center justify-center mx-auto">
                  <WifiOff className="w-8 h-8 text-[#E5484D]" />
                </div>
                <h2 className="text-xl font-bold text-white">{Strings.wifiOffErrorTitle}</h2>
                <p className="text-sm text-zinc-300 max-w-md mx-auto leading-relaxed">
                  {Strings.wifiOffErrorDesc}
                </p>
                <div className="flex items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => handleToggleWifiSimulation(false)}
                    className="px-5 py-2.5 rounded-xl bg-[#4FD1C5] text-[#0F1115] text-xs font-bold flex items-center gap-2 cursor-pointer"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>{Strings.retryNetworkCheck} (اتصال مجدد Wi-Fi)</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-6 sm:p-8 rounded-2xl bg-[#1A1D24] border border-white/10 space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/10">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-[#4FD1C5] font-medium">
                      <ShieldCheck className="w-4 h-4" />
                      <span>{Strings.foregroundServiceActive}</span>
                    </div>
                    <h2 className="text-xl font-bold text-white mt-1">
                      سرور محلی بازی راه‌اندازی شد
                    </h2>
                  </div>

                  {/* Interactive Edge-Case Toggles to test §5 (Wi-Fi Off & Port 8081 Fallback) */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleTogglePortFallbackSimulation(networkInfo?.lanPort === 8080)}
                      className="px-3 py-1.5 rounded-lg bg-[#0F1115] border border-white/10 text-[11px] text-zinc-300 hover:text-white cursor-pointer"
                    >
                      {networkInfo?.lanPort === 8081
                        ? 'بازگشت به پورت ۸۰۸۰'
                        : 'تست اشغال بودن پورت ۸۰۸۰ (Fallback 8081)'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleToggleWifiSimulation(true)}
                      className="px-3 py-1.5 rounded-lg bg-[#0F1115] border border-white/10 text-[11px] text-zinc-300 hover:text-[#E5484D] cursor-pointer"
                    >
                      تست قطع Wi-Fi
                    </button>
                  </div>
                </div>

                {networkInfo?.lanPort === 8081 && (
                  <div className="p-3 rounded-xl bg-[#F5A524]/15 border border-[#F5A524]/40 text-xs text-[#F5A524]">
                    {Strings.portFallbackNotice} (پورت فعلی: ۸۰۸۱)
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                  {/* QR Code Box */}
                  <div className="md:col-span-5 flex flex-col items-center justify-center p-5 rounded-2xl bg-white text-[#0F1115]">
                    <QRCodeSVG value={qrTargetUrl} size={190} level="M" />
                    <span className="mt-3 text-xs font-bold text-zinc-800">
                      اسکن با دوربین موبایل بازیکنان
                    </span>
                  </div>

                  {/* URL & Host "I'm also playing" Form */}
                  <div className="md:col-span-7 space-y-4">
                    <div className="p-4 rounded-xl bg-[#0F1115] border border-white/5 space-y-2">
                      <div className="text-xs font-bold text-[#4FD1C5]">
                        {Strings.connectSameWifiInstruction}
                      </div>
                      <p className="text-xs text-zinc-400 leading-relaxed">
                        {Strings.scanQrInstruction}
                      </p>
                      <div
                        dir="ltr"
                        className="p-2.5 rounded-lg bg-[#1A1D24] font-mono text-sm font-bold text-white text-center select-all"
                      >
                        {displayLanUrl}
                      </div>
                      <div className="flex items-center justify-between gap-2 pt-1">
                        <span className="text-[11px] text-zinc-400 truncate" dir="ltr">
                          {qrTargetUrl}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopyUrl(qrTargetUrl)}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#232730] text-xs text-white hover:bg-zinc-700 shrink-0 cursor-pointer"
                        >
                          {copiedUrl ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-[#4FD1C5]" />
                              <span>کپی شد</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>کپی لینک</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Step 4: Host taps "I'm also playing" -> enters own name -> joins lobby */}
                    <form
                      onSubmit={(e) => handleJoinSubmit(e, true)}
                      className="p-4 rounded-xl bg-[#0F1115] border border-[#4FD1C5]/30 space-y-3"
                    >
                      <div className="text-xs font-bold text-white">
                        {Strings.joinAsHostPlayer} (ورود میزبان به عنوان بازیکن)
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          required
                          value={joinNameInput}
                          onChange={(e) => setJoinNameInput(e.target.value)}
                          placeholder="نام شما (میزبان)..."
                          className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#1A1D24] border border-white/10 text-sm text-white focus:outline-none focus:border-[#4FD1C5]"
                        />
                        <button
                          type="submit"
                          className="px-5 py-2.5 rounded-xl bg-[#4FD1C5] hover:bg-[#38B2AC] text-[#0F1115] font-bold text-xs whitespace-nowrap cursor-pointer"
                        >
                          {Strings.joinAsHostPlayer}
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ===================================================================
            STEP 3: SHARED PLAYER + HOST GAME VIEW (§2.2.5 – §2.2.9)
           =================================================================== */}
        {hostStep === 'joined_game' && (
          <>
            {!activeState ? (
              /* If user switched to an unjoined device slot, show clean Join Card */
              <div className="max-w-md mx-auto p-6 rounded-2xl bg-[#1A1D24] border border-white/10 space-y-4">
                <h2 className="text-lg font-bold text-white">{Strings.enterYourName}</h2>
                <form
                  onSubmit={(e) => handleJoinSubmit(e, slots.length === 1)}
                  className="space-y-4"
                >
                  <input
                    type="text"
                    required
                    value={joinNameInput}
                    onChange={(e) => setJoinNameInput(e.target.value)}
                    placeholder={Strings.namePlaceholder}
                    className="w-full px-4 py-3 rounded-xl bg-[#0F1115] border border-white/10 text-sm text-white"
                  />
                  <button
                    type="submit"
                    className="w-full h-12 rounded-xl bg-[#4FD1C5] text-[#0F1115] font-bold text-sm cursor-pointer"
                  >
                    {Strings.joinLobbyButton}
                  </button>
                </form>
              </div>
            ) : (
              <SharedPlayerScreens
                state={activeState}
                onMarkReady={actions.markReady}
                onOpenConfigureRoles={() => setShowConfigRolesModal(true)}
                onStartGame={actions.startGame}
                onSubmitNightAction={actions.submitNightAction}
                onSubmitVote={actions.submitVote}
                onAdvancePhase={actions.advancePhase}
                onRestartTimer={actions.restartTimer}
                onResetToLobby={actions.resetToLobby}
                onSendChat={actions.sendChat}
                onMarkAllSimulatedReady={actions.markAllSimulatedPlayersReady}
                hasMultipleSimulatedSlots={slots.length > 1}
              />
            )}
          </>
        )}
      </main>

      {/* =====================================================================
          MODALS (QR Info, Role Config, Flutter Architecture & Automated Tests)
         ===================================================================== */}
      {activeState && (
        <ConfigureRolesModal
          isOpen={showConfigRolesModal}
          onClose={() => setShowConfigRolesModal(false)}
          state={activeState}
          onSaveConfig={actions.configureRoles}
          onStartGame={actions.startGame}
        />
      )}

      <FlutterArchitectureModal
        isOpen={archModalState.open}
        initialTab={archModalState.tab}
        onClose={() => setArchModalState((prev) => ({ ...prev, open: false }))}
      />

      {showQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#1A1D24] border border-white/10 p-6 space-y-5 text-center">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <QrCode className="w-4 h-4 text-[#4FD1C5]" />
                <span>اتصال بازیکنان با کد QR</span>
              </div>
              <button
                type="button"
                onClick={() => setShowQrModal(false)}
                className="text-xs text-zinc-400 hover:text-white cursor-pointer"
              >
                بستن
              </button>
            </div>

            <p className="text-xs text-zinc-300 leading-relaxed">
              {Strings.connectSameWifiInstruction}
            </p>

            <div className="p-4 rounded-2xl bg-white inline-block mx-auto">
              <QRCodeSVG value={qrTargetUrl} size={180} level="M" />
            </div>

            <div className="space-y-1">
              <div className="text-xs text-zinc-400">آدرس شبکه محلی (LAN IPv4):</div>
              <div dir="ltr" className="font-mono text-sm font-bold text-[#4FD1C5]">
                {displayLanUrl}
              </div>
            </div>

            <div className="flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => handleCopyUrl(qrTargetUrl)}
                className="px-4 py-2 rounded-xl bg-[#232730] hover:bg-zinc-700 text-xs font-bold text-white cursor-pointer"
              >
                {copiedUrl ? 'لینک کپی شد!' : 'کپی لینک ورود بازیکنان'}
              </button>
              <button
                type="button"
                onClick={() => {
                  spawnTestPlayersUpToSix();
                  setShowQrModal(false);
                  setHostStep('joined_game');
                }}
                className="px-4 py-2 rounded-xl bg-[#4FD1C5] text-[#0F1115] text-xs font-bold cursor-pointer"
              >
                افزودن ۶ بازیکن آزمایشی
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
