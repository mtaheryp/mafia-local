import { RoleIds } from '../roles/role_ids';
import {
  GameStateView,
  NightAction,
  NightContext,
  NightEffect,
  NightEffectType,
  NightOutcome,
  RoleTeam,
} from '../roles/role_module';
import { RoleRegistry } from '../roles/role_registry';

/**
 * Resolves all submitted night actions in a strict deterministic order:
 * 1. PROTECT effects (Doctor protection)
 * 2. KILL effects (Mafia collective vote + optional Hunter shot)
 * 3. INVESTIGATE effects (Detective alignment lookup)
 */
export class ActionResolver {
  static resolveNight(
    view: GameStateView,
    submittedActions: Record<string, NightAction>
  ): NightOutcome {
    const ctx: NightContext = {
      view,
      allSubmittedActions: submittedActions,
    };

    const rawEffects: NightEffect[] = [];

    for (const [actorId, action] of Object.entries(submittedActions)) {
      const player = view.players.find((p) => p.id === actorId);
      if (!player || !player.isAlive) continue;

      const roleId = view.roleAssignments[actorId];
      if (!roleId) continue;

      const module = RoleRegistry.tryGet(roleId);
      if (!module || !module.hasNightAction) continue;

      if (!module.validateAction(view, actorId, action)) continue;

      const effect = module.resolve(ctx, actorId, action);
      if (effect) {
        rawEffects.push(effect);
      }
    }

    // 1. Collect all PROTECT targets
    const protectedPlayerIds = new Set<string>();
    for (const eff of rawEffects) {
      if (eff.type === NightEffectType.protect) {
        protectedPlayerIds.add(eff.targetPlayerId);
      }
    }

    // 2. Compute Mafia collective KILL target (majority vote; tie rule from RuleSet)
    const mafiaKillEffects = rawEffects.filter(
      (e) => e.type === NightEffectType.kill && e.roleId === RoleIds.mafia
    );

    let targetedByMafiaId: string | null = null;
    if (mafiaKillEffects.length > 0) {
      const tally: Record<string, number> = {};
      let lastTarget: string | null = null;

      for (const eff of mafiaKillEffects) {
        tally[eff.targetPlayerId] = (tally[eff.targetPlayerId] ?? 0) + 1;
        lastTarget = eff.targetPlayerId;
      }

      let maxVotes = 0;
      let topCandidates: string[] = [];

      for (const [candidateId, count] of Object.entries(tally)) {
        if (count > maxVotes) {
          maxVotes = count;
          topCandidates = [candidateId];
        } else if (count === maxVotes) {
          topCandidates.push(candidateId);
        }
      }

      if (topCandidates.length === 1) {
        targetedByMafiaId = topCandidates[0];
      } else if (topCandidates.length > 1) {
        targetedByMafiaId =
          view.rules.mafiaTieRule === 'last_selection' ? lastTarget : null;
      }
    }

    const killedSet = new Set<string>();
    const savedSet = new Set<string>();

    if (targetedByMafiaId) {
      if (protectedPlayerIds.has(targetedByMafiaId)) {
        savedSet.add(targetedByMafiaId);
      } else {
        killedSet.add(targetedByMafiaId);
      }
    }

    // Also process non-Mafia kill effects (e.g. Hunter one-shot kill)
    let hunterKilledId: string | null = null;
    const otherKillEffects = rawEffects.filter(
      (e) => e.type === NightEffectType.kill && e.roleId !== RoleIds.mafia
    );
    for (const eff of otherKillEffects) {
      hunterKilledId = eff.targetPlayerId;
      if (protectedPlayerIds.has(eff.targetPlayerId)) {
        savedSet.add(eff.targetPlayerId);
      } else {
        killedSet.add(eff.targetPlayerId);
      }
    }

    // 3. Process INVESTIGATE effects (Detective)
    const investigations: Record<
      string,
      { targetId: string; targetName: string; team: RoleTeam }
    > = {};

    for (const eff of rawEffects) {
      if (eff.type === NightEffectType.investigate) {
        const targetPlayer = view.players.find((p) => p.id === eff.targetPlayerId);
        const targetRoleId = view.roleAssignments[eff.targetPlayerId];
        const targetRole = targetRoleId ? RoleRegistry.tryGet(targetRoleId) : undefined;

        if (targetPlayer && targetRole) {
          investigations[eff.sourcePlayerId] = {
            targetId: targetPlayer.id,
            targetName: targetPlayer.name,
            team: targetRole.team,
          };
        }
      }
    }

    return {
      killedPlayerIds: Array.from(killedSet),
      savedPlayerIds: Array.from(savedSet),
      targetedByMafiaId,
      investigations,
      hunterKilledId,
    };
  }
}
