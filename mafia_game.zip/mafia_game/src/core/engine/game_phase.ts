/**
 * Strict sequential game phases controlled by the Host.
 */
export enum GamePhase {
  lobby = 'lobby',
  roleReveal = 'roleReveal',
  night = 'night',
  day = 'day',
  vote = 'vote',
  gameOver = 'gameOver',
}

export const PHASE_LABELS_FA: Record<GamePhase, string> = {
  [GamePhase.lobby]: 'لابی انتظار',
  [GamePhase.roleReveal]: 'مشاهده نقش مخفی',
  [GamePhase.night]: 'فاز شب',
  [GamePhase.day]: 'فاز روز و مذاکره',
  [GamePhase.vote]: 'فاز رای‌گیری',
  [GamePhase.gameOver]: 'پایان بازی',
};
