import { GameStateView, WinCondition, WinConditionResult } from '../roles/role_module';
import { RoleRegistry } from '../roles/role_registry';
import { MafiaWinCondition, TownWinCondition } from '../rules/win_conditions';

/**
 * Evaluates pluggable WinConditions in priority order.
 * Collects any custom WinCondition from registered RoleModules plus standard Town & Mafia conditions.
 */
export class WinChecker {
  static check(view: GameStateView): WinConditionResult {
    const conditions: WinCondition[] = [
      new TownWinCondition(),
      new MafiaWinCondition(),
    ];

    for (const role of RoleRegistry.getAll()) {
      if (role.customWinCondition) {
        conditions.push(role.customWinCondition);
      }
    }

    conditions.sort((a, b) => a.priority - b.priority);

    for (const cond of conditions) {
      const res = cond.evaluate(view);
      if (res && res.isGameOver) {
        return res;
      }
    }

    return {
      isGameOver: false,
      winningTeam: null,
      reason: '',
    };
  }
}
