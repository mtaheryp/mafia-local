import { GamePhase } from './game_phase';
import { RoleTeam } from '../roles/role_module';

export type DomainEvent =
  | { type: 'PlayerJoined'; playerId: string; name: string; isHost: boolean }
  | { type: 'PlayerReconnected'; playerId: string; name: string }
  | { type: 'PlayerDisconnected'; playerId: string }
  | { type: 'RolesConfigured'; counts: Record<string, number> }
  | { type: 'GameStarted'; seed: number; playerCount: number }
  | { type: 'PlayerMarkedReady'; playerId: string }
  | { type: 'PhaseChanged'; from: GamePhase; to: GamePhase; round: number }
  | { type: 'NightActionSubmitted'; actorId: string }
  | { type: 'NightResolved'; round: number; killedPlayerIds: string[] }
  | { type: 'VoteSubmitted'; voterId: string; targetId: string | null }
  | { type: 'VotingEnded'; round: number; eliminatedPlayerId: string | null; isTie: boolean }
  | { type: 'GameOver'; winningTeam: RoleTeam; reason: string };
