import { GamePhase } from './game_phase';
import {
  NightAction,
  NightActionSchema,
  RoleResultPayload,
  RoleTeam,
  PublicPlayerView,
} from '../roles/role_module';
import { RuleSet } from '../rules/rule_set';

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
}

export interface DayAnnouncement {
  round: number;
  killedPlayers: { id: string; name: string; revealedRoleName?: string; revealedTeam?: RoleTeam }[];
  message: string;
}

export interface VoteResolutionSummary {
  round: number;
  eliminatedPlayerId: string | null;
  eliminatedPlayerName: string | null;
  eliminatedPlayerRoleName?: string;
  eliminatedPlayerTeam?: RoleTeam;
  isTie: boolean;
  tallies: Record<string, number>; // targetId or 'SKIP' -> vote count
  message: string;
}

/**
 * Strictly filtered Per-Client State View constructed by StateBroadcaster.
 * NEVER contains another player's secret role (unless game is over or revealed on death).
 */
export interface ClientPersonalizedState {
  gameId: string;
  phase: GamePhase;
  round: number;
  selfPlayerId: string;
  selfSessionToken: string;
  isHost: boolean;
  players: PublicPlayerView[];
  roleCountsConfig: Record<string, number>;
  rules: RuleSet;
  availableRolesMeta: {
    id: string;
    displayName: string;
    shortDescription: string;
    team: RoleTeam;
    minCount: number;
  }[];
  /** Present ONLY for this player after game starts */
  mySecretRole: {
    roleId: string;
    displayName: string;
    shortDescription: string;
    team: RoleTeam;
    hasNightAction: boolean;
  } | null;
  /** Present ONLY during Night if this player has an active NightActionSchema */
  myNightPrompt: NightActionSchema | null;
  mySubmittedNightTargetId: string | null | undefined;
  /** Present ONLY to this player if their role produced a private night result (e.g. Detective history) */
  myPrivateReports: RoleResultPayload[];
  /** Present ONLY to Host during Night: list of playerIds who have submitted night actions (NEVER what they did or who has a role—Wait: to prevent Host from knowing who has a night role, we show total required vs submitted count + per-actor completion status without revealing role!) */
  hostNightStatus: {
    totalExpectedActions: number;
    submittedCount: number;
    allSubmitted: boolean;
    pendingCount: number;
    submittedPlayerNames: string[];
  } | null;
  lastDayAnnouncement: DayAnnouncement | null;
  discussionTimerRemainingSec: number | null;
  discussionTimerRunning: boolean;
  /** Public vote tallies (targetId or 'SKIP' -> count) */
  voteTallies: Record<string, number>;
  totalVotesCast: number;
  totalEligibleVoters: number;
  myCurrentVoteTargetId: string | null | undefined; // undefined = not voted yet, null = skip
  lastVoteSummary: VoteResolutionSummary | null;
  /** Populated ONLY when phase === GamePhase.gameOver or for dead spectators if rule enabled */
  revealedRoster: {
    playerId: string;
    name: string;
    isAlive: boolean;
    roleId: string;
    roleDisplayName: string;
    team: RoleTeam;
  }[] | null;
  gameOverInfo: {
    winningTeam: RoleTeam;
    reason: string;
  } | null;
  chatMessages: ChatMessage[];
}
