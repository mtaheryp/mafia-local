import { ActionResolver } from './action_resolver';
import { DomainEvent } from './events';
import { GamePhase } from './game_phase';
import { ChatMessage, DayAnnouncement, VoteResolutionSummary } from './game_state';
import { WinChecker } from './win_checker';
import { RoleIds } from '../roles/role_ids';
import {
  GameStateView,
  NightAction,
  PublicPlayerView,
  RoleResultPayload,
  RoleTeam,
} from '../roles/role_module';
import { RoleRegistry } from '../roles/role_registry';
import {
  buildSuggestedRoleCounts,
  DEFAULT_RULE_SET,
  RuleSet,
  validateRoleConfiguration,
} from '../rules/rule_set';
import { PlayerSession } from '../session/session';
import { Strings } from '../strings';

/**
 * Seeded PRNG (Mulberry32) for deterministic, reproducible uniform role shuffling.
 */
function createSeededRandom(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    let t = (a += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Pure Domain GameEngine.
 * Orchestrates sessions, role assignment, phases, night actions, voting, and win checking.
 * Zero UI or transport dependencies.
 */
export class GameEngine {
  readonly gameId: string;
  private _phase: GamePhase = GamePhase.lobby;
  private _round = 0;
  private _seed = 0;
  private _sessions: Map<string, PlayerSession> = new Map(); // playerId -> PlayerSession
  private _tokenToPlayerId: Map<string, string> = new Map(); // sessionToken -> playerId
  private _roleCountsConfig: Record<string, number> = buildSuggestedRoleCounts(6);
  private _rules: RuleSet = { ...DEFAULT_RULE_SET };
  private _roleAssignments: Record<string, string> = {}; // playerId -> roleId (SECRET!)
  private _doctorLastProtectedTarget: Record<string, string | null> = {};
  private _hunterUsedShot: Record<string, boolean> = {};
  private _nightActions: Record<string, NightAction> = {}; // actorId -> NightAction
  private _privateReportsByPlayer: Record<string, RoleResultPayload[]> = {};
  private _lastDayAnnouncement: DayAnnouncement | null = null;
  private _votes: Record<string, string | null> = {}; // voterId -> targetPlayerId | null (SKIP)
  private _lastVoteSummary: VoteResolutionSummary | null = null;
  private _gameOverInfo: { winningTeam: RoleTeam; reason: string } | null = null;
  private _chatMessages: ChatMessage[] = [];
  private _discussionTimerEndsAt: number | null = null;
  private _eventListeners: ((event: DomainEvent) => void)[] = [];

  constructor(gameId = 'mafia-lan-session') {
    this.gameId = gameId;
  }

  onEvent(listener: (event: DomainEvent) => void): void {
    this._eventListeners.push(listener);
  }

  private _emit(event: DomainEvent): void {
    for (const listener of this._eventListeners) {
      listener(event);
    }
  }

  get phase(): GamePhase {
    return this._phase;
  }

  get round(): number {
    return this._round;
  }

  get seed(): number {
    return this._seed;
  }

  get rules(): RuleSet {
    return this._rules;
  }

  get roleCountsConfig(): Record<string, number> {
    return { ...this._roleCountsConfig };
  }

  get sessions(): PlayerSession[] {
    return Array.from(this._sessions.values()).sort((a, b) => a.joinedAt - b.joinedAt);
  }

  getSessionByPlayerId(playerId: string): PlayerSession | undefined {
    return this._sessions.get(playerId);
  }

  getSessionByToken(token: string): PlayerSession | undefined {
    const pid = this._tokenToPlayerId.get(token);
    return pid ? this._sessions.get(pid) : undefined;
  }

  /**
   * Handles a player joining or reconnecting via sessionToken.
   * Duplicate names are automatically disambiguated by appending #2, #3, etc.
   */
  joinOrReconnect(params: {
    name: string;
    sessionToken?: string;
    preferHost?: boolean;
  }): { session: PlayerSession; reconnected: boolean; warning?: string } {
    const trimmedRawName = params.name.trim() || 'بازیکن';

    // 1. Check existing session token for reconnect
    if (params.sessionToken) {
      const existingPlayerId = this._tokenToPlayerId.get(params.sessionToken);
      if (existingPlayerId) {
        const existing = this._sessions.get(existingPlayerId);
        if (existing) {
          existing.isConnected = true;
          this._emit({
            type: 'PlayerReconnected',
            playerId: existing.playerId,
            name: existing.name,
          });
          return { session: existing, reconnected: true };
        }
      }
    }

    // If game already started and unknown token provided, reject or warn
    let warning: string | undefined;
    if (params.sessionToken) {
      warning = 'توکن نشست قبلی یافت نشد؛ به عنوان بازیکن جدید وارد شدید.';
    }

    if (this._phase !== GamePhase.lobby) {
      throw new Error('بازی در جریان است و امکان ورود بازیکن جدید در میانه بازی وجود ندارد.');
    }

    // Disambiguate duplicate names (#2, #3...)
    const existingNames = new Set(Array.from(this._sessions.values()).map((s) => s.name));
    let finalName = trimmedRawName;
    let counter = 2;
    while (existingNames.has(finalName)) {
      finalName = `${trimmedRawName} #${counter}`;
      counter++;
    }

    // First player to join or explicit preferHost when no host exists becomes Host
    const hasHostAlready = Array.from(this._sessions.values()).some((s) => s.isHost);
    const isHost = !hasHostAlready && (params.preferHost ?? this._sessions.size === 0);

    const playerId = `p_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
    const sessionToken = `tok_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;

    const session: PlayerSession = {
      playerId,
      sessionToken,
      name: finalName,
      isHost,
      isConnected: true,
      isAlive: true,
      isReady: false,
      joinedAt: Date.now(),
    };

    this._sessions.set(playerId, session);
    this._tokenToPlayerId.set(sessionToken, playerId);

    // Auto-update suggested role counts when player count changes in lobby
    this._rebalanceVillagerCount();

    this._emit({
      type: 'PlayerJoined',
      playerId: session.playerId,
      name: session.name,
      isHost: session.isHost,
    });

    return { session, reconnected: false, warning };
  }

  private _rebalanceVillagerCount(): void {
    const total = this._sessions.size;
    if (total >= 5) {
      const validation = validateRoleConfiguration(this._roleCountsConfig, total);
      if (!validation.isValid) {
        this._roleCountsConfig = buildSuggestedRoleCounts(total);
      } else {
        this._roleCountsConfig[RoleIds.villager] = validation.villagerCount;
      }
    } else {
      const suggested = buildSuggestedRoleCounts(Math.max(total, 5));
      this._roleCountsConfig = suggested;
    }
  }

  /**
   * Marks a client as disconnected.
   * If in Night or Vote and all remaining connected players have acted, auto-submits no-action/skip if Host advances or immediately records fallback.
   */
  markDisconnected(playerId: string): void {
    const session = this._sessions.get(playerId);
    if (!session) return;
    session.isConnected = false;
    this._emit({ type: 'PlayerDisconnected', playerId });
  }

  /**
   * Host updates Role counts and/or RuleSet in Lobby.
   */
  configureRolesAndRules(
    actorPlayerId: string,
    roleCounts?: Record<string, number>,
    partialRules?: Partial<RuleSet>
  ): void {
    this._assertHost(actorPlayerId);
    if (this._phase !== GamePhase.lobby) {
      throw new Error('تغییر نقش‌ها فقط در لابی امکان‌پذیر است.');
    }

    if (partialRules) {
      this._rules = { ...this._rules, ...partialRules };
    }

    if (roleCounts) {
      const nextCounts: Record<string, number> = {};
      let nonVillagerSum = 0;
      for (const role of RoleRegistry.getConfigurableNonVillagerRoles()) {
        const val = Math.max(0, Math.floor(roleCounts[role.id] ?? 0));
        nextCounts[role.id] = val;
        nonVillagerSum += val;
      }
      nextCounts[RoleIds.villager] = Math.max(0, this._sessions.size - nonVillagerSum);
      this._roleCountsConfig = nextCounts;
      this._emit({ type: 'RolesConfigured', counts: { ...this._roleCountsConfig } });
    }
  }

  /**
   * Host starts the game: validates role configuration, shuffles roles uniformly with random seed,
   * and transitions to `GamePhase.roleReveal`.
   */
  startGame(actorPlayerId: string, customSeed?: number): void {
    this._assertHost(actorPlayerId);
    if (this._phase !== GamePhase.lobby) {
      throw new Error('بازی قبلاً شروع شده است.');
    }

    const totalPlayers = this._sessions.size;
    const validation = validateRoleConfiguration(
      this._roleCountsConfig,
      totalPlayers,
      this._rules.minPlayersToStart
    );

    if (!validation.isValid) {
      throw new Error(validation.errorMessage ?? 'تنظیمات نقش‌ها معتبر نیست.');
    }

    // Build exact role pool matching totalPlayers
    const rolePool: string[] = [];
    for (const role of RoleRegistry.getConfigurableNonVillagerRoles()) {
      const count = Math.max(0, Math.floor(this._roleCountsConfig[role.id] ?? 0));
      for (let i = 0; i < count; i++) {
        rolePool.push(role.id);
      }
    }
    while (rolePool.length < totalPlayers) {
      rolePool.push(RoleIds.villager);
    }

    // Seeded Fisher-Yates uniform shuffle
    this._seed = customSeed ?? Math.floor(Math.random() * 0x7fffffff);
    const rng = createSeededRandom(this._seed);
    for (let i = rolePool.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      const tmp = rolePool[i];
      rolePool[i] = rolePool[j];
      rolePool[j] = tmp;
    }

    this._roleAssignments = {};
    this._doctorLastProtectedTarget = {};
    this._hunterUsedShot = {};
    this._nightActions = {};
    this._privateReportsByPlayer = {};
    this._votes = {};
    this._lastDayAnnouncement = null;
    this._lastVoteSummary = null;
    this._gameOverInfo = null;
    this._round = 1;

    const orderedSessions = this.sessions;
    orderedSessions.forEach((session, idx) => {
      session.isAlive = true;
      session.isReady = false;
      this._roleAssignments[session.playerId] = rolePool[idx];
      this._privateReportsByPlayer[session.playerId] = [];
    });

    const prevPhase = this._phase;
    this._phase = GamePhase.roleReveal;

    this._emit({ type: 'GameStarted', seed: this._seed, playerCount: totalPlayers });
    this._emit({ type: 'PhaseChanged', from: prevPhase, to: this._phase, round: this._round });
  }

  /**
   * Player marks themselves as Ready on the Role Reveal screen.
   */
  markPlayerReady(playerId: string): void {
    const session = this._sessions.get(playerId);
    if (!session) throw new Error('بازیکن یافت نشد.');
    session.isReady = true;
    this._emit({ type: 'PlayerMarkedReady', playerId });
  }

  /**
   * Submits a player's Night Action.
   */
  submitNightAction(actorId: string, targetPlayerId: string | null): void {
    if (this._phase !== GamePhase.night) {
      throw new Error('ثبت عملیات شب فقط در فاز شب امکان‌پذیر است.');
    }

    const session = this._sessions.get(actorId);
    if (!session || !session.isAlive) {
      throw new Error('فقط بازیکنان زنده می‌توانند در شب عملیات انجام دهند.');
    }

    const roleId = this._roleAssignments[actorId];
    const module = RoleRegistry.tryGet(roleId);
    if (!module || !module.hasNightAction) {
      throw new Error('نقش شما عملیات شبانه ندارد.');
    }

    const view = this.buildInternalGameStateView();
    const action: NightAction = {
      actorId,
      roleId,
      targetPlayerId,
    };

    if (!module.validateAction(view, actorId, action)) {
      throw new Error('انتخاب شب شما طبق قوانین بازی معتبر نیست.');
    }

    this._nightActions[actorId] = action;
    this._emit({ type: 'NightActionSubmitted', actorId });
  }

  /**
   * Submits or updates a living player's vote during `GamePhase.vote`.
   * `targetPlayerId === null` represents a "Skip" (رای سفید) vote.
   */
  submitVote(voterId: string, targetPlayerId: string | null): void {
    if (this._phase !== GamePhase.vote) {
      throw new Error('در حال حاضر در مرحله رای‌گیری نیستیم.');
    }

    const voter = this._sessions.get(voterId);
    if (!voter || !voter.isAlive) {
      throw new Error('فقط بازیکنان زنده اجازه رای دادن دارند.');
    }

    if (targetPlayerId !== null) {
      const target = this._sessions.get(targetPlayerId);
      if (!target || !target.isAlive) {
        throw new Error('فقط می‌توانید به بازیکنان زنده رای دهید.');
      }
    }

    this._votes[voterId] = targetPlayerId;
    this._emit({ type: 'VoteSubmitted', voterId, targetId: targetPlayerId });
  }

  /**
   * Host advances from Role Reveal -> Night 1, or Day -> Vote, or Night -> Day, or Vote -> Night/GameOver.
   */
  hostAdvancePhase(hostPlayerId: string, force = false): void {
    this._assertHost(hostPlayerId);

    if (this._phase === GamePhase.roleReveal) {
      const unreadyConnected = this.sessions.filter((s) => s.isConnected && !s.isReady);
      if (unreadyConnected.length > 0 && !force) {
        throw new Error('هنوز همه بازیکنان دکمه «نقشم را دیدم، آماده‌ام» را نزده‌اند.');
      }
      this._enterNightPhase(1);
      return;
    }

    if (this._phase === GamePhase.night) {
      const status = this.getNightSubmissionStatus();
      if (!status.allSubmitted && !force) {
        throw new Error(Strings.hostForceEndNightWarning);
      }
      this._resolveNightAndTransitionToDay();
      return;
    }

    if (this._phase === GamePhase.day) {
      this._enterVotePhase();
      return;
    }

    if (this._phase === GamePhase.vote) {
      this._resolveVoteAndTransition();
      return;
    }
  }

  private _enterNightPhase(roundNumber: number): void {
    const prev = this._phase;
    this._round = roundNumber;
    this._phase = GamePhase.night;
    this._nightActions = {};
    this._discussionTimerEndsAt = null;

    // Auto-submit null action for any disconnected player who has a night action
    for (const s of this.sessions) {
      if (s.isAlive && !s.isConnected && this._doesPlayerNeedNightAction(s.playerId)) {
        const roleId = this._roleAssignments[s.playerId];
        this._nightActions[s.playerId] = {
          actorId: s.playerId,
          roleId,
          targetPlayerId: null,
        };
      }
    }

    this._emit({ type: 'PhaseChanged', from: prev, to: this._phase, round: this._round });
  }

  private _resolveNightAndTransitionToDay(): void {
    // Auto-fill null action for any player who still hasn't submitted (disconnected or forced by Host)
    for (const s of this.sessions) {
      if (
        s.isAlive &&
        this._doesPlayerNeedNightAction(s.playerId) &&
        this._nightActions[s.playerId] === undefined
      ) {
        this._nightActions[s.playerId] = {
          actorId: s.playerId,
          roleId: this._roleAssignments[s.playerId],
          targetPlayerId: null,
        };
      }
    }

    const viewBefore = this.buildInternalGameStateView();
    const outcome = ActionResolver.resolveNight(viewBefore, this._nightActions);

    // Update Doctor consecutive protection memory and Hunter one-shot usage
    for (const [actorId, action] of Object.entries(this._nightActions)) {
      if (action.roleId === RoleIds.doctor) {
        this._doctorLastProtectedTarget[actorId] = action.targetPlayerId;
      }
      if (action.roleId === RoleIds.hunter && action.targetPlayerId !== null) {
        this._hunterUsedShot[actorId] = true;
      }
    }

    // Deliver private night outcomes to actors (e.g., Detective alignment report)
    for (const s of this.sessions) {
      if (!s.isAlive) continue;
      const roleId = this._roleAssignments[s.playerId];
      const module = RoleRegistry.tryGet(roleId);
      if (module) {
        const privatePayload = module.resultForActor(viewBefore, s.playerId, outcome);
        if (privatePayload) {
          this._privateReportsByPlayer[s.playerId] = [
            ...(this._privateReportsByPlayer[s.playerId] ?? []),
            privatePayload,
          ];
        }
      }
    }

    // Apply deaths from night
    const killedPlayersInfo: DayAnnouncement['killedPlayers'] = [];
    for (const victimId of outcome.killedPlayerIds) {
      const session = this._sessions.get(victimId);
      if (session && session.isAlive) {
        session.isAlive = false;
        const rId = this._roleAssignments[victimId];
        const rMod = RoleRegistry.tryGet(rId);
        killedPlayersInfo.push({
          id: session.playerId,
          name: session.name,
          revealedRoleName: this._rules.revealRoleOnDeath ? rMod?.displayName : undefined,
          revealedTeam: this._rules.revealRoleOnDeath ? rMod?.team : undefined,
        });

        // Also send a private notification to the victim
        this._privateReportsByPlayer[victimId] = [
          ...(this._privateReportsByPlayer[victimId] ?? []),
          {
            roleId: rId,
            title: 'شما در شب گذشته کشته شدید',
            message: 'متاسفانه در جریان عملیات شب گذشته جان خود را از دست دادید و اکنون تماشاگر بازی هستید.',
          },
        ];
      }
    }

    this._lastDayAnnouncement = {
      round: this._round,
      killedPlayers: killedPlayersInfo,
      message:
        killedPlayersInfo.length === 0
          ? Strings.noOneDiedAnnouncement
          : Strings.playersDiedAnnouncement(killedPlayersInfo.map((k) => k.name)),
    };

    this._emit({
      type: 'NightResolved',
      round: this._round,
      killedPlayerIds: outcome.killedPlayerIds,
    });

    // Check win condition immediately after night deaths
    const winRes = WinChecker.check(this.buildInternalGameStateView());
    if (winRes.isGameOver && winRes.winningTeam) {
      this._transitionToGameOver(winRes.winningTeam, winRes.reason);
      return;
    }

    const prev = this._phase;
    this._phase = GamePhase.day;
    this._discussionTimerEndsAt =
      this._rules.discussionTimerSeconds > 0
        ? Date.now() + this._rules.discussionTimerSeconds * 1000
        : null;

    this._emit({ type: 'PhaseChanged', from: prev, to: this._phase, round: this._round });
  }

  private _enterVotePhase(): void {
    const prev = this._phase;
    this._phase = GamePhase.vote;
    this._votes = {};
    this._lastVoteSummary = null;
    this._discussionTimerEndsAt = null;

    // Auto-skip for disconnected alive players
    for (const s of this.sessions) {
      if (s.isAlive && !s.isConnected) {
        this._votes[s.playerId] = null;
      }
    }

    this._emit({ type: 'PhaseChanged', from: prev, to: this._phase, round: this._round });
  }

  private _resolveVoteAndTransition(): void {
    const alivePlayers = this.sessions.filter((s) => s.isAlive);
    const tallies: Record<string, number> = {};

    for (const voter of alivePlayers) {
      const choice = this._votes[voter.playerId];
      if (choice === undefined) continue; // Did not vote
      const key = choice === null ? 'SKIP' : choice;
      tallies[key] = (tallies[key] ?? 0) + 1;
    }

    let maxVotes = 0;
    let topKeys: string[] = [];

    for (const [key, count] of Object.entries(tallies)) {
      if (count > maxVotes) {
        maxVotes = count;
        topKeys = [key];
      } else if (count === maxVotes) {
        topKeys.push(key);
      }
    }

    let eliminatedPlayerId: string | null = null;
    let eliminatedPlayerName: string | null = null;
    let eliminatedRoleName: string | undefined;
    let eliminatedTeam: RoleTeam | undefined;
    let isTie = false;

    if (topKeys.length === 1 && topKeys[0] !== 'SKIP' && maxVotes > 0) {
      eliminatedPlayerId = topKeys[0];
      const session = this._sessions.get(eliminatedPlayerId);
      if (session) {
        session.isAlive = false;
        eliminatedPlayerName = session.name;
        const rId = this._roleAssignments[session.playerId];
        const rMod = RoleRegistry.tryGet(rId);
        if (this._rules.revealRoleOnDeath && rMod) {
          eliminatedRoleName = rMod.displayName;
          eliminatedTeam = rMod.team;
        }
      }
    } else {
      isTie = true;
    }

    this._lastVoteSummary = {
      round: this._round,
      eliminatedPlayerId,
      eliminatedPlayerName,
      eliminatedPlayerRoleName: eliminatedRoleName,
      eliminatedPlayerTeam: eliminatedTeam,
      isTie,
      tallies,
      message:
        eliminatedPlayerName !== null
          ? Strings.voteEliminatedAnnouncement(eliminatedPlayerName, eliminatedRoleName)
          : Strings.voteTieNoElimination,
    };

    this._emit({
      type: 'VotingEnded',
      round: this._round,
      eliminatedPlayerId,
      isTie,
    });

    // Check win conditions after vote elimination
    const winRes = WinChecker.check(this.buildInternalGameStateView());
    if (winRes.isGameOver && winRes.winningTeam) {
      this._transitionToGameOver(winRes.winningTeam, winRes.reason);
      return;
    }

    // Otherwise loop back to next Night
    this._enterNightPhase(this._round + 1);
  }

  private _transitionToGameOver(winningTeam: RoleTeam, reason: string): void {
    const prev = this._phase;
    this._phase = GamePhase.gameOver;
    this._gameOverInfo = { winningTeam, reason };
    this._discussionTimerEndsAt = null;
    this._emit({ type: 'GameOver', winningTeam, reason });
    this._emit({ type: 'PhaseChanged', from: prev, to: this._phase, round: this._round });
  }

  /**
   * Host resets the finished game back to the Lobby while keeping all connected players in the room.
   */
  resetToLobby(hostPlayerId: string): void {
    this._assertHost(hostPlayerId);
    const prev = this._phase;
    this._phase = GamePhase.lobby;
    this._round = 0;
    this._roleAssignments = {};
    this._doctorLastProtectedTarget = {};
    this._hunterUsedShot = {};
    this._nightActions = {};
    this._privateReportsByPlayer = {};
    this._votes = {};
    this._lastDayAnnouncement = null;
    this._lastVoteSummary = null;
    this._gameOverInfo = null;
    this._discussionTimerEndsAt = null;

    for (const s of this._sessions.values()) {
      s.isAlive = true;
      s.isReady = false;
    }

    this._rebalanceVillagerCount();
    this._emit({ type: 'PhaseChanged', from: prev, to: this._phase, round: 0 });
  }

  /**
   * Starts or resets the Day discussion countdown timer (Host only).
   */
  restartDiscussionTimer(hostPlayerId: string, durationSec?: number): void {
    this._assertHost(hostPlayerId);
    const sec = durationSec ?? this._rules.discussionTimerSeconds;
    this._discussionTimerEndsAt = Date.now() + sec * 1000;
  }

  /**
   * Appends a public chat message if chat is enabled for the current phase.
   */
  addChatMessage(senderId: string, text: string): ChatMessage {
    const session = this._sessions.get(senderId);
    if (!session) throw new Error('بازیکن یافت نشد.');

    const trimmed = text.trim();
    if (!trimmed) throw new Error('متن پیام نمی‌تواند خالی باشد.');

    if (this._phase === GamePhase.lobby && !this._rules.enableLobbyChat) {
      throw new Error('چت لابی غیرفعال است.');
    }
    if (this._phase === GamePhase.day && !this._rules.enableDayChat) {
      throw new Error('چت روز توسط میزبان غیرفعال شده است.');
    }
    if (this._phase !== GamePhase.lobby && this._phase !== GamePhase.day) {
      throw new Error('ارسال پیام عمومی فقط در لابی یا فاز روز مجاز است.');
    }
    if (this._phase === GamePhase.day && !session.isAlive) {
      throw new Error('بازیکنان حذف‌شده (تماشاگران) در طول بازی اجازه ارسال پیام ندارند.');
    }

    const msg: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      senderId: session.playerId,
      senderName: session.name,
      text: trimmed.slice(0, 280),
      timestamp: Date.now(),
    };

    this._chatMessages = [...this._chatMessages.slice(-49), msg];
    return msg;
  }

  private _doesPlayerNeedNightAction(playerId: string): boolean {
    const s = this._sessions.get(playerId);
    if (!s || !s.isAlive) return false;
    const roleId = this._roleAssignments[playerId];
    if (!roleId) return false;
    const module = RoleRegistry.tryGet(roleId);
    if (!module || !module.hasNightAction) return false;
    if (roleId === RoleIds.hunter && this._hunterUsedShot[playerId]) return false;
    return true;
  }

  getNightSubmissionStatus(): {
    totalExpectedActions: number;
    submittedCount: number;
    allSubmitted: boolean;
    pendingCount: number;
    submittedPlayerNames: string[];
  } {
    let totalExpectedActions = 0;
    let submittedCount = 0;
    const submittedPlayerNames: string[] = [];

    for (const s of this.sessions) {
      if (this._doesPlayerNeedNightAction(s.playerId)) {
        totalExpectedActions++;
        if (this._nightActions[s.playerId] !== undefined) {
          submittedCount++;
          submittedPlayerNames.push(s.name);
        }
      }
    }

    return {
      totalExpectedActions,
      submittedCount,
      allSubmitted: submittedCount >= totalExpectedActions,
      pendingCount: Math.max(0, totalExpectedActions - submittedCount),
      submittedPlayerNames,
    };
  }

  /**
   * Builds the internal GameStateView used by RoleModules and WinChecker.
   * WARNING: Contains `roleAssignments`. Must NEVER be serialized directly to clients!
   */
  buildInternalGameStateView(): GameStateView {
    const players: PublicPlayerView[] = this.sessions.map((s) => {
      const rId = this._roleAssignments[s.playerId];
      const rMod = rId ? RoleRegistry.tryGet(rId) : undefined;
      const shouldRevealPublicly =
        this._phase === GamePhase.gameOver || (!s.isAlive && this._rules.revealRoleOnDeath);

      return {
        id: s.playerId,
        name: s.name,
        isAlive: s.isAlive,
        isConnected: s.isConnected,
        isHost: s.isHost,
        isReady: s.isReady,
        revealedRoleId: shouldRevealPublicly ? rId : undefined,
        revealedRoleName: shouldRevealPublicly ? rMod?.displayName : undefined,
        revealedTeam: shouldRevealPublicly ? rMod?.team : undefined,
      };
    });

    return {
      round: this._round,
      phase: this._phase,
      players,
      roleAssignments: { ...this._roleAssignments },
      doctorLastProtectedTarget: { ...this._doctorLastProtectedTarget },
      hunterUsedShot: { ...this._hunterUsedShot },
      nightActions: { ...this._nightActions },
      rules: { ...this._rules },
    };
  }

  // Expose controlled getters for StateBroadcaster ONLY
  getRoleAssignmentForPlayer(playerId: string): string | undefined {
    return this._roleAssignments[playerId];
  }

  getNightActionForPlayer(playerId: string): NightAction | undefined {
    return this._nightActions[playerId];
  }

  getPrivateReportsForPlayer(playerId: string): RoleResultPayload[] {
    return [...(this._privateReportsByPlayer[playerId] ?? [])];
  }

  getLastDayAnnouncement(): DayAnnouncement | null {
    return this._lastDayAnnouncement;
  }

  getDiscussionTimerRemainingSec(): number | null {
    if (!this._discussionTimerEndsAt) return null;
    const diff = Math.ceil((this._discussionTimerEndsAt - Date.now()) / 1000);
    return Math.max(0, diff);
  }

  getVotesSnapshot(): {
    tallies: Record<string, number>;
    totalVotesCast: number;
    totalEligibleVoters: number;
    rawVotes: Record<string, string | null>;
  } {
    const alivePlayers = this.sessions.filter((s) => s.isAlive);
    const tallies: Record<string, number> = {};
    let totalVotesCast = 0;

    for (const p of alivePlayers) {
      const choice = this._votes[p.playerId];
      if (choice !== undefined) {
        totalVotesCast++;
        const key = choice === null ? 'SKIP' : choice;
        tallies[key] = (tallies[key] ?? 0) + 1;
      }
    }

    return {
      tallies,
      totalVotesCast,
      totalEligibleVoters: alivePlayers.length,
      rawVotes: { ...this._votes },
    };
  }

  getLastVoteSummary(): VoteResolutionSummary | null {
    return this._lastVoteSummary;
  }

  getGameOverInfo(): { winningTeam: RoleTeam; reason: string } | null {
    return this._gameOverInfo;
  }

  getChatMessages(): ChatMessage[] {
    return [...this._chatMessages];
  }

  private _assertHost(playerId: string): void {
    const session = this._sessions.get(playerId);
    if (!session || !session.isHost) {
      throw new Error('فقط میزبان بازی اجازه انجام این کار را دارد.');
    }
  }
}
