/**
 * Represents a player's persistent session across reconnects.
 * Each browser tab/device receives a unique `sessionToken` stored in localStorage.
 */
export interface PlayerSession {
  playerId: string;
  sessionToken: string;
  name: string;
  isHost: boolean;
  isConnected: boolean;
  isAlive: boolean;
  isReady: boolean;
  joinedAt: number;
}
