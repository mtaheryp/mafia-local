import { GameStateView, RoleTeam, WinCondition, WinConditionResult } from '../roles/role_module';
import { RoleRegistry } from '../roles/role_registry';

/**
 * Town Win Condition:
 * Town wins when all living Mafia players are eliminated (aliveMafia === 0).
 */
export class TownWinCondition implements WinCondition {
  readonly id = 'town_eliminates_all_mafia';
  readonly priority = 10;

  evaluate(view: GameStateView): WinConditionResult | null {
    const alivePlayers = view.players.filter((p) => p.isAlive);
    if (alivePlayers.length === 0) {
      return {
        isGameOver: true,
        winningTeam: RoleTeam.town,
        reason: 'تمام بازیکنان از بازی خارج شدند.',
      };
    }

    let aliveMafia = 0;
    for (const p of alivePlayers) {
      const roleId = view.roleAssignments[p.id];
      const role = RoleRegistry.tryGet(roleId);
      if (role?.team === RoleTeam.mafia) {
        aliveMafia++;
      }
    }

    if (aliveMafia === 0) {
      return {
        isGameOver: true,
        winningTeam: RoleTeam.town,
        reason: 'تمام اعضای مافیا شناسایی و از شهر خارج شدند. شهروندان پیروز شدند!',
      };
    }

    return null;
  }
}

/**
 * Mafia Win Condition:
 * Mafia wins when living Mafia count >= living non-Mafia count.
 */
export class MafiaWinCondition implements WinCondition {
  readonly id = 'mafia_parity_or_majority';
  readonly priority = 20;

  evaluate(view: GameStateView): WinConditionResult | null {
    const alivePlayers = view.players.filter((p) => p.isAlive);
    if (alivePlayers.length === 0) return null;

    let aliveMafia = 0;
    let aliveNonMafia = 0;

    for (const p of alivePlayers) {
      const roleId = view.roleAssignments[p.id];
      const role = RoleRegistry.tryGet(roleId);
      if (role?.team === RoleTeam.mafia) {
        aliveMafia++;
      } else {
        aliveNonMafia++;
      }
    }

    if (aliveMafia > 0 && aliveMafia >= aliveNonMafia) {
      return {
        isGameOver: true,
        winningTeam: RoleTeam.mafia,
        reason: `تعداد مافیای زنده (${aliveMafia}) با شهروندان زنده (${aliveNonMafia}) برابر یا بیشتر شد. مافیا کنترل شهر را به دست گرفت!`,
      };
    }

    return null;
  }
}
