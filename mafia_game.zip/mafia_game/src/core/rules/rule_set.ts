import { RoleIds } from '../roles/role_ids';
import { RoleRegistry } from '../roles/role_registry';

/**
 * Configurable RuleSet for a game session.
 * All ties and edge cases are documented and controlled here.
 */
export interface RuleSet {
  /** Reveal eliminated player's role publicly after Day Vote (default: true) */
  revealRoleOnDeath: boolean;
  /** Whether Doctor can protect themselves at night (default: true) */
  doctorCanSelfProtect: boolean;
  /** Standard Rule: Doctor cannot protect the same player two nights in a row (default: true) */
  doctorCannotProtectSameTargetTwiceInARow: boolean;
  /** Whether dead players (spectators) can see everyone's roles (default: false for fairness) */
  revealRolesToDeadSpectators: boolean;
  /** Public text chat enabled in Lobby (default: true) */
  enableLobbyChat: boolean;
  /** Public text chat enabled during Day phase (default: false) */
  enableDayChat: boolean;
  /** Day discussion countdown timer in seconds (default: 120) */
  discussionTimerSeconds: number;
  /**
   * Tie rule for multiple Mafia members voting at night:
   * - 'no_kill': Majority required; if tied between two targets, no kill occurs (recommended default).
   * - 'last_selection': Last submitted non-null selection wins.
   */
  mafiaTieRule: 'no_kill' | 'last_selection';
  /** Minimum total players required to start a game (default: 5, recommended 6–15) */
  minPlayersToStart: number;
}

export const DEFAULT_RULE_SET: RuleSet = {
  revealRoleOnDeath: true,
  doctorCanSelfProtect: true,
  doctorCannotProtectSameTargetTwiceInARow: true,
  revealRolesToDeadSpectators: false,
  enableLobbyChat: true,
  enableDayChat: false,
  discussionTimerSeconds: 120,
  mafiaTieRule: 'no_kill',
  minPlayersToStart: 5,
};

/**
 * Generates suggested role counts based on the total number of joined players.
 * e.g. 6 players -> 1 mafia, 1 doctor, 1 detective, 3 villagers.
 */
export function buildSuggestedRoleCounts(totalPlayers: number): Record<string, number> {
  const safeTotal = Math.max(totalPlayers, 0);
  const mafiaCount = safeTotal >= 12 ? 3 : safeTotal >= 8 ? 2 : 1;
  const doctorCount = safeTotal >= 5 ? 1 : 0;
  const detectiveCount = safeTotal >= 5 ? 1 : 0;

  const counts: Record<string, number> = {};
  for (const role of RoleRegistry.getConfigurableNonVillagerRoles()) {
    if (role.id === RoleIds.mafia) {
      counts[role.id] = mafiaCount;
    } else if (role.id === RoleIds.doctor) {
      counts[role.id] = doctorCount;
    } else if (role.id === RoleIds.detective) {
      counts[role.id] = detectiveCount;
    } else {
      counts[role.id] = 0; // Optional roles like hunter default to 0
    }
  }

  const nonVillagerSum = Object.values(counts).reduce((a, b) => a + b, 0);
  counts[RoleIds.villager] = Math.max(0, safeTotal - nonVillagerSum);
  return counts;
}

export interface RoleConfigValidation {
  isValid: boolean;
  villagerCount: number;
  nonVillagerSum: number;
  errorMessage: string | null;
}

/**
 * Validates the Host's role configuration against total joined players.
 */
export function validateRoleConfiguration(
  counts: Record<string, number>,
  totalPlayers: number,
  minPlayers = DEFAULT_RULE_SET.minPlayersToStart
): RoleConfigValidation {
  let nonVillagerSum = 0;
  for (const role of RoleRegistry.getConfigurableNonVillagerRoles()) {
    const c = Math.max(0, Math.floor(counts[role.id] ?? 0));
    nonVillagerSum += c;
  }

  const mafiaCount = Math.max(0, Math.floor(counts[RoleIds.mafia] ?? 0));
  const villagerCount = Math.max(0, totalPlayers - nonVillagerSum);

  if (totalPlayers < minPlayers) {
    return {
      isValid: false,
      villagerCount,
      nonVillagerSum,
      errorMessage: `حداقل ${minPlayers} بازیکن در لابی برای شروع بازی لازم است (فعلی: ${totalPlayers}).`,
    };
  }

  if (mafiaCount < 1) {
    return {
      isValid: false,
      villagerCount,
      nonVillagerSum,
      errorMessage: 'حداقل ۱ مافیا باید در بازی حضور داشته باشد.',
    };
  }

  if (nonVillagerSum > totalPlayers) {
    return {
      isValid: false,
      villagerCount: 0,
      nonVillagerSum,
      errorMessage: 'مجموع نقش‌های انتخابی بیشتر از تعداد کل بازیکنان است.',
    };
  }

  const nonMafiaCount = totalPlayers - mafiaCount;
  if (mafiaCount >= nonMafiaCount) {
    return {
      isValid: false,
      villagerCount,
      nonVillagerSum,
      errorMessage: 'تعداد مافیا نباید مساوی یا بیشتر از کل شهروندان باشد (بازی در لحظه شروع تمام می‌شود).',
    };
  }

  return {
    isValid: true,
    villagerCount,
    nonVillagerSum,
    errorMessage: null,
  };
}
