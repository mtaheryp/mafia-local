/**
 * Centralized UI & Engine Strings (Persian Default, structured for i18n)
 * تمام رشته‌های متنی بازی به زبان فارسی در این فایل متمرکز شده‌اند.
 */
export const Strings = {
  appName: 'مافیا لوکال',
  appSubtitle: 'بازی مافیا چندنفره آفلاین روی شبکه محلی (Wi-Fi LAN)',
  hostBadge: 'میزبان',
  youBadge: 'شما',
  deadBadge: 'حذف‌شده (تماشاگر)',
  disconnectedBadge: 'قطع ارتباط',
  readyBadge: 'آماده',
  waitingBadge: 'در انتظار',

  // Home & Connection
  createGame: 'ساخت بازی جدید (میزبان)',
  joinAsHostPlayer: 'من هم بازی می‌کنم',
  enterYourName: 'نام خود را وارد کنید',
  namePlaceholder: 'مثلاً: امیر، سارا، سهراب...',
  joinLobbyButton: 'ورود به لابی بازی',
  connectSameWifiInstruction: 'همه بازیکنان را به یک وای‌فای (Wi-Fi) یا هات‌اسپات مشترک متصل کنید.',
  scanQrInstruction: 'بازیکنان با دوربین گوشی کد QR را اسکن کنند یا آدرس زیر را در مرورگر موبایل باز کنند (نیاز به نصب برنامه نیست):',
  foregroundServiceActive: 'سرویس پس‌زمینه و قفل بیداری صفحه (WakeLock) فعال است',
  wifiOffErrorTitle: 'عدم اتصال به شبکه وای‌فای محلی (LAN)',
  wifiOffErrorDesc: 'آدرس IP شبکه محلی یافت نشد. لطفاً Wi-Fi یا هات‌اسپات گوشی را روشن کرده و دوباره تلاش کنید.',
  retryNetworkCheck: 'بررسی مجدد شبکه',
  portFallbackNotice: 'پورت پیش‌فرض ۸۰۸۰ مشغول بود؛ سرور به صورت خودکار روی پورت جایگزین راه‌اندازی شد.',

  // Lobby
  lobbyTitle: 'لابی انتظار بازیکنان',
  playersJoinedCount: (count: number) => `${count} بازیکن در لابی`,
  minPlayersNotice: (min: number) => `حداقل ${min} بازیکن برای شروع بازی لازم است.`,
  waitingForHostToStart: 'در انتظار تنظیم نقش‌ها و شروع بازی توسط میزبان...',
  configureRolesBtn: 'تنظیم نقش‌ها و قوانین',
  startGameBtn: 'شروع بازی و توزیع نقش‌ها',
  publicChatTitle: 'گفتگوی عمومی',
  chatPlaceholder: 'پیام خود را بنویسید...',
  sendBtn: 'ارسال',

  // Role Configuration
  roleConfigTitle: 'تنظیم نقش‌ها و قوانین بازی',
  totalPlayersLabel: 'مجموع بازیکنان حاضر:',
  villagerAutoComputedNote: 'تعداد شهروند ساده به صورت خودکار از باقی‌مانده بازیکنان محاسبه می‌شود.',
  validationMinPlayers: 'حداقل ۵ بازیکن برای شروع بازی نیاز است.',
  validationMinMafia: 'حداقل ۱ مافیا باید در بازی حضور داشته باشد.',
  validationRolesExceedTotal: 'مجموع نقش‌های انتخاب‌شده بیشتر از تعداد کل بازیکنان است.',
  validationMafiaOutnumbersTown: 'تعداد مافیا نباید مساوی یا بیشتر از شهروندان باشد.',
  applyPresetBtn: 'چیدمان پیشنهادی استاندارد',
  rulesSectionTitle: 'قوانین قابل تنظیم میزبان',
  ruleRevealRoleOnDeath: 'افشای نقش بازیکن پس از حذف در رای‌گیری روز',
  ruleDoctorSelfProtect: 'اجازه محافظت دکتر از خودش',
  ruleDeadSpectatorSeeRoles: 'نمایش نقش تمام بازیکنان به تماشاگران (بازیکنان حذف‌شده)',
  ruleEnableDayChat: 'فعال‌سازی چت متنی در طول فاز روز',
  ruleDiscussionTimerSeconds: 'زمان تایمر مذاکره روز (ثانیه)',

  // Role Reveal
  roleRevealTitle: 'کارت نقش مخفی شما',
  tapToFlipPrompt: 'برای مشاهده نقش مخفی خود، روی کارت ضربه بزنید',
  keepSecretWarning: 'مراقب باشید کسی صفحه گوشی شما را نبیند!',
  iSawMyRoleReadyBtn: 'نقشم را دیدم، آماده‌ام',
  waitingForOthersReady: 'در انتظار اعلام آمادگی سایر بازیکنان...',
  hostContinueToNightBtn: 'شروع شب اول',

  // Teams
  teamTown: 'گروه شهروندان (Town)',
  teamMafia: 'گروه مافیا (Mafia)',
  teamNeutral: 'مستقل (Neutral)',

  // Night Phase
  nightPhaseTitle: (round: number) => `شب ${round} — شهر به خواب می‌رود`,
  townSleepsTitle: 'شهر در تاریکی فرو رفته است...',
  townSleepsSubtitle: 'شما در طول شب عملیاتی ندارید. آرام بمانید تا شب به پایان برسد.',
  submitNightActionBtn: 'ثبت قطعی انتخاب شب',
  actionSubmittedNotice: 'انتخاب شب شما ثبت شد. منتظر پایان شب توسط میزبان بمانید.',
  mafiaTeammatesLabel: 'هم‌تیمی‌های مافیا:',
  mafiaVoteStatusLabel: 'آرای ثبت‌شده مافیا در این شب:',
  hostNightStatusLabel: 'وضعیت ثبت عملیات شب (بدون افشای نقش یا هدف):',
  hostEndNightBtn: 'پایان شب و اعلام نتایج صبح',
  hostForceEndNightWarning: 'هنوز همه نقش‌های شب اقدام نکرده‌اند. آیا شب را به اجبار پایان می‌دهید؟',

  // Day Phase
  dayPhaseTitle: (round: number) => `روز ${round} — طلوع آفتاب و مذاکره`,
  noOneDiedAnnouncement: 'دیشب هیچ‌کس کشته نشد! شهر روز آرامی را آغاز می‌کند.',
  playersDiedAnnouncement: (names: string[]) =>
    `دیشب ${names.join(' و ')} به قتل رسید!`,
  privateNightResultHeader: 'گزارش محرمانه شب گذشته برای شما:',
  discussionTimerLabel: 'تایمر مذاکره روز',
  alivePlayersHeader: 'بازیکنان زنده در شهر',
  fallenPlayersHeader: 'بازیکنان خارج‌شده از بازی',
  hostStartVotingBtn: 'شروع مرحله رای‌گیری',

  // Vote Phase
  votePhaseTitle: (round: number) => `رای‌گیری روز ${round}`,
  voteInstruction: 'یک بازیکن را برای خروج از شهر انتخاب کنید یا رای سفید (رد کردن) بدهید.',
  skipVoteOption: 'رای سفید (عدم خروج هیچ‌کس)',
  submitVoteBtn: 'ثبت رای',
  changeVoteHint: 'تا پیش از بستن رای‌گیری توسط میزبان می‌توانید رای خود را تغییر دهید.',
  hostEndVotingBtn: 'پایان رای‌گیری و شمارش آرا',
  voteTieNoElimination: 'آرا مساوی شد یا رای سفید اکثریت را داشت؛ امروز کسی از شهر خارج نمی‌شود.',
  voteEliminatedAnnouncement: (name: string, roleName?: string) =>
    roleName
      ? `${name} با اکثریت آرا از شهر خارج شد. نقش او: «${roleName}»`
      : `${name} با اکثریت آرا از شهر خارج شد.`,

  // Game Over
  gameOverTitle: 'پایان بازی!',
  townWinsBanner: 'پیروزی شهروندان! تمام اعضای مافیا شناسایی و حذف شدند.',
  mafiaWinsBanner: 'پیروزی مافیا! مافیا کنترل کامل شهر را به دست گرفت.',
  fullRoleRosterTitle: 'فهرست کامل بازیکنان و نقش‌های واقعی',
  backToLobbyHostBtn: 'بازگشت به لابی برای دست جدید',
};
