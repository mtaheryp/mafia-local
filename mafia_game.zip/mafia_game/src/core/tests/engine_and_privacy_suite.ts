import { ActionResolver } from '../engine/action_resolver';
import { GameEngine } from '../engine/game_engine';
import { GamePhase } from '../engine/game_phase';
import { WinChecker } from '../engine/win_checker';
import { RoleIds } from '../roles/role_ids';
import { RoleTeam } from '../roles/role_module';
import { WsConnectionAdapter, WsGateway } from '../../server/ws_gateway';

export interface TestCaseResult {
  id: string;
  title: string;
  category: 'unit' | 'integration_privacy';
  passed: boolean;
  durationMs: number;
  details: string;
}

/**
 * Runs all required Unit Tests (§6.1) + the 6-Client WebSocket Privacy Leak Integration Test (§6.2).
 * Can be invoked live from the UI or from CLI test scripts.
 */
export function runAllEngineAndPrivacyTests(): TestCaseResult[] {
  const results: TestCaseResult[] = [];

  function runTest(
    id: string,
    title: string,
    category: 'unit' | 'integration_privacy',
    fn: () => string
  ) {
    const start = performance.now();
    try {
      const details = fn();
      results.push({
        id,
        title,
        category,
        passed: true,
        durationMs: Math.round((performance.now() - start) * 100) / 100,
        details,
      });
    } catch (err) {
      results.push({
        id,
        title,
        category,
        passed: false,
        durationMs: Math.round((performance.now() - start) * 100) / 100,
        details: err instanceof Error ? err.message : String(err),
      });
    }
  }

  // 1. Role Assignment Distribution Test
  runTest(
    'unit_role_distribution',
    'توزیع دقیق و تصادفی نقش‌ها (۱ مافیا، ۱ دکتر، ۱ کارآگاه، ۳ شهروند)',
    'unit',
    () => {
      const engine = new GameEngine('test-dist');
      const host = engine.joinOrReconnect({ name: 'آرش', preferHost: true }).session;
      for (const name of ['بهرام', 'پریسا', 'تینا', 'جواد', 'حامد']) {
        engine.joinOrReconnect({ name });
      }
      engine.configureRolesAndRules(host.playerId, {
        [RoleIds.mafia]: 1,
        [RoleIds.doctor]: 1,
        [RoleIds.detective]: 1,
        [RoleIds.hunter]: 0,
      });
      engine.startGame(host.playerId, 42);

      const counts: Record<string, number> = {};
      for (const s of engine.sessions) {
        const r = engine.getRoleAssignmentForPlayer(s.playerId)!;
        counts[r] = (counts[r] ?? 0) + 1;
      }

      if (counts[RoleIds.mafia] !== 1) throw new Error('تعداد مافیا باید دقیقاً ۱ باشد');
      if (counts[RoleIds.doctor] !== 1) throw new Error('تعداد دکتر باید دقیقاً ۱ باشد');
      if (counts[RoleIds.detective] !== 1) throw new Error('تعداد کارآگاه باید دقیقاً ۱ باشد');
      if (counts[RoleIds.villager] !== 3) throw new Error('تعداد شهروند ساده باید دقیقاً ۳ باشد');

      return '۶ بازیکن با موفقیت نقش‌های دقیق (۱ مافیا، ۱ دکتر، ۱ کارآگاه، ۳ شهروند) دریافت کردند.';
    }
  );

  // 2. Doctor Save vs Mafia Kill Resolution Order Test
  runTest(
    'unit_doctor_save',
    'نجات دکتر در برابر شلیک مافیا (ترتیب قطعی: محافظت ← شلیک ← استعلام)',
    'unit',
    () => {
      const engine = new GameEngine('test-doc-save');
      const p1 = engine.joinOrReconnect({ name: 'بازیکن ۱', preferHost: true }).session;
      const p2 = engine.joinOrReconnect({ name: 'بازیکن ۲' }).session;
      const p3 = engine.joinOrReconnect({ name: 'بازیکن ۳' }).session;
      const p4 = engine.joinOrReconnect({ name: 'بازیکن ۴' }).session;
      const p5 = engine.joinOrReconnect({ name: 'بازیکن ۵' }).session;
      const p6 = engine.joinOrReconnect({ name: 'بازیکن ۶' }).session;

      const view = engine.buildInternalGameStateView();
      view.roleAssignments = {
        [p1.playerId]: RoleIds.mafia,
        [p2.playerId]: RoleIds.doctor,
        [p3.playerId]: RoleIds.detective,
        [p4.playerId]: RoleIds.villager,
        [p5.playerId]: RoleIds.villager,
        [p6.playerId]: RoleIds.villager,
      };

      const outcome = ActionResolver.resolveNight(view, {
        [p1.playerId]: {
          actorId: p1.playerId,
          roleId: RoleIds.mafia,
          targetPlayerId: p4.playerId,
        },
        [p2.playerId]: {
          actorId: p2.playerId,
          roleId: RoleIds.doctor,
          targetPlayerId: p4.playerId,
        },
      });

      if (outcome.killedPlayerIds.length !== 0) {
        throw new Error('بازیکن محافظت‌شده توسط دکتر نباید کشته شود!');
      }
      if (!outcome.savedPlayerIds.includes(p4.playerId)) {
        throw new Error('بازیکن ۴ باید در لیست نجات‌یافتگان باشد.');
      }

      return 'شلیک مافیا به بازیکن ۴ با محافظت دکتر خنثی شد و هیچ‌کس کشته نشد.';
    }
  );

  // 3. Doctor Cannot Protect Same Target Twice In A Row Test
  runTest(
    'unit_doctor_no_consecutive',
    'قانون عدم محافظت دکتر از یک نفر در دو شب متوالی',
    'unit',
    () => {
      const engine = new GameEngine('test-doc-consecutive');
      const p1 = engine.joinOrReconnect({ name: 'میزبان', preferHost: true }).session;
      const p2 = engine.joinOrReconnect({ name: 'دکتر' }).session;
      const p3 = engine.joinOrReconnect({ name: 'سوم' }).session;
      const p4 = engine.joinOrReconnect({ name: 'چهارم' }).session;
      const p5 = engine.joinOrReconnect({ name: 'پنجم' }).session;

      const view = engine.buildInternalGameStateView();
      view.roleAssignments = {
        [p1.playerId]: RoleIds.mafia,
        [p2.playerId]: RoleIds.doctor,
        [p3.playerId]: RoleIds.villager,
        [p4.playerId]: RoleIds.villager,
        [p5.playerId]: RoleIds.villager,
      };
      // Simulate that Doctor protected p3 last night
      view.doctorLastProtectedTarget[p2.playerId] = p3.playerId;

      const outcomeRepeat = ActionResolver.resolveNight(view, {
        [p1.playerId]: {
          actorId: p1.playerId,
          roleId: RoleIds.mafia,
          targetPlayerId: p3.playerId,
        },
        [p2.playerId]: {
          actorId: p2.playerId,
          roleId: RoleIds.doctor,
          targetPlayerId: p3.playerId, // Invalid consecutive target!
        },
      });

      if (!outcomeRepeat.killedPlayerIds.includes(p3.playerId)) {
        throw new Error('محافظت تکراری دکتر در دو شب متوالی باید رد شود.');
      }

      return 'تلاش دکتر برای محافظت مجدد از هدف شب گذشته توسط اعتبارسنج رد شد.';
    }
  );

  // 4. Detective Alignment Privacy Test (Returns Team Only, Not Exact Role)
  runTest(
    'unit_detective_alignment',
    'استعلام کارآگاه: دریافت قطب (شهروند/مافیا) بدون افشای نقش دقیق و فقط برای کارآگاه',
    'unit',
    () => {
      const engine = new GameEngine('test-detective');
      const p1 = engine.joinOrReconnect({ name: 'مافیا۱', preferHost: true }).session;
      const p2 = engine.joinOrReconnect({ name: 'دکتر۱' }).session;
      const p3 = engine.joinOrReconnect({ name: 'کارآگاه۱' }).session;
      const p4 = engine.joinOrReconnect({ name: 'شهروند۱' }).session;
      const p5 = engine.joinOrReconnect({ name: 'شهروند۲' }).session;

      const view = engine.buildInternalGameStateView();
      view.roleAssignments = {
        [p1.playerId]: RoleIds.mafia,
        [p2.playerId]: RoleIds.doctor,
        [p3.playerId]: RoleIds.detective,
        [p4.playerId]: RoleIds.villager,
        [p5.playerId]: RoleIds.villager,
      };

      const outcome = ActionResolver.resolveNight(view, {
        [p3.playerId]: {
          actorId: p3.playerId,
          roleId: RoleIds.detective,
          targetPlayerId: p2.playerId, // Investigating the Doctor
        },
      });

      const inv = outcome.investigations[p3.playerId];
      if (!inv || inv.team !== RoleTeam.town) {
        throw new Error('استعلام دکتر باید قطب Town برگرداند.');
      }

      return 'کارآگاه با استعلام از دکتر فقط قطب «گروه شهروندان (Town)» را بدون افشای عنوان نقش دکتر دریافت کرد.';
    }
  );

  // 5. Vote Tie = No Elimination Rule Test
  runTest(
    'unit_vote_tie',
    'قانون تساوی آرا در رای‌گیری روز (تساوی = عدم خروج هیچ‌کس)',
    'unit',
    () => {
      const engine = new GameEngine('test-vote-tie');
      const host = engine.joinOrReconnect({ name: 'بازیکن ۱', preferHost: true }).session;
      const p2 = engine.joinOrReconnect({ name: 'بازیکن ۲' }).session;
      const p3 = engine.joinOrReconnect({ name: 'بازیکن ۳' }).session;
      const p4 = engine.joinOrReconnect({ name: 'بازیکن ۴' }).session;
      const p5 = engine.joinOrReconnect({ name: 'بازیکن ۵' }).session;
      const p6 = engine.joinOrReconnect({ name: 'بازیکن ۶' }).session;

      engine.startGame(host.playerId, 99);
      // RoleReveal -> Night 1
      engine.hostAdvancePhase(host.playerId, true);
      // Night 1 -> Day 1 (nobody acts, nobody dies)
      engine.hostAdvancePhase(host.playerId, true);
      // Day 1 -> Vote 1
      engine.hostAdvancePhase(host.playerId, true);

      // 2 votes for p2, 2 votes for p3, 2 skip
      engine.submitVote(host.playerId, p2.playerId);
      engine.submitVote(p4.playerId, p2.playerId);
      engine.submitVote(p2.playerId, p3.playerId);
      engine.submitVote(p5.playerId, p3.playerId);
      engine.submitVote(p3.playerId, null);
      engine.submitVote(p6.playerId, null);

      engine.hostAdvancePhase(host.playerId, true);

      const summary = engine.getLastVoteSummary();
      if (!summary || !summary.isTie || summary.eliminatedPlayerId !== null) {
        throw new Error('در حالت تساوی آرا نباید کسی حذف شود!');
      }

      const aliveCount = engine.sessions.filter((s) => s.isAlive).length;
      if (aliveCount !== 6) {
        throw new Error('هر ۶ بازیکن باید پس از تساوی آرا زنده بمانند.');
      }

      return 'تساوی ۲ به ۲ در رای‌گیری روز بررسی شد: هیچ بازیکنی حذف نشد و بازی وارد شب دوم شد.';
    }
  );

  // 6. Win Condition Checks (Town Win & Mafia Parity Win)
  runTest(
    'unit_win_conditions',
    'بررسی شرط پیروزی شهروندان (حذف کل مافیا) و پیروزی مافیا (برابری تعداد مافیا و شهروند)',
    'unit',
    () => {
      const engine = new GameEngine('test-win');
      const p1 = engine.joinOrReconnect({ name: 'الف', preferHost: true }).session;
      const p2 = engine.joinOrReconnect({ name: 'ب' }).session;
      const p3 = engine.joinOrReconnect({ name: 'پ' }).session;
      const p4 = engine.joinOrReconnect({ name: 'ت' }).session;
      const p5 = engine.joinOrReconnect({ name: 'ث' }).session;

      const view = engine.buildInternalGameStateView();
      view.roleAssignments = {
        [p1.playerId]: RoleIds.mafia,
        [p2.playerId]: RoleIds.doctor,
        [p3.playerId]: RoleIds.detective,
        [p4.playerId]: RoleIds.villager,
        [p5.playerId]: RoleIds.villager,
      };

      // Case A: Mafia eliminated -> Town wins
      view.players.find((p) => p.id === p1.playerId)!.isAlive = false;
      const townWin = WinChecker.check(view);
      if (!townWin.isGameOver || townWin.winningTeam !== RoleTeam.town) {
        throw new Error('با حذف تنها مافیا، شهروندان باید برنده شوند.');
      }

      // Case B: 1 Mafia alive, 1 Town alive -> Mafia wins
      view.players.find((p) => p.id === p1.playerId)!.isAlive = true;
      view.players.find((p) => p.id === p2.playerId)!.isAlive = false;
      view.players.find((p) => p.id === p3.playerId)!.isAlive = false;
      view.players.find((p) => p.id === p4.playerId)!.isAlive = false;
      const mafiaWin = WinChecker.check(view);
      if (!mafiaWin.isGameOver || mafiaWin.winningTeam !== RoleTeam.mafia) {
        throw new Error('با برابری ۱ مافیا و ۱ شهروند، مافیا باید برنده شود.');
      }

      return 'هر دو شرط پیروزی شهروندان (۰ مافیا) و پیروزی مافیا (۱ مافیا در برابر ۱ شهروند) تایید شدند.';
    }
  );

  // 7. Full 6-Client WebSocket Integration & Strict Role Privacy Leak Test (§6.2 Hard Requirement)
  runTest(
    'integration_6_client_zero_leak',
    'تست یکپارچگی پروتکل وب‌سوکت با ۶ کلاینت و اسکن تمام بسته‌ها برای تضمین عدم نشت نقش‌ها',
    'integration_privacy',
    () => {
      const engine = new GameEngine('test-6-client-ws');
      const gateway = new WsGateway(engine);

      interface MockClient {
        conn: WsConnectionAdapter;
        playerId: string;
        sessionToken: string;
        name: string;
        inbox: string[];
      }

      const clients: MockClient[] = [];
      let totalFramesInspected = 0;

      // Attach strict privacy leak scanner on EVERY outgoing WebSocket message before GameOver
      gateway.onOutgoingMessage((recipientPlayerId, envelope) => {
        totalFramesInspected++;
        if (!recipientPlayerId) return;
        if (engine.phase === GamePhase.lobby || engine.phase === GamePhase.gameOver) return;

        const serialized = JSON.stringify(envelope);

        // Verify that for every OTHER alive player, their secret roleId is not leaked in `mySecretRole` or `roleAssignments`
        if (serialized.includes('"roleAssignments"')) {
          throw new Error(
            `نشت امنیتی! فیلد داخلی roleAssignments در پیام ارسالی به ${recipientPlayerId} دیده شد!`
          );
        }

        // Also check that if recipient is NOT Detective, they never receive `discoveredAlignment`
        const recipientRole = engine.getRoleAssignmentForPlayer(recipientPlayerId);
        if (recipientRole !== RoleIds.detective && serialized.includes('"discoveredAlignment"')) {
          throw new Error(
            `نشت امنیتی! نتیجه استعلام کارآگاه برای بازیکن غیرکارآگاه (${recipientPlayerId}) ارسال شد!`
          );
        }

        // Check that `revealedRoster` is strictly null while game is still active and player is alive
        const recipientSession = engine.getSessionByPlayerId(recipientPlayerId);
        if (
          recipientSession?.isAlive &&
          envelope.type === 'stateSync' &&
          (envelope.payload as { revealedRoster: unknown }).revealedRoster !== null
        ) {
          throw new Error(
            `نشت امنیتی! فهرست کامل نقش‌ها (revealedRoster) پیش از پایان بازی برای بازیکن زنده ${recipientPlayerId} ارسال شد!`
          );
        }
      });

      // Connect 6 simulated clients over WebSocket gateway
      const names = ['میزبان (امیر)', 'سارا', 'کیوان', 'نازنین', 'فرهاد', 'مهسا'];
      names.forEach((name, idx) => {
        const inbox: string[] = [];
        const conn: WsConnectionAdapter = {
          id: `conn_${idx}`,
          send: (raw) => inbox.push(raw),
        };
        gateway.handleRawMessage(
          conn,
          JSON.stringify({
            type: 'join',
            seq: 1,
            payload: { name, preferHost: idx === 0 },
          })
        );

        const joinedEnv = JSON.parse(inbox[0]);
        clients.push({
          conn,
          playerId: joinedEnv.payload.playerId,
          sessionToken: joinedEnv.payload.sessionToken,
          name,
          inbox,
        });
      });

      const hostClient = clients[0];

      // Host starts game
      gateway.handleRawMessage(
        hostClient.conn,
        JSON.stringify({
          type: 'startGame',
          seq: 2,
          payload: { sessionToken: hostClient.sessionToken },
        })
      );

      // Verify each client only knows their own role in their latest stateSync
      for (const c of clients) {
        const lastSyncRaw = [...c.inbox]
          .reverse()
          .find((m) => JSON.parse(m).type === 'stateSync')!;
        const syncState = JSON.parse(lastSyncRaw).payload;
        const expectedRole = engine.getRoleAssignmentForPlayer(c.playerId);
        if (!syncState.mySecretRole || syncState.mySecretRole.roleId !== expectedRole) {
          throw new Error(`بازیکن ${c.name} نقش صحیح خود را دریافت نکرد.`);
        }
        // Ensure no other player in `syncState.players` has `revealedRoleId` while alive in RoleReveal
        for (const p of syncState.players) {
          if (p.revealedRoleId !== undefined) {
            throw new Error(`نقش بازیکن ${p.name} در ابتدای بازی افشا شده است!`);
          }
        }
      }

      // All 6 clients mark Ready
      for (const c of clients) {
        gateway.handleRawMessage(
          c.conn,
          JSON.stringify({
            type: 'ready',
            seq: 3,
            payload: { sessionToken: c.sessionToken },
          })
        );
      }

      // Host advances to Night 1
      gateway.handleRawMessage(
        hostClient.conn,
        JSON.stringify({
          type: 'advancePhase',
          seq: 4,
          payload: { sessionToken: hostClient.sessionToken },
        })
      );

      // Find Mafia, Doctor, Detective, and a Villager victim
      const mafiaClient = clients.find(
        (c) => engine.getRoleAssignmentForPlayer(c.playerId) === RoleIds.mafia
      )!;
      const doctorClient = clients.find(
        (c) => engine.getRoleAssignmentForPlayer(c.playerId) === RoleIds.doctor
      )!;
      const detectiveClient = clients.find(
        (c) => engine.getRoleAssignmentForPlayer(c.playerId) === RoleIds.detective
      )!;
      const villagerVictim = clients.find(
        (c) => engine.getRoleAssignmentForPlayer(c.playerId) === RoleIds.villager
      )!;

      // Mafia targets villagerVictim; Doctor protects self; Detective investigates Mafia
      gateway.handleRawMessage(
        mafiaClient.conn,
        JSON.stringify({
          type: 'submitNightAction',
          seq: 5,
          payload: {
            sessionToken: mafiaClient.sessionToken,
            targetPlayerId: villagerVictim.playerId,
          },
        })
      );
      gateway.handleRawMessage(
        doctorClient.conn,
        JSON.stringify({
          type: 'submitNightAction',
          seq: 6,
          payload: {
            sessionToken: doctorClient.sessionToken,
            targetPlayerId: doctorClient.playerId,
          },
        })
      );
      gateway.handleRawMessage(
        detectiveClient.conn,
        JSON.stringify({
          type: 'submitNightAction',
          seq: 7,
          payload: {
            sessionToken: detectiveClient.sessionToken,
            targetPlayerId: mafiaClient.playerId,
          },
        })
      );

      // Host ends Night 1 -> transitions to Day 1
      gateway.handleRawMessage(
        hostClient.conn,
        JSON.stringify({
          type: 'advancePhase',
          seq: 8,
          payload: { sessionToken: hostClient.sessionToken },
        })
      );

      // Host starts Voting -> Vote 1
      gateway.handleRawMessage(
        hostClient.conn,
        JSON.stringify({
          type: 'advancePhase',
          seq: 9,
          payload: { sessionToken: hostClient.sessionToken },
        })
      );

      // Living town players vote out Mafia based on Detective's finding
      for (const c of clients) {
        const s = engine.getSessionByPlayerId(c.playerId)!;
        if (s.isAlive && c.playerId !== mafiaClient.playerId) {
          gateway.handleRawMessage(
            c.conn,
            JSON.stringify({
              type: 'submitVote',
              seq: 10,
              payload: {
                sessionToken: c.sessionToken,
                targetPlayerId: mafiaClient.playerId,
              },
            })
          );
        }
      }

      // Host ends Voting -> Mafia eliminated -> Town wins -> GameOver!
      gateway.handleRawMessage(
        hostClient.conn,
        JSON.stringify({
          type: 'advancePhase',
          seq: 11,
          payload: { sessionToken: hostClient.sessionToken },
        })
      );

      if (engine.phase !== GamePhase.gameOver) {
        throw new Error('بازی باید پس از حذف تنها مافیا به پایان برسد.');
      }

      return `یک بازی کامل ۶ نفره روی وب‌سوکت اجرا شد (${totalFramesInspected} بسته شبکه اسکن شد) — ۰ نشت اطلاعات محرمانه!`;
    }
  );

  return results;
}
