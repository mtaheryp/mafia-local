/**
 * Exact RoleModule Contract (Pure Domain Layer — Zero UI/Framework Imports)
 * Mirrors lib/core/roles/role_module.dart in the Flutter codebase.
 */

export enum RoleTeam {
  town = 'town',
  mafia = 'mafia',
  neutral = 'neutral',
}

export interface SelectablePlayerOption {
  playerId: string;
  displayName: string;
  disabled?: boolean;
  disabledReason?: string;
}

export interface NightActionSchema {
  roleId: string;
  prompt: string;
  allowSkip: boolean;
  selectablePlayers: SelectablePlayerOption[];
  teammates?: { playerId: string; displayName: string }[];
  teammateSelections?: Record<string, string | null>;
}

export interface NightAction {
  actorId: string;
  roleId: string;
  targetPlayerId: string | null;
}

export enum NightEffectType {
  protect = 'protect',
  kill = 'kill',
  investigate = 'investigate',
}

export interface NightEffect {
  type: NightEffectType;
  sourcePlayerId: string;
  roleId: string;
  targetPlayerId: string;
}

export interface RoleResultPayload {
  roleId: string;
  title: string;
  message: string;
  targetPlayerId?: string;
  discoveredAlignment?: RoleTeam;
}

export interface PublicPlayerView {
  id: string;
  name: string;
  isAlive: boolean;
  isConnected: boolean;
  isHost: boolean;
  isReady: boolean;
  revealedRoleId?: string;
  revealedRoleName?: string;
  revealedTeam?: RoleTeam;
}

export interface GameStateView {
  round: number;
  phase: string;
  players: PublicPlayerView[];
  roleAssignments: Record<string, string>; // Only accessible inside server/engine
  doctorLastProtectedTarget: Record<string, string | null>; // actorId -> lastNightTargetId
  hunterUsedShot: Record<string, boolean>; // actorId -> used one-shot ability
  nightActions: Record<string, NightAction>;
  rules: {
    revealRoleOnDeath: boolean;
    doctorCanSelfProtect: boolean;
    doctorCannotProtectSameTargetTwiceInARow: boolean;
    revealRolesToDeadSpectators: boolean;
    enableLobbyChat: boolean;
    enableDayChat: boolean;
    discussionTimerSeconds: number;
    mafiaTieRule: 'no_kill' | 'last_selection';
  };
}

export interface NightContext {
  view: GameStateView;
  allSubmittedActions: Record<string, NightAction>;
}

export interface NightOutcome {
  killedPlayerIds: string[];
  savedPlayerIds: string[];
  targetedByMafiaId: string | null;
  investigations: Record<string, { targetId: string; targetName: string; team: RoleTeam }>;
  hunterKilledId: string | null;
}

export interface WinConditionResult {
  isGameOver: boolean;
  winningTeam: RoleTeam | null;
  reason: string;
}

export interface WinCondition {
  id: string;
  priority: number;
  evaluate(view: GameStateView): WinConditionResult | null;
}

/**
 * Abstract RoleModule contract that every role plugin implements.
 * Adding a new role requires ONLY creating one file implementing RoleModule
 * and registering it in RoleRegistry.
 */
export abstract class RoleModule {
  /** Stable identifier, e.g. 'doctor' */
  abstract get id(): string;

  /** Localized display name, e.g. 'دکتر' */
  abstract get displayName(): string;

  /** Short localized description shown on role reveal and config screen */
  abstract get shortDescription(): string;

  /** Team alignment: town, mafia, or neutral */
  abstract get team(): RoleTeam;

  /** Whether this role wakes up during Night phase */
  abstract get hasNightAction(): boolean;

  /** True if role acts every night; false for one-shot roles like Hunter */
  abstract get actsEachNight(): boolean;

  /** Whether enabled by default in Role Configuration stepper */
  get enabledByDefaultInConfig(): boolean {
    return true;
  }

  /** Minimum count allowed in Role Configuration (1 for Mafia, 0 for others) */
  get minCountInConfig(): number {
    return 0;
  }

  /**
   * Called during Night: server asks this role's player to submit an action.
   * Returns the UI action schema (which players are selectable, what the prompt is).
   */
  abstract buildNightActionSchema(view: GameStateView, actorId: string): NightActionSchema | null;

  /**
   * Validate a submitted action from `actorId`.
   */
  abstract validateAction(view: GameStateView, actorId: string, action: NightAction): boolean;

  /**
   * Contribute an effect to the night resolution (e.g. protect, kill, investigate).
   * Multiple roles can contribute; ActionResolver combines them deterministically.
   */
  abstract resolve(ctx: NightContext, actorId: string, action: NightAction): NightEffect | null;

  /**
   * How to deliver the private result to the actor at the end of the night (if any).
   */
  abstract resultForActor(
    view: GameStateView,
    actorId: string,
    outcome: NightOutcome
  ): RoleResultPayload | null;

  /**
   * Optional custom win condition contribution (most roles use default Town/Mafia win conditions).
   */
  get customWinCondition(): WinCondition | null {
    return null;
  }
}
