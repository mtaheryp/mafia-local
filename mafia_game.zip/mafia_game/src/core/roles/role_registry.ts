import { DetectiveRole } from './builtin/detective_role';
import { DoctorRole } from './builtin/doctor_role';
import { HunterRole } from './builtin/hunter_role';
import { MafiaRole } from './builtin/mafia_role';
import { VillagerRole } from './builtin/villager_role';
import { RoleIds } from './role_ids';
import { RoleModule } from './role_module';

/**
 * Central Registry of RoleModule plugins.
 * To add a new role to the game:
 * 1. Create a class extending RoleModule in `builtin/`
 * 2. Call `RoleRegistry.register(new YourNewRole())` below.
 * The Host's Role Configuration UI and Engine will automatically discover it.
 */
export class RoleRegistry {
  private static readonly _modules: Map<string, RoleModule> = new Map();

  static {
    RoleRegistry.register(new MafiaRole());
    RoleRegistry.register(new DoctorRole());
    RoleRegistry.register(new DetectiveRole());
    RoleRegistry.register(new HunterRole()); // 5th optional role (disabled by default in preset)
    RoleRegistry.register(new VillagerRole());
  }

  static register(module: RoleModule): void {
    this._modules.set(module.id, module);
  }

  static get(roleId: string): RoleModule {
    const found = this._modules.get(roleId);
    if (!found) {
      throw new Error(`RoleModule not found for id: ${roleId}`);
    }
    return found;
  }

  static tryGet(roleId: string): RoleModule | undefined {
    return this._modules.get(roleId);
  }

  static getAll(): RoleModule[] {
    return Array.from(this._modules.values());
  }

  /**
   * Returns all configurable non-villager roles for the Host's Role Configuration screen.
   */
  static getConfigurableNonVillagerRoles(): RoleModule[] {
    return this.getAll().filter((r) => r.id !== RoleIds.villager);
  }
}
