/**
 * Stable string identifiers for built-in and extensible RoleModules.
 */
export const RoleIds = {
  villager: 'villager',
  mafia: 'mafia',
  doctor: 'doctor',
  detective: 'detective',
  hunter: 'hunter', // Optional 5th plugin role demonstrating 1-file + 1-line registration extensibility
} as const;

export type RoleId = (typeof RoleIds)[keyof typeof RoleIds] | string;
