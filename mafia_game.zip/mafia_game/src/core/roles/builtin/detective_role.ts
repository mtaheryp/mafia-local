import { RoleIds } from '../role_ids';
import {
  GameStateView,
  NightAction,
  NightActionSchema,
  NightContext,
  NightEffect,
  NightEffectType,
  NightOutcome,
  RoleModule,
  RoleResultPayload,
  RoleTeam,
} from '../role_module';

/**
 * Detective RoleModule (`detective`)
 * Team: Town. At night, chooses ONE player and receives their team alignment (Town / Mafia),
 * NOT their exact role. Result delivered privately to the detective only.
 */
export class DetectiveRole extends RoleModule {
  get id(): string {
    return RoleIds.detective;
  }

  get displayName(): string {
    return 'کارآگاه';
  }

  get shortDescription(): string {
    return 'عضو گروه شهروندان است. هر شب استعلام یک بازیکن را می‌گیرد و قطب او (شهروند یا مافیا) را به صورت محرمانه دریافت می‌کند.';
  }

  get team(): RoleTeam {
    return RoleTeam.town;
  }

  get hasNightAction(): boolean {
    return true;
  }

  get actsEachNight(): boolean {
    return true;
  }

  buildNightActionSchema(view: GameStateView, actorId: string): NightActionSchema | null {
    const actor = view.players.find((p) => p.id === actorId);
    if (!actor || !actor.isAlive) return null;

    const selectablePlayers = view.players
      .filter((p) => p.isAlive)
      .map((p) => ({
        playerId: p.id,
        displayName: p.name,
        disabled: p.id === actorId,
        disabledReason: p.id === actorId ? 'نمی‌توانید از خودتان استعلام بگیرید' : undefined,
      }));

    return {
      roleId: this.id,
      prompt: 'یک بازیکن را برای استعلام قطب (شهروند / مافیا) در این شب انتخاب کنید:',
      allowSkip: false,
      selectablePlayers,
    };
  }

  validateAction(view: GameStateView, actorId: string, action: NightAction): boolean {
    const actor = view.players.find((p) => p.id === actorId);
    if (!actor || !actor.isAlive) return false;
    if (!action.targetPlayerId) return true; // Auto-skip on disconnect

    if (action.targetPlayerId === actorId) return false;
    const target = view.players.find((p) => p.id === action.targetPlayerId);
    return Boolean(target && target.isAlive);
  }

  resolve(_ctx: NightContext, actorId: string, action: NightAction): NightEffect | null {
    if (!action.targetPlayerId) return null;
    return {
      type: NightEffectType.investigate,
      sourcePlayerId: actorId,
      roleId: this.id,
      targetPlayerId: action.targetPlayerId,
    };
  }

  resultForActor(
    _view: GameStateView,
    actorId: string,
    outcome: NightOutcome
  ): RoleResultPayload | null {
    const inv = outcome.investigations[actorId];
    if (!inv) return null;

    const isMafia = inv.team === RoleTeam.mafia;
    return {
      roleId: this.id,
      title: `نتیجه استعلام کارآگاه (${inv.targetName})`,
      message: isMafia
        ? `استعلام «${inv.targetName}» مثبت است: او عضو گروه مافیا است!`
        : `استعلام «${inv.targetName}» منفی است: او در گروه شهروندان قرار دارد.`,
      targetPlayerId: inv.targetId,
      discoveredAlignment: inv.team,
    };
  }
}
