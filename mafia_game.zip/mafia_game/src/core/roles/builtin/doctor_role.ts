import { RoleIds } from '../role_ids';
import {
  GameStateView,
  NightAction,
  NightActionSchema,
  NightContext,
  NightEffect,
  NightEffectType,
  NightOutcome,
  RoleModule,
  RoleResultPayload,
  RoleTeam,
} from '../role_module';

/**
 * Doctor RoleModule (`doctor`)
 * Team: Town. At night, chooses ONE player (may be self if rule enabled) to protect.
 * Cannot protect the same player two nights in a row.
 */
export class DoctorRole extends RoleModule {
  get id(): string {
    return RoleIds.doctor;
  }

  get displayName(): string {
    return 'دکتر';
  }

  get shortDescription(): string {
    return 'عضو گروه شهروندان است. هر شب یک نفر را از خطر شلیک مافیا نجات می‌دهد. نمی‌تواند دو شب متوالی یک نفر را نجات دهد.';
  }

  get team(): RoleTeam {
    return RoleTeam.town;
  }

  get hasNightAction(): boolean {
    return true;
  }

  get actsEachNight(): boolean {
    return true;
  }

  buildNightActionSchema(view: GameStateView, actorId: string): NightActionSchema | null {
    const actor = view.players.find((p) => p.id === actorId);
    if (!actor || !actor.isAlive) return null;

    const lastTarget = view.doctorLastProtectedTarget[actorId] ?? null;

    const selectablePlayers = view.players
      .filter((p) => p.isAlive)
      .map((p) => {
        const isConsecutiveRepeat =
          view.rules.doctorCannotProtectSameTargetTwiceInARow &&
          lastTarget !== null &&
          lastTarget === p.id;
        const isDisallowedSelf = !view.rules.doctorCanSelfProtect && p.id === actorId;

        return {
          playerId: p.id,
          displayName: p.id === actorId ? `${p.name} (خودتان)` : p.name,
          disabled: isConsecutiveRepeat || isDisallowedSelf,
          disabledReason: isConsecutiveRepeat
            ? 'شب گذشته محافظت شده (ممنوعیت دو شب متوالی)'
            : isDisallowedSelf
            ? 'محافظت از خود در قوانین غیرفعال است'
            : undefined,
        };
      });

    return {
      roleId: this.id,
      prompt: 'یک بازیکن را برای محافظت در برابر شلیک امشب مافیا انتخاب کنید:',
      allowSkip: false,
      selectablePlayers,
    };
  }

  validateAction(view: GameStateView, actorId: string, action: NightAction): boolean {
    const actor = view.players.find((p) => p.id === actorId);
    if (!actor || !actor.isAlive) return false;
    if (!action.targetPlayerId) return true; // Only if timed out/disconnected auto-skip

    const target = view.players.find((p) => p.id === action.targetPlayerId);
    if (!target || !target.isAlive) return false;

    if (!view.rules.doctorCanSelfProtect && target.id === actorId) {
      return false;
    }

    const lastTarget = view.doctorLastProtectedTarget[actorId] ?? null;
    if (
      view.rules.doctorCannotProtectSameTargetTwiceInARow &&
      lastTarget !== null &&
      lastTarget === target.id
    ) {
      return false;
    }

    return true;
  }

  resolve(_ctx: NightContext, actorId: string, action: NightAction): NightEffect | null {
    if (!action.targetPlayerId) return null;
    return {
      type: NightEffectType.protect,
      sourcePlayerId: actorId,
      roleId: this.id,
      targetPlayerId: action.targetPlayerId,
    };
  }

  resultForActor(
    _view: GameStateView,
    _actorId: string,
    _outcome: NightOutcome
  ): RoleResultPayload | null {
    // Standard rule: Doctor learns nothing privately (sees public morning report)
    return null;
  }
}
