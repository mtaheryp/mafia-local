import { RoleIds } from '../role_ids';
import {
  GameStateView,
  NightAction,
  NightActionSchema,
  NightContext,
  NightEffect,
  NightEffectType,
  NightOutcome,
  RoleModule,
  RoleResultPayload,
  RoleTeam,
} from '../role_module';

/**
 * Hunter / Sniper RoleModule (`hunter`) — Optional 5th plugin role (disabled by default, count = 0).
 * Demonstrates zero-touch extensibility: 1 file implementing RoleModule + 1 line in RoleRegistry.
 * Team: Town. One-shot night action (`actsEachNight = false`): can shoot one suspect once per game.
 */
export class HunterRole extends RoleModule {
  get id(): string {
    return RoleIds.hunter;
  }

  get displayName(): string {
    return 'تک‌تیرانداز (شکارچی)';
  }

  get shortDescription(): string {
    return 'عضو گروه شهروندان با ۱ تیر در کل بازی. در یکی از شب‌ها می‌تواند به مظنون اصلی خود شلیک کند یا تیرش را نگه دارد.';
  }

  get team(): RoleTeam {
    return RoleTeam.town;
  }

  get hasNightAction(): boolean {
    return true;
  }

  get actsEachNight(): boolean {
    return false; // One-shot ability
  }

  get enabledByDefaultInConfig(): boolean {
    return false; // 0 by default in presets
  }

  buildNightActionSchema(view: GameStateView, actorId: string): NightActionSchema | null {
    const actor = view.players.find((p) => p.id === actorId);
    if (!actor || !actor.isAlive) return null;
    if (view.hunterUsedShot[actorId]) return null; // Already used their single shot

    const selectablePlayers = view.players
      .filter((p) => p.isAlive)
      .map((p) => ({
        playerId: p.id,
        displayName: p.name,
        disabled: p.id === actorId,
        disabledReason: p.id === actorId ? 'نمی‌توانید به خودتان شلیک کنید' : undefined,
      }));

    return {
      roleId: this.id,
      prompt: 'شما ۱ تیر در کل بازی دارید. می‌توانید امشب شلیک کنید یا تیر خود را برای شب‌های بعد نگه دارید:',
      allowSkip: true,
      selectablePlayers,
    };
  }

  validateAction(view: GameStateView, actorId: string, action: NightAction): boolean {
    const actor = view.players.find((p) => p.id === actorId);
    if (!actor || !actor.isAlive) return false;
    if (view.hunterUsedShot[actorId]) return false;
    if (action.targetPlayerId === null) return true; // Keep bullet

    if (action.targetPlayerId === actorId) return false;
    const target = view.players.find((p) => p.id === action.targetPlayerId);
    return Boolean(target && target.isAlive);
  }

  resolve(_ctx: NightContext, actorId: string, action: NightAction): NightEffect | null {
    if (!action.targetPlayerId) return null;
    return {
      type: NightEffectType.kill,
      sourcePlayerId: actorId,
      roleId: this.id,
      targetPlayerId: action.targetPlayerId,
    };
  }

  resultForActor(
    _view: GameStateView,
    _actorId: string,
    outcome: NightOutcome
  ): RoleResultPayload | null {
    if (!outcome.hunterKilledId) return null;
    return {
      roleId: this.id,
      title: 'شلیک تک‌تیرانداز انجام شد',
      message: 'تیر شما شلیک شد. نتیجه نهایی در گزارش صبحگاهی شهر اعلام می‌شود.',
      targetPlayerId: outcome.hunterKilledId,
    };
  }
}
