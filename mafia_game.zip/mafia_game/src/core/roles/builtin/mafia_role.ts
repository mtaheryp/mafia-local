import { RoleIds } from '../role_ids';
import {
  GameStateView,
  NightAction,
  NightActionSchema,
  NightContext,
  NightEffect,
  NightEffectType,
  NightOutcome,
  RoleModule,
  RoleResultPayload,
  RoleTeam,
} from '../role_module';

/**
 * Mafia RoleModule (`mafia`)
 * Team: Mafia. At night, mafia players collectively choose ONE target to kill.
 * Multiple mafia see each other's names and live selections.
 * Tie rule: majority of mafia votes; tie = no kill that night (configurable in rules).
 */
export class MafiaRole extends RoleModule {
  get id(): string {
    return RoleIds.mafia;
  }

  get displayName(): string {
    return 'مافیا';
  }

  get shortDescription(): string {
    return 'عضو گروه مافیا است. هم‌تیمی‌های خود را می‌شناسد و هر شب با رای‌گیری درون‌گروهی یک نفر را برای ترور انتخاب می‌کنند.';
  }

  get team(): RoleTeam {
    return RoleTeam.mafia;
  }

  get hasNightAction(): boolean {
    return true;
  }

  get actsEachNight(): boolean {
    return true;
  }

  get minCountInConfig(): number {
    return 1;
  }

  buildNightActionSchema(view: GameStateView, actorId: string): NightActionSchema | null {
    const actor = view.players.find((p) => p.id === actorId);
    if (!actor || !actor.isAlive) return null;

    const teammates = view.players
      .filter((p) => view.roleAssignments[p.id] === RoleIds.mafia && p.isAlive)
      .map((p) => ({ playerId: p.id, displayName: p.name }));

    const teammateSelections: Record<string, string | null> = {};
    for (const mate of teammates) {
      const submitted = view.nightActions[mate.playerId];
      if (submitted !== undefined) {
        teammateSelections[mate.playerId] = submitted.targetPlayerId;
      }
    }

    const selectablePlayers = view.players
      .filter((p) => p.isAlive)
      .map((p) => ({
        playerId: p.id,
        displayName: p.name,
        disabled: view.roleAssignments[p.id] === RoleIds.mafia,
        disabledReason:
          view.roleAssignments[p.id] === RoleIds.mafia ? 'هم‌تیمی مافیا' : undefined,
      }));

    return {
      roleId: this.id,
      prompt: 'یک بازیکن را برای شلیک امشب مافیا انتخاب کنید (اکثریت آرای مافیا ملاک است؛ تساوی = عدم شلیک):',
      allowSkip: true,
      selectablePlayers,
      teammates,
      teammateSelections,
    };
  }

  validateAction(view: GameStateView, actorId: string, action: NightAction): boolean {
    const actor = view.players.find((p) => p.id === actorId);
    if (!actor || !actor.isAlive) return false;
    if (action.targetPlayerId === null) return true; // Skip allowed
    const target = view.players.find((p) => p.id === action.targetPlayerId);
    if (!target || !target.isAlive) return false;
    // Mafia cannot target living mafia teammates
    if (view.roleAssignments[target.id] === RoleIds.mafia) return false;
    return true;
  }

  resolve(_ctx: NightContext, actorId: string, action: NightAction): NightEffect | null {
    if (!action.targetPlayerId) return null;
    return {
      type: NightEffectType.kill,
      sourcePlayerId: actorId,
      roleId: this.id,
      targetPlayerId: action.targetPlayerId,
    };
  }

  resultForActor(
    _view: GameStateView,
    _actorId: string,
    _outcome: NightOutcome
  ): RoleResultPayload | null {
    // Standard rule: Mafia learns nothing extra privately (they see public morning results)
    return null;
  }
}
