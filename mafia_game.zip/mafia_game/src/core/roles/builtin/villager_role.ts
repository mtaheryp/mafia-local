import { RoleIds } from '../role_ids';
import {
  GameStateView,
  NightAction,
  NightActionSchema,
  NightContext,
  NightEffect,
  NightOutcome,
  RoleModule,
  RoleResultPayload,
  RoleTeam,
} from '../role_module';

/**
 * Villager RoleModule (`villager`)
 * Team: Town. No night action. Wins with Town.
 */
export class VillagerRole extends RoleModule {
  get id(): string {
    return RoleIds.villager;
  }

  get displayName(): string {
    return 'شهروند ساده';
  }

  get shortDescription(): string {
    return 'عضو گروه شهروندان است. در طول شب عملیاتی ندارد و در روز با تحلیل و رای‌گیری به شناسایی مافیا کمک می‌کند.';
  }

  get team(): RoleTeam {
    return RoleTeam.town;
  }

  get hasNightAction(): boolean {
    return false;
  }

  get actsEachNight(): boolean {
    return false;
  }

  buildNightActionSchema(_view: GameStateView, _actorId: string): NightActionSchema | null {
    return null;
  }

  validateAction(_view: GameStateView, _actorId: string, _action: NightAction): boolean {
    return false;
  }

  resolve(_ctx: NightContext, _actorId: string, _action: NightAction): NightEffect | null {
    return null;
  }

  resultForActor(
    _view: GameStateView,
    _actorId: string,
    _outcome: NightOutcome
  ): RoleResultPayload | null {
    return null;
  }
}
